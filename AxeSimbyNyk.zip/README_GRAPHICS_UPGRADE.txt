AXE SIMULATOR 3D — GRAPHICS UPGRADE

World dressing:
- Added procedural grass tufts, small mossy rocks, low bushes, and colorful wildflowers.
- Decoration positions are deterministic per world build and skip the spawn, shop, portal, shoreline, and immediate tree area.
- Decorations are visual-only and do not change harvesting, movement, or collision.
- Tiny grass tufts and flowers do not cast shadow-map shadows to reduce GPU cost.

Graphics presets (Options):
- LOW: render scale capped at 60%, smaller shadow map (when shadows are enabled).
- MEDIUM: render scale capped at 82%, medium shadow map, physically based shader remains enabled.
- HIGH: at least native render resolution and a 2048 shadow map; PBR materials, procedural surface detail, tone mapping, and shadow filtering remain enabled.
- Custom resolution and shadow toggles continue to work. The automatic performance adjustment can lower quality if the device struggles.

Performance note:
The game uses OpenGL ES 3.0 and this project has not been built on a device in this editing environment. Test the APK on the target phone; if frame rate drops, use LOW or disable shadows.
