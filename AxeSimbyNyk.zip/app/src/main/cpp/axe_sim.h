// axe_sim.h - Axe Simulator 3D: the game itself, written in C++.
// Include after engine.cpp, touch_ui.h, gltf_loader.h and gpu_renderer.h.
//
//   The world   : hilly meadow (256 m), 30 pine trees, food stall (shop), travel port, World 2 (autumn woods).
//   The player  : first-person axe, stamina, chopping.
//   The economy : sell wood, upgrade the axe (more chance of extra wood) and stamina, buy World 2 for 100,000 coins.
//                 The shop's PRICE SPIN tab is a random spinner (x1.5 ... x10000) that sets the wood price. Each new spin REPLACES the
//                 old multiplier (it does not stack): x10 then x2 leaves the price at x2.
//                 The price spin uses in-game coins only.
//   The menus   : shop (sell / upgrades / price spin), port and options (graphics, resolution, credits).
//   Numbers     : coins, wood and prices show as 10, 100, 1k, 1.5M, 2B ... (see game_numbers.h).
#pragma once
#include <iomanip>
#include <random>
#include <sstream>
#include "game_numbers.h"

struct AxeAssets {
    std::function<bool(const std::string&, std::vector<uint8_t>&)> read;   // reads a file from the app's assets
};

class AxeSim {
public:
    enum Panel { P_NONE, P_SHOP, P_PORT, P_OPTIONS };
    struct PBtn { float x, y, w, h; std::string label; int id; bool on; };

    // ---- set up by the platform code ----
    AxeAssets assets;
    std::string dataDir = ".";                                             // where the save file goes
    std::function<void(const std::string&, ModelData&)> afterModelLoad;    // used by tests
    ImageData grass;                                                       // ground picture
    FontAtlas font;                                                        // Kurland
    float fps = 0.f;

    // ---- progress and settings (saved) ----
    int wood = 0, axeLevel = 1, staminaLevel = 1, level = 1, chopped = 0;
    double coins = 0;                 // a double: the price spinner can push the numbers far past what an int holds
    double woodPriceMult = 1.0;       // the wood price multiplier from the LATEST spin (x1.5 ... x10000). A new spin replaces it: x10 then x2 = x2
    int spins = 0;                    // how many times the spinner was used
    int maxWoodLevel = 1, multLevel = 0;   // uncapped upgrades
    int highestUnlockedLevel = 1;
    bool world2Owned = false;
    float stamina = 100.f;
    int preset = 1;                    // 0 low, 1 medium, 2 high, 3 custom
    int resPercent = 75;               // picture size: 100 = full screen resolution
    bool shadowsOn = true, autoAdjust = true;

    static constexpr int kWorld2Price = 100000;   // coins to unlock World 2
    static constexpr double kWoodPrice = 5.0;     // coins for one wood before the price spinner
    static constexpr float kWorldHalf = 120.f;    // trees are placed inside this square (and on the island)
    static constexpr float kWaterLevel = -4.0f;   // the sea
    static constexpr float kFenceHeight = -2.9f;  // the fence stands where the ground reaches this height; the player cannot go lower
    float maxStamina() const { return 100.f + 20.f * (staminaLevel - 1); }
    float axeDamage() const { return 10.f + 5.f * (axeLevel - 1); }
    float woodBonusChance() const { return std::min(0.9f, 0.10f * (axeLevel - 1)); }   // chance of DOUBLE wood from a tree
    double axeCost() const { return 50.0 * axeLevel * axeLevel; }
    double staminaCost() const { return 40.0 * staminaLevel; }
    int maxWood() const { return 7 + 2 * (maxWoodLevel - 1); }                       // no artificial level cap
    double woodMultiplier() const { return std::pow(1.5, (double)multLevel); }           // uncapped multiplier
    double maxWoodCost() const { return 3000.0 * maxWoodLevel * maxWoodLevel; }
    double multCost() const { return 5000.0 * (multLevel + 1.0) * (multLevel + 1.0); }
    static double levelPrice(int lv) { if (lv <= 1) return 0.0; return 100000.0 * std::pow(100.0, (double)(lv - 2)); }
    static const char* biomeName(int lv) { static const char* n[] = {"SPRING MEADOW", "AUTUMN WOODS", "FROSTLAND", "DESERT DUNES", "MISTY HIGHLANDS", "VOLCANIC RIDGE", "TROPICAL JUNGLE", "FROZEN TUNDRA", "GOLDEN SAVANNA", "CRYSTAL PEAKS"}; return n[std::max(1, std::min(10, lv))-1]; }
    static int biomeTemp(int lv) { static const int t[] = {18, 12, -8, 38, 6, 48, 30, -24, 34, -15}; return t[std::max(1, std::min(10, lv))-1]; }
    double spinCost() const { return 5000.0 * (spins + 1.0) * (spins + 1.0); }         // same formula as the wood multiplier: 5k, 20k, 45k, 80k ... it rises with every spin
    static std::string multText(int m) { int t = 10 + 5 * m; return std::to_string(t / 10) + "." + std::to_string(t % 10); }
    // Every coin, wood and price number goes through this:  10 -> 100 -> 1k -> 1.5k -> 1M -> 1B -> 1T -> 1Qa ...
    static std::string num(double v) { return gnum::format(v); }
    static double capNum(double x) { return x == x ? std::min(x, 1e300) : 0.0; }   // keeps coins finite
    double woodPrice() const { return kWoodPrice * woodPriceMult; }               // coins for one wood right now
    // Wood from one felled tree: 4 up to the max-wood upgrade, sometimes doubled by the axe bonus, times the multiplier,
    // and ten times more in World 2.
    int rollWood() {
        int base = 4 + (int)(rand01() * (maxWood() - 4 + 1));
        if (base > maxWood()) base = maxWood();
        float g = (float)base;
        if (rand01() < woodBonusChance()) g *= 2.f;
        g *= (float)woodMultiplier();
        g *= (float)std::pow(10.0, (double)(level - 1));
        return std::max(1, (int)std::min(2.0e9, g + 0.5f));
    }

    // ---------------------------------------------------------------- the hills
    static float smoothStep(float a, float b, float x) { float t = clampf((x - a) / (b - a), 0.f, 1.f); return t * t * (3.f - 2.f * t); }
    // 0 in the middle of the island, 1 at its edge (a rounded square).
    static float islandR(float x, float z) {
        float ax = std::fabs(x) / 128.f, az = std::fabs(z) / 128.f;
        return std::pow(ax * ax * ax * ax + az * az * az * az, 0.25f);
    }
    // Ground height: hills in the middle, level ground at the start / stall / port, and the land slopes down into the sea at the edge.
    static float terrainHeightFor(int lv, float x, float z) {
        float h = 4.5f * std::sin(x * 0.045f + 1.3f) * std::cos(z * 0.038f + 0.4f) + 1.7f * std::sin(x * 0.11f + z * 0.07f + 2.0f) +
                  0.7f * std::sin(x * 0.19f - z * 0.23f + 0.7f) + 0.25f * std::sin(x * 0.41f + 1.0f) * std::sin(z * 0.37f);
        float flat = smoothStep(10.f, 22.f, hdist(x, z, 0.f, 12.f)) * smoothStep(10.f, 22.f, hdist(x, z, kStallX, kStallZ)) *
                     smoothStep(10.f, 22.f, hdist(x, z, kPortX, kPortZ));   // level ground around the start, stall and port
        float land = std::max(h * (lv == 2 ? 1.3f : 1.f) * flat, -2.f);       // no valleys below the sea
        float edge = smoothStep(0.78f, 1.0f, islandR(x, z));
        return land * (1.f - edge) + (-9.f) * edge;
    }
    float terrainHeight(float x, float z) const { return terrainHeightFor(level, x, z); }

    // ---------------------------------------------------------------- loading
    bool loadAssets(std::string* err = nullptr) {
        auto model = [&](const char* file, ModelData& m) -> bool {
            std::vector<uint8_t> bytes;
            std::string e;
            if (!assets.read || !assets.read(file, bytes)) { if (err) *err += std::string("missing ") + file + "; "; return false; }
            if (!loadGLB(bytes.data(), bytes.size(), m, &e)) { if (err) *err += std::string(file) + ": " + e + "; "; return false; }
            if (afterModelLoad) afterModelLoad(file, m);
            return true;
        };
        bool ok = model("models/axe.glb", axe_);
        ok = model("models/food_stall_in_edo.glb", stall_) && ok;
        ok = model("models/pine_tree_low-poly.glb", pine_) && ok;
        if (!stall_.parts.empty()) fitModelOnGround(stall_, 3.4f);
        if (!pine_.parts.empty()) fitModelOnGround(pine_, 9.f);
        std::vector<uint8_t> bytes, fm, fr;
        if (assets.read && assets.read("textures/grass_1k.jpg", bytes)) decodeImage(bytes.data(), bytes.size(), grass);
        if (assets.read && assets.read("fonts/kurland.txt", fm) && assets.read("fonts/kurland.raw", fr))
            if (font.load(std::string(fm.begin(), fm.end()), fr)) UiText::font = &font;
        for (int lv = 1; lv <= 2; lv++) { terrainData_[lv - 1] = makeTerrain(lv); fenceData_[lv - 1] = makeFence(lv); }
        return ok;
    }
    // Sends the models, ground picture, hills and font to the GPU. Call again if the GPU was restarted.
    void uploadToGpu(GpuRenderer& gpu) {
        gpu_ = &gpu;
        axeId_ = axe_.parts.empty() ? -1 : gpu.addModel(axe_);
        stallId_ = stall_.parts.empty() ? -1 : gpu.addModel(stall_);
        pineId_ = pine_.parts.empty() ? -1 : gpu.addModel(pine_);
        groundTex_ = gpu.addTexture(grass, true);
        for (int i = 0; i < 2; i++) { terrainId_[i] = gpu.addMesh(terrainData_[i]); fenceId_[i] = gpu.addMesh(fenceData_[i]); }
        gpu.setFont(font);
        applyGraphics();
    }
    void attach(Game& g, TouchUI& ui, GpuRenderer& gpu) {
        game_ = &g; ui_ = &ui; gpu_ = &gpu;
        ui.setGameLayout(true);
        g.allowThirdPerson = false; g.firstPerson = true;   // first person only
        for (int i = 0; i < kReelLen; i++) reel_[i] = i % kSpinTiers;   // what the price spinner shows before the first spin
        g.playerStart = Vec3(0, 0.85f, 12);
        g.eyeHeight = 0.72f;
        g.terrainFn = [this](float x, float z) { return terrainHeight(x, z); };
        g.blockFn = [this](float x, float z) { return terrainHeight(x, z) < kWaterLevel + 1.0f; };   // the player cannot enter the water
        g.levelOverride = [this](Game& gg) { buildWorld(gg); };
        g.onLevelBuilt = [this](Game& gg) { afterLevelBuilt(gg); };
        load();
        applyGraphics();
    }

    // ---------------------------------------------------------------- graphics options
    void applyGraphics() {
        if (!gpu_) return;
        // Quality presets: low prioritizes battery/FPS, medium balances detail,
        // high uses full render resolution and a denser shadow map.
        int shadow = shadowsOn ? (preset == 2 ? 2048 : (preset == 1 ? 1536 : 768)) : 0;
        float renderScale = resPercent / 100.f;
        if (preset == 0) renderScale = std::min(renderScale, 0.60f);
        else if (preset == 1) renderScale = std::min(renderScale, 0.82f);
        else if (preset == 2) renderScale = std::max(renderScale, 1.0f);
        gpu_->setSettings(renderScale, shadow);
    }
    void setPreset(int p) {
        preset = p;
        resPercent = p == 0 ? 55 : (p == 1 ? 75 : 100);
        shadowsOn = p != 0;
        applyGraphics(); save();
    }

    // ---------------------------------------------------------------- saving
    void save() const {
        std::ofstream f(dataDir + "/axe_save.txt");
        f << std::setprecision(17);   // coins and the price multiplier can be huge: keep every digit
        f << "wood=" << wood << "\ncoins=" << coins << "\naxe=" << axeLevel << "\nstamina=" << staminaLevel << "\nlevel=" << level
          << "\nchopped=" << chopped << "\nworld2=" << (world2Owned ? 1 : 0) << "\nhighest=" << highestUnlockedLevel << "\npreset=" << preset << "\nres=" << resPercent
          << "\nshadows=" << (shadowsOn ? 1 : 0) << "\nauto=" << (autoAdjust ? 1 : 0) << "\nmaxwood=" << maxWoodLevel << "\nmult=" << multLevel
          << "\npricemult=" << woodPriceMult << "\nspins=" << spins << "\npending=" << pendingTier_ << "\n";
    }
    void load() {
        std::ifstream f(dataDir + "/axe_save.txt");
        std::string line;
        while (std::getline(f, line)) {
            size_t p = line.find('=');
            if (p == std::string::npos) continue;
            std::string k = line.substr(0, p);
            const double dv = std::atof(line.c_str() + p + 1);                              // coins and the price multiplier are big numbers
            const int v = (int)std::max(-2147483647.0, std::min(2147483647.0, dv));         // everything else is a small whole number
            if (k == "wood") wood = std::max(0, v); else if (k == "coins") coins = dv > 0.0 ? std::min(dv, 1e300) : 0.0;
            else if (k == "axe") axeLevel = std::max(1, v);
            else if (k == "stamina") staminaLevel = std::max(1, v); else if (k == "level") level = std::max(1, std::min(10, v));
            else if (k == "chopped") chopped = v; else if (k == "world2") world2Owned = v != 0; else if (k == "highest") highestUnlockedLevel = std::max(1, std::min(10, v));
            else if (k == "preset") preset = std::max(0, std::min(3, v)); else if (k == "res") resPercent = std::max(30, std::min(125, v));
            else if (k == "shadows") shadowsOn = v != 0; else if (k == "auto") autoAdjust = v != 0;
            else if (k == "maxwood") maxWoodLevel = std::max(1, v); else if (k == "mult") multLevel = std::max(0, v);
            else if (k == "pricemult") woodPriceMult = dv >= 1.0 ? std::min(dv, 10000.0) : 1.0;   // x10000 is the biggest the spinner can give
            else if (k == "spins") spins = std::max(0, v);
            else if (k == "pending") pendingTier_ = (v >= 0 && v < kSpinTiers) ? v : -1;
        }
        if (pendingTier_ >= 0) { applySpin(pendingTier_); pendingTier_ = -1; }   // the game closed in the middle of a spin: give the result now
        highestUnlockedLevel = std::max(highestUnlockedLevel, world2Owned ? 2 : 1);
        if (level > highestUnlockedLevel) level = highestUnlockedLevel;
        stamina = maxStamina();
    }

    // ---------------------------------------------------------------- the world
    void buildWorld(Game& g) {
        Scene& sc = g.scene;
        trees_.clear(); held_ = nullptr;
        rng_ = 987654u + (uint32_t)level * 7919u;
        panel_ = P_NONE; swingT_ = -1.f; nearby_ = 0;

        Entity* ground = sc.add("ground", nullptr, Vec3(0, 0, 0), Vec3(1, 1, 1), (level==2 ? Color{1.0f,0.85f,0.6f} : level==3 ? Color{0.72f,0.88f,1.2f} : level==4 ? Color{1.2f,0.88f,0.58f} : level==5 ? Color{0.78f,0.92f,1.08f} : level==6 ? Color{1.18f,0.62f,0.38f} : level==7 ? Color{0.55f,1.12f,0.62f} : level==8 ? Color{0.65f,0.82f,1.22f} : level==9 ? Color{1.18f,1.02f,0.62f} : level==10 ? Color{0.78f,0.92f,1.25f} : Color{0.70f,1.15f,0.95f}));
        ground->meshId = terrainId_[(level - 1) % 2];
        ground->pattern = groundTex_ >= 0 ? 4 : 1;
        ground->tex = groundTex_;
        ground->roughness = 0.95f;
        Entity* water = sc.add("water", &waterMesh_, Vec3(0, kWaterLevel, 0), Vec3(1, 1, 1), Color{1, 1, 1});   // the sea around the island
        water->pattern = 5; water->roughness = 0.06f;
        Entity* fence = sc.add("fence", nullptr, Vec3(0, 0, 0), Vec3(1, 1, 1), Color{0.55f, 0.36f, 0.22f});    // the border of the island
        fence->meshId = fenceId_[(level - 1) % 2]; fence->pattern = 3; fence->roughness = 0.8f;
        const float e = 128.5f;                                                                           // invisible walls at the edge
        const Vec3 wp[4] = {{0, 20, -e}, {0, 20, e}, {-e, 20, 0}, {e, 20, 0}}, ws[4] = {{260, 60, 1}, {260, 60, 1}, {1, 60, 260}, {1, 60, 260}};
        for (int i = 0; i < 4; i++) { Entity* w = sc.add("wall", &cubeMesh_, wp[i], ws[i], Color{1, 1, 1}); w->solid = true; w->visible = false; }

        // food stall (the shop): its counter faces the start point
        Entity* stall = sc.add("stall", nullptr, Vec3(kStallX, 0, kStallZ), Vec3(1, 1, 1), Color{1, 1, 1});
        stall->model = stallId_; stall->rot.y = -PI / 2;
        Entity* stallBox = sc.add("stallbox", &cubeMesh_, Vec3(kStallX, 1.7f, kStallZ), Vec3(3.7f, 3.4f, 2.4f), Color{1, 1, 1});
        stallBox->solid = true; stallBox->visible = false;

        // travel port: a wooden gate with a glowing portal
        const Color wood3{0.55f, 0.36f, 0.22f};
        Entity* p1 = sc.add("post", &cubeMesh_, Vec3(kPortX, 2.1f, kPortZ - 1.8f), Vec3(0.5f, 4.2f, 0.5f), wood3);
        Entity* p2 = sc.add("post", &cubeMesh_, Vec3(kPortX, 2.1f, kPortZ + 1.8f), Vec3(0.5f, 4.2f, 0.5f), wood3);
        Entity* beam = sc.add("beam", &cubeMesh_, Vec3(kPortX, 4.45f, kPortZ), Vec3(0.7f, 0.5f, 4.8f), wood3);
        p1->solid = p2->solid = true; p1->pattern = p2->pattern = beam->pattern = 3;
        Entity* portal = sc.add("portal", &cubeMesh_, Vec3(kPortX, 2.0f, kPortZ), Vec3(0.1f, 3.6f, 3.2f), level % 2 == 0 ? Color{0.3f, 0.95f, 0.5f} : Color{0.2f, 0.9f, 0.95f});
        portal->unlit = true;

        const int count = 45;   // exactly 45 harvestable trees per level
        for (int i = 0; i < count; i++) {
            float x, z;
            if (!pickSpot(x, z, -1, false)) break;
            addTree(sc, x, z);
        }
        // Dense, deterministic ground dressing. These are decorative only: they
        // do not block movement or interfere with chopping/collision.
        // Keep the spawn, shop and portal clear so the first-person view stays readable.
        for (int i = 0; i < 190; ++i) {
            float x = (rand01() * 2.f - 1.f) * 111.f;
            float z = (rand01() * 2.f - 1.f) * 111.f;
            if (terrainHeight(x, z) < kWaterLevel + 1.4f) continue;
            if (hdist(x,z,0.f,12.f) < 10.f || hdist(x,z,kStallX,kStallZ) < 9.f || hdist(x,z,kPortX,kPortZ) < 8.f) continue;
            bool nearTree = false;
            for (const auto& tr : trees_) if (tr.state != 2 && hdist(x,z,tr.x,tr.z) < 3.2f) { nearTree = true; break; }
            if (nearTree) continue;
            const float y = terrainHeight(x,z);
            const float r = rand01();
            if (r < 0.48f) {
                // Three low-poly grass blades in varied greens.
                Entity* a = sc.add("grass_tuft", &grassBladeMesh_, Vec3(x,y,z), Vec3(.55f+rand01()*.5f,.55f+rand01()*.8f,.55f+rand01()*.5f),
                    level == 2 ? Color{0.54f+rand01()*.16f,0.48f+rand01()*.12f,0.20f} : Color{0.28f+rand01()*.16f,0.58f+rand01()*.20f,0.18f+rand01()*.08f});
                a->roughness = 0.94f;
            } else if (r < 0.70f) {
                Entity* a = sc.add("mossy_rock", &rockMesh_, Vec3(x,y+.20f,z), Vec3(.35f+rand01()*.65f,.22f+rand01()*.35f,.35f+rand01()*.6f),
                    Color{.38f+rand01()*.18f,.39f+rand01()*.17f,.36f+rand01()*.18f});
                a->roughness = .96f;
            } else if (r < 0.87f) {
                Entity* a = sc.add("wild_bush", &bushMesh_, Vec3(x,y+.34f,z), Vec3(.45f+rand01()*.55f,.35f+rand01()*.35f,.45f+rand01()*.55f),
                    level == 2 ? Color{.40f,.36f,.16f} : Color{.12f+rand01()*.08f,.34f+rand01()*.12f,.12f+rand01()*.06f});
                a->roughness = .9f;
            } else {
                Entity* a = sc.add("wildflower", &flowerMesh_, Vec3(x,y+.20f,z), Vec3(.10f+rand01()*.10f,.12f+rand01()*.14f,.10f+rand01()*.10f),
                    rand01() < .5f ? Color{.95f,.34f,.20f} : Color{.98f,.78f,.28f});
                a->roughness = .72f;
            }
        }
        // the axe in the player's hands (moved every frame to stay in front of the camera)
        held_ = sc.add("held_axe", nullptr, Vec3(0, 0, 0), Vec3(1, 1, 1), Color{1, 1, 1});
        held_->model = axeId_; held_->useMatrix = true;
    }
    void afterLevelBuilt(Game& g) {   // the player is only a tall collision box: it is never drawn and casts no shadow
        Entity* p = g.player;
        p->scale = Vec3(0.7f, 1.7f, 0.7f);
        p->half = p->scale * 0.5f;
        p->pos = g.playerStart;
        p->visible = false;
    }

    // ---------------------------------------------------------------- every frame
    void update(float dt, double now) {
        if (!game_ || !ui_ || !game_->player) return;
        Game& g = *game_;
        g.firstPerson = true;   // there is no third-person view in this game
        time_ = now;
        handleTaps();
        const bool menu = panel_ != P_NONE;
        ui_->capture = menu;
        if (menu) { g.padMove = g.padStrafe = g.padTurn = 0; }

        Vec3 pp = g.player->pos;
        nearby_ = 0;
        if (hdist(pp.x, pp.z, kStallX, kStallZ) < 4.6f) nearby_ = 1;
        else if (hdist(pp.x, pp.z, kPortX, kPortZ) < 4.4f) nearby_ = 2;
        ui_->useVisible = nearby_ != 0 && !menu;
        ui_->useLabel = nearby_ == 2 ? "PORT" : "SHOP";

        if (!menu) {
            if (g.input.pressed('o')) openPanel(P_OPTIONS);
            else if (g.input.pressed('e') && nearby_ != 0) openPanel(nearby_ == 1 ? P_SHOP : P_PORT);
            else if (g.input.pressed('f')) startSwing();
        }
        idle_ += dt;
        if (swingT_ < 0 && idle_ > 0.6f) stamina = std::min(maxStamina(), stamina + 10.f * dt);
        stamina = std::min(stamina, maxStamina());
        if (tiredT_ > 0) tiredT_ -= dt;
        if (toastT_ > 0) toastT_ -= dt;
        if (spinning_) { spinT_ += dt; if (spinT_ >= kSpinTime) finishSpin(); }   // the price spinner keeps running even if the menu is closed
        if (swingT_ >= 0) {
            swingT_ += dt;
            if (!swingHit_ && swingT_ >= 0.24f) { swingHit_ = true; playerHit(); }
            if (swingT_ >= 0.45f) swingT_ = -1.f;
        }
        updateTrees(dt);
        autoTune(dt);
        saveT_ += dt;
        if (saveT_ > 20.f) { saveT_ = 0; save(); }
        layoutPanel();
    }

    // Call after the camera is final for this frame: puts the axe in the hands.
    void lateUpdate() { if (game_) updateHeld(*game_); }

    // ---------------------------------------------------------------- drawing (HUD and menus)
    void drawUI(GpuCanvas& cv) {
        if (!game_ || !ui_) return;
        cv.font = font.ok() ? &font : nullptr;
        const float W = (float)ui_->w, H = (float)ui_->h;
        const Color white{1, 1, 1}, gold{1.f, 0.85f, 0.4f};
        UiText::draw(cv, "WOOD " + num(wood), 6, 2, 2, gold);
        UiText::draw(cv, "COINS " + num(coins), 6, 15, 2, Color{1.f, 0.95f, 0.6f});
        float bw = 90, bx = W * 0.5f - bw / 2, fr = clampf(stamina / maxStamina(), 0.f, 1.f);
        cv.rect(bx - 1, 3, bw + 2, 8, Color{0, 0, 0}, 0.5f);
        cv.rect(bx, 4, bw * fr, 6, fr > 0.25f ? Color{0.4f, 0.9f, 0.4f} : Color{0.95f, 0.4f, 0.3f}, 0.9f);
        UiText::draw(cv, "LEVEL " + std::to_string(level) + "  " + biomeName(level) + "  " + std::to_string(biomeTemp(level)) + " C", W * 0.5f, 12, 1, Color{0.85f, 0.93f, 1.f}, 1, 0.9f);
        if (tiredT_ > 0) UiText::draw(cv, "TIRED!", W * 0.5f, H * 0.33f, 2, Color{1.f, 0.5f, 0.4f}, 1);
        if (toastT_ > 0) UiText::draw(cv, toast_, W * 0.5f, H * 0.42f - (1.5f - toastT_) * 8.f, 2, gold, 1, clampf(toastT_, 0.f, 1.f));
        UiText::draw(cv, std::to_string((int)(fps + 0.5f)), 6, H - 10, 1, Color{0.7f, 0.7f, 0.7f});
        if (panel_ == P_NONE) cv.rect(W * 0.5f - 1, H * 0.5f - 1, 2, 2, white, 0.8f);   // crosshair
        if (panel_ != P_NONE) drawPanel(cv);
    }

    // ---------------------------------------------------------------- test helpers (read-only views)
    int treeTotal() const { return (int)trees_.size(); }
    int treesStanding() const { int n = 0; for (auto& t : trees_) if (t.state == 0) n++; return n; }
    Vec3 treePos(int i) const { return Vec3(trees_[i].x, terrainHeight(trees_[i].x, trees_[i].z), trees_[i].z); }
    int treeState(int i) const { return trees_[i].state; }
    float treeHp(int i) const { return trees_[i].hp; }
    Panel panel() const { return panel_; }
    const std::vector<PBtn>& panelButtons() const { return pbtns_; }

private:
    struct TreeInfo { Entity* vis = nullptr; Entity* col = nullptr; float x = 0, z = 0, h = 9, hp = 100, shake = 0, fall = 0, yaw = 0, respawn = 0; int state = 0; };   // state: 0 standing, 1 falling, 2 gone
    static constexpr float kStallX = 6.f, kStallZ = 3.f, kPortX = -9.f, kPortZ = 3.f, kSwingCost = 6.f;
    Game* game_ = nullptr; TouchUI* ui_ = nullptr; GpuRenderer* gpu_ = nullptr;
    ModelData axe_, stall_, pine_;
    MeshData terrainData_[2], fenceData_[2];
    int axeId_ = -1, stallId_ = -1, pineId_ = -1, groundTex_ = -1, terrainId_[2] = {-1, -1}, fenceId_[2] = {-1, -1};
    Mesh cubeMesh_ = Shapes::cube(), waterMesh_ = Shapes::ground(1, 2400.f, Vec3(1, 1, 1), Vec3(1, 1, 1));
    Mesh grassBladeMesh_ = Shapes::pyramid(), rockMesh_ = Shapes::sphere(7), bushMesh_ = Shapes::sphere(8), flowerMesh_ = Shapes::sphere(7);
    std::vector<TreeInfo> trees_;
    Entity* held_ = nullptr;
    uint32_t rng_ = 1;
    double time_ = 0;
    float swingT_ = -1.f, idle_ = 0, tiredT_ = 0, toastT_ = 0, saveT_ = 0, tuneT_ = 0;
    int tuneFrames_ = 0, slowWindows_ = 0, shopTab_ = 0;   // shopTab_: 0 = sell, 1 = upgrades, 2 = price spin
    bool swingHit_ = false;
    int nearby_ = 0;
    std::string toast_;
    Panel panel_ = P_NONE;
    std::vector<PBtn> pbtns_;

    static float hdist(float ax, float az, float bx, float bz) { return std::sqrt((ax - bx) * (ax - bx) + (az - bz) * (az - bz)); }
    float rand01() { rng_ = rng_ * 1664525u + 1013904223u; return (float)((rng_ >> 8) & 0xFFFFFF) / 16777216.f; }
    void say(const std::string& s) { toast_ = s; toastT_ = 1.5f; }

    // ---------------------------------------------------------------- the wood-price spinner (3rd tab of the shop)
    // A strip of tiles slides past a marker and slows down until it stops on the result. The result is drawn by the
    // weights in game_numbers.h (x1.5 is common, x10000 is 1 spin in 2000). The wood price becomes whatever it lands on:
    // the newest spin REPLACES the old multiplier (x10 then x2 = x2), so a spin can also lower the price.
    static constexpr int kReelLen = 40, kReelStop = 30;    // 40 tiles; the spin always ends on tile 30
    static constexpr float kTileW = 44.f, kTileGap = 4.f, kSpinTime = 2.6f;
    bool spinning_ = false, reelDone_ = false;
    float spinT_ = 0.f;
    int spinTier_ = 0;                                     // which multiplier this spin lands on
    int pendingTier_ = -1;                                 // saved while a spin runs, so closing the game mid-spin loses nothing
    int reel_[kReelLen] = {};                              // the tile shown at each place on the strip
    std::mt19937 spinRng_{makeSeed()};                     // its own random numbers: the spinner is never the same twice
    static uint32_t makeSeed() {
        uint32_t seed = (uint32_t)std::chrono::steady_clock::now().time_since_epoch().count();
        try { std::random_device rd; seed ^= rd(); } catch (...) {}
        return seed ^ 0x9E3779B9u;
    }
    void startSpin() {
        if (spinning_) return;
        spinTier_ = rollSpinTier(spinRng_);
        for (int i = 0; i < kReelLen; i++) reel_[i] = std::uniform_int_distribution<int>(0, kSpinTiers - 1)(spinRng_);   // the tiles flying past
        reel_[kReelStop] = spinTier_;                                                                                     // the one it stops on
        spinning_ = true; reelDone_ = false; spinT_ = 0.f;
        pendingTier_ = spinTier_;
    }
    void applySpin(int tier) {   // the wood price becomes what the spin landed on (it replaces the old one), and the next spin costs more
        woodPriceMult = spinTiers()[tier].mult;
        spins++;
    }
    void finishSpin() {
        spinning_ = false; reelDone_ = true;
        applySpin(spinTier_);
        pendingTier_ = -1;
        say("WOOD PRICE X" + num(spinTiers()[spinTier_].mult) + "!");
        save();
    }
    float reelScroll() const {   // how far the strip has slid (it slows down smoothly)
        const float pitch = kTileW + kTileGap;
        if (spinning_) { const float t = clampf(spinT_ / kSpinTime, 0.f, 1.f), k = 1.f - t; return (1.f - k * k * k * k) * kReelStop * pitch; }
        return reelDone_ ? kReelStop * pitch : 0.f;
    }
    static Color tierColor(int i) {   // the rarer, the hotter
        if (i <= 3) return Color{0.25f, 0.36f, 0.52f};
        if (i <= 6) return Color{0.18f, 0.50f, 0.30f};
        if (i <= 8) return Color{0.20f, 0.40f, 0.80f};
        if (i <= 10) return Color{0.50f, 0.28f, 0.75f};
        if (i <= 12) return Color{0.85f, 0.50f, 0.12f};
        return Color{0.90f, 0.20f, 0.25f};
    }

    // The hills as a mesh: 96 x 96 squares with smooth normals.
    static MeshData makeTerrain(int lv) {
        const int cells = 96, n = cells + 1;
        const float half = 128.f, eps = 1.f;
        MeshData d;
        d.v.reserve((size_t)n * n * 8);
        for (int j = 0; j < n; j++)
            for (int i = 0; i < n; i++) {
                float x = -half + 2 * half * i / cells, z = -half + 2 * half * j / cells;
                float y = terrainHeightFor(lv, x, z);
                float hx = terrainHeightFor(lv, x + eps, z) - terrainHeightFor(lv, x - eps, z), hz = terrainHeightFor(lv, x, z + eps) - terrainHeightFor(lv, x, z - eps);
                Vec3 nr = normalize(Vec3(-hx / (2 * eps), 1.f, -hz / (2 * eps)));
                d.v.insert(d.v.end(), {x, y, z, nr.x, nr.y, nr.z, 0.f, 0.f});
            }
        for (int j = 0; j < cells; j++)
            for (int i = 0; i < cells; i++) {
                uint32_t a = (uint32_t)(j * n + i), b = a + 1, c = a + (uint32_t)n, e = c + 1;
                d.idx.insert(d.idx.end(), {a, c, b, b, c, e});
            }
        return d;
    }

    // A thin box from a to b (used to build the fence in one mesh).
    static void addBeam(MeshData& d, const Vec3& a, const Vec3& b, float t) {
        Vec3 dir = normalize(b - a);
        Vec3 ref = std::fabs(dir.y) > 0.9f ? Vec3(1, 0, 0) : Vec3(0, 1, 0);
        Vec3 r = normalize(cross(dir, ref)) * t, u = normalize(cross(r, dir)) * t, c[8];
        for (int i = 0; i < 8; i++) c[i] = ((i & 1) ? b : a) + ((i & 2) ? r : -r) + ((i & 4) ? u : -u);
        static const int faces[6][4] = {{0, 2, 6, 4}, {1, 5, 7, 3}, {0, 4, 5, 1}, {2, 3, 7, 6}, {0, 1, 3, 2}, {4, 6, 7, 5}};
        const Vec3 mid = (a + b) * 0.5f;
        for (auto& f : faces) {
            Vec3 tn = cross(c[f[1]] - c[f[0]], c[f[2]] - c[f[0]]);
            Vec3 center = (c[f[0]] + c[f[1]] + c[f[2]] + c[f[3]]) * 0.25f;
            bool flip = dot(tn, center - mid) < 0;
            Vec3 n = normalize(flip ? -tn : tn);
            uint32_t base = (uint32_t)(d.v.size() / 8);
            for (int k = 0; k < 4; k++) d.v.insert(d.v.end(), {c[f[k]].x, c[f[k]].y, c[f[k]].z, n.x, n.y, n.z, 0.f, 0.f});
            if (!flip) d.idx.insert(d.idx.end(), {base, base + 1, base + 2, base, base + 2, base + 3});
            else d.idx.insert(d.idx.end(), {base, base + 2, base + 1, base, base + 3, base + 2});
        }
    }
    // The fence around the island: posts and two rails, all in ONE mesh (one draw call).
    static MeshData makeFence(int lv) {
        MeshData d;
        const int N = 240;
        std::vector<Vec3> pts;
        for (int i = 0; i < N; i++) {
            float th = 2 * PI * i / N, dx = std::cos(th), dz = std::sin(th), r = 20.f;
            while (r < 200.f && terrainHeightFor(lv, dx * r, dz * r) > kFenceHeight) r += 0.5f;   // walk outward until the ground drops to the fence line
            pts.push_back(Vec3(dx * r, 0.f, dz * r));
        }
        for (auto& p : pts) p.y = terrainHeightFor(lv, p.x, p.z);
        for (int i = 0; i < N; i++) {
            const Vec3 a = pts[i], b = pts[(i + 1) % N];
            addBeam(d, a, a + Vec3(0, 1.4f, 0), 0.10f);                          // post
            addBeam(d, a + Vec3(0, 0.55f, 0), b + Vec3(0, 0.55f, 0), 0.05f);     // lower rail
            addBeam(d, a + Vec3(0, 1.05f, 0), b + Vec3(0, 1.05f, 0), 0.05f);     // upper rail
        }
        return d;
    }

    // ---- trees ----
    bool pickSpot(float& x, float& z, int ignore, bool avoidPlayer) {
        for (int tries = 0; tries < 500; tries++) {
            float px = (rand01() * 2 - 1) * kWorldHalf, pz = (rand01() * 2 - 1) * kWorldHalf;
            if (islandR(px, pz) > 0.74f) continue;   // stay off the beach
            if (hdist(px, pz, 0, 12) < 14.f || hdist(px, pz, kStallX, kStallZ) < 8.f || hdist(px, pz, kPortX, kPortZ) < 8.f) continue;
            if (avoidPlayer && game_ && game_->player && hdist(px, pz, game_->player->pos.x, game_->player->pos.z) < 12.f) continue;
            bool ok = true;
            for (int j = 0; j < (int)trees_.size(); j++) {
                if (j == ignore || trees_[j].state == 2) continue;
                if (hdist(px, pz, trees_[j].x, trees_[j].z) < 6.5f) { ok = false; break; }
            }
            if (ok) { x = px; z = pz; return true; }
        }
        return false;
    }
    void addTree(Scene& sc, float x, float z) {
        TreeInfo t;
        t.x = x; t.z = z; t.h = 7.5f + rand01() * 3.5f; t.hp = 100.f * level;
        float s = t.h / 9.f, gy = terrainHeight(x, z);
        t.vis = sc.add("tree", nullptr, Vec3(x, gy, z), Vec3(s, s, s), Color{1, 1, 1});
        t.vis->model = pineId_; t.vis->rot.y = rand01() * 6.28f; t.vis->roughness = 0.9f;
        t.col = sc.add("treecol", &cubeMesh_, Vec3(x, gy + t.h / 2, z), Vec3(0.9f, t.h, 0.9f), Color{1, 1, 1});
        t.col->solid = true; t.col->visible = false;
        trees_.push_back(t);
    }
    void hitTree(int i, float dmg, const Vec3& from) {
        TreeInfo& t = trees_[i];
        if (t.state != 0) return;
        t.hp -= dmg; t.shake = 0.35f;
        if (t.hp > 0) return;
        t.state = 1; t.fall = 0;
        t.yaw = std::atan2(t.x - from.x, t.z - from.z);   // falls away from the player
        t.col->solid = false;
        int gain = rollWood();
        wood += gain; chopped++;
        say("+" + num(gain) + " WOOD  | TREE HP " + num(100.0 * level));
    }
    void updateTrees(float dt) {
        for (int i = 0; i < (int)trees_.size(); i++) {
            TreeInfo& t = trees_[i];
            if (t.state == 0) {
                if (t.shake > 0) { t.shake -= dt * 1.4f; t.vis->rot.z = std::sin((float)time_ * 45.f) * 0.05f * std::max(0.f, t.shake); }
                else t.vis->rot.z = 0;
            } else if (t.state == 1) {
                t.fall += dt;
                float k = t.fall / 1.5f;
                t.vis->rot.y = t.yaw; t.vis->rot.z = 0;
                t.vis->rot.x = std::min(1.5f, k * k * 1.55f);
                if (t.fall >= 1.8f) { t.state = 2; t.vis->visible = false; t.respawn = 35.f; }
            } else {
                t.respawn -= dt;
                if (t.respawn <= 0) {
                    float x, z;
                    if (pickSpot(x, z, i, true)) {
                        float s = t.h / 9.f, gy = terrainHeight(x, z);
                        t.x = x; t.z = z; t.hp = 100.f * level; t.state = 0; t.shake = 0;
                        t.vis->pos = Vec3(x, gy, z); t.vis->rot = Vec3(0, rand01() * 6.28f, 0); t.vis->scale = Vec3(s, s, s); t.vis->visible = true;
                        t.col->pos = Vec3(x, gy + t.h / 2, z); t.col->solid = true;
                    } else t.respawn = 5.f;
                }
            }
        }
    }

    // ---- the player's axe ----
    void startSwing() {
        if (swingT_ >= 0) return;
        if (stamina < kSwingCost) { tiredT_ = 1.2f; return; }
        stamina -= kSwingCost; swingT_ = 0; swingHit_ = false; idle_ = 0;
    }
    void playerHit() {
        Game& g = *game_;
        Vec3 p = g.player->pos;
        float fx = std::sin(g.yaw), fz = -std::cos(g.yaw);
        int best = -1; float bd = 1e9f;
        for (int i = 0; i < (int)trees_.size(); i++) {
            if (trees_[i].state != 0) continue;
            float dx = trees_[i].x - p.x, dz = trees_[i].z - p.z, d = std::sqrt(dx * dx + dz * dz);
            if (d > 3.1f || d < 0.01f) continue;
            if ((dx * fx + dz * fz) / d < 0.72f) continue;   // must be in front of you
            if (d < bd) { bd = d; best = i; }
        }
        if (best >= 0) hitTree(best, axeDamage(), p);
    }
    float swingAngle() const {   // radians about the camera's right axis; negative = head swings forward and down
        if (swingT_ < 0) return 0.f;
        auto sm = [](float x) { x = clampf(x, 0.f, 1.f); return x * x * (3.f - 2.f * x); };
        float t = swingT_;
        if (t < 0.12f) return lerpf(0.f, 0.6f, sm(t / 0.12f));
        if (t < 0.26f) return lerpf(0.6f, -1.35f, sm((t - 0.12f) / 0.14f));
        return lerpf(-1.35f, 0.f, sm((t - 0.26f) / 0.19f));
    }
    void updateHeld(Game& g) {
        if (!held_) return;
        held_->visible = g.firstPerson && axeId_ >= 0;
        const Vec3 f = g.cam.forward(), r = normalize(cross(f, Vec3(0, 1, 0))), u = cross(r, f);
        auto rot = [](const Vec3& v, const Vec3& k, float a) { float c = std::cos(a), s = std::sin(a); return v * c + cross(k, v) * s + k * (dot(k, v) * (1.f - c)); };
        const float sw = swingAngle(), pitch = -0.20f + sw, roll = -0.35f;
        Vec3 ax = -u, ay = -r, az = f;   // the axe's own directions (handle = x, face = y, blade side = z) as seen from the camera
        ax = rot(rot(ax, r, pitch), f, roll); ay = rot(rot(ay, r, pitch), f, roll); az = rot(rot(az, r, pitch), f, roll);
        const Vec3 shoulder = g.cam.pos + r * 0.36f - u * 0.66f - f * 0.10f;
        const Vec3 hand0 = g.cam.pos + r * 0.40f - u * 0.40f + f * 0.74f;
        const Vec3 hand = shoulder + rot(hand0 - shoulder, r, sw);
        const float s = 0.32f;
        const Vec3 grip(0.5f, 0.f, -0.2f);   // where the hand holds the handle (axe model units)
        const Vec3 off = hand - (ax * (s * grip.x) + ay * (s * grip.y) + az * (s * grip.z));
        Mat4 m;
        m.m[0][0] = ax.x * s; m.m[1][0] = ax.y * s; m.m[2][0] = ax.z * s;
        m.m[0][1] = ay.x * s; m.m[1][1] = ay.y * s; m.m[2][1] = ay.z * s;
        m.m[0][2] = az.x * s; m.m[1][2] = az.y * s; m.m[2][2] = az.z * s;
        m.m[0][3] = off.x; m.m[1][3] = off.y; m.m[2][3] = off.z;
        held_->customMatrix = m;
    }

    // Too slow for a few seconds? Switch shadows off first, then lower the resolution (only if "auto adjust" is on).
    void autoTune(float dt) {
        if (!autoAdjust || !gpu_ || time_ < 6.0 || panel_ != P_NONE) { tuneT_ = 0; tuneFrames_ = 0; return; }
        tuneT_ += dt; tuneFrames_++;
        if (tuneT_ < 2.5f) return;
        float f = tuneFrames_ / tuneT_;
        tuneT_ = 0; tuneFrames_ = 0;
        slowWindows_ = f < 22.f ? slowWindows_ + 1 : 0;
        if (slowWindows_ < 2) return;
        slowWindows_ = 0;
        if (shadowsOn) shadowsOn = false; else if (resPercent > 40) resPercent -= 10; else return;
        preset = 3; applyGraphics(); say("GRAPHICS LOWERED");
    }

    // ---- menus ----
    void openPanel(Panel p) { panel_ = p; shopTab_ = 0; ui_->releaseAll(); ui_->capture = true; layoutPanel(); }   // taps go to the menu right away
    void layoutPanel() {
        pbtns_.clear();
        if (panel_ == P_NONE || !ui_) return;
        const float W = (float)ui_->w, H = (float)ui_->h;
        const float px = W * 0.5f - 130, py = 6, pw = 260, ph = H - 12, iw = pw - 20;
        auto add = [&](float x, float y, float w, float h, const std::string& l, int id, bool on = false) { pbtns_.push_back({x, y, w, h, l, id, on}); };
        if (panel_ == P_SHOP) {
            const float tw = (iw - 8) / 3;
            add(px + 10, py + 22, tw, 18, "SELL", 60, shopTab_ == 0);
            add(px + 14 + tw, py + 22, tw, 18, "UPGRADES", 61, shopTab_ == 1);
            add(px + 18 + 2 * tw, py + 22, tw, 18, "PRICE SPIN", 62, shopTab_ == 2);
            if (shopTab_ == 0) {
                add(px + 10, py + 58, iw, 24, "SELL 1 WOOD  +" + num(woodPrice()), 4);
                add(px + 10, py + 88, iw, 24, "SELL ALL WOOD  +" + num(wood * woodPrice()), 1);
            } else if (shopTab_ == 1) {
                add(px + 10, py + 52, iw, 20, "AXE LV " + std::to_string(axeLevel) + " > " + std::to_string(axeLevel + 1) + "   COST " + num(axeCost()), 2);
                add(px + 10, py + 77, iw, 20, "STAMINA LV " + std::to_string(staminaLevel) + " > " + std::to_string(staminaLevel + 1) + "   COST " + num(staminaCost()), 3);
                add(px + 10, py + 102, iw, 20, "MAX WOOD " + num(maxWood()) + " > " + num(maxWood() + 2) + "   COST " + num(maxWoodCost()), 5);
                add(px + 10, py + 127, iw, 20, "WOOD MULT X" + num(woodMultiplier()) + " > X" + num(woodMultiplier()*1.5) + "   COST " + num(multCost()), 6);
            } else {
                add(px + 10, py + 92, iw, 20, spinning_ ? std::string("SPINNING...") : "SPIN  COST " + num(spinCost()), 70, spinning_);
            }
            add(px + 10, py + ph - 24, iw, 20, "CLOSE", 99);
        } else if (panel_ == P_PORT) {
            const float gap = 6.f, bw = (iw - gap) / 2.f;
            for (int lv = 1; lv <= 10; ++lv) {
                int col = (lv - 1) % 2, row = (lv - 1) / 2;
                std::string label = "LV" + std::to_string(lv) + " " + biomeName(lv);
                if (lv > highestUnlockedLevel) label += " " + num(levelPrice(lv));
                add(px + 10 + col * (bw + gap), py + 40 + row * 31, bw, 26, label, 10 + lv, level == lv);
            }
            add(px + 10, py + ph - 28, iw, 22, "CLOSE", 99);
        } else {   // options: the full names of everything
            const float third = (iw - 8) / 3, half = (iw - 4) / 2;
            add(px + 10, py + 52, third, 20, "LOW", 41, preset == 0); add(px + 14 + third, py + 52, third, 20, "MEDIUM", 42, preset == 1); add(px + 18 + 2 * third, py + 52, third, 20, "HIGH", 43, preset == 2);
            add(px + 10, py + 78, 40, 20, "-", 44); add(px + pw - 50, py + 78, 40, 20, "+", 45);
            add(px + 10, py + 104, half, 20, shadowsOn ? "SHADOWS: ON" : "SHADOWS: OFF", 46); add(px + 14 + half, py + 104, half, 20, autoAdjust ? "AUTO LOWER: ON" : "AUTO LOWER: OFF", 47);
            add(px + 10, py + 130, iw, 20, "RESTART WORLD", 48);
            add(px + 10, py + ph - 22, iw, 18, "CLOSE", 99);
        }
    }
    void handleTaps() {
        if (!ui_) return;
        auto taps = ui_->taps;
        ui_->taps.clear();
        for (auto& t : taps) {
            if (panel_ == P_NONE) break;
            layoutPanel();
            for (const PBtn& b : pbtns_)
                if (t.first >= b.x && t.first <= b.x + b.w && t.second >= b.y && t.second <= b.y + b.h) { onPanelButton(b.id); break; }
        }
    }
    void goToWorld(int to) {
        to = std::max(1, std::min(10, to));
        if (to > highestUnlockedLevel) {
            double cost = levelPrice(to);
            if (to != highestUnlockedLevel + 1) { say("UNLOCK THE PREVIOUS LEVEL FIRST"); return; }
            if (coins < cost) { say("NEED " + num(cost) + " COINS"); return; }
            coins -= cost; highestUnlockedLevel = to; world2Owned = highestUnlockedLevel >= 2;
        }
        panel_ = P_NONE;
        if (to == level) { save(); return; }
        level = to; save(); game_->buildLevel(); say(std::string("WELCOME TO ") + biomeName(level));
    }
    void onPanelButton(int id) {
        if (id == 99) { panel_ = P_NONE; save(); return; }
        if (id == 1) { coins = capNum(coins + wood * woodPrice()); if (wood > 0) say("SOLD!"); wood = 0; save(); }
        else if (id == 2) { if (coins >= axeCost()) { coins -= axeCost(); axeLevel++; say("AXE UPGRADED"); save(); } else say("NOT ENOUGH COINS"); }
        else if (id == 3) { if (coins >= staminaCost()) { coins -= staminaCost(); staminaLevel++; stamina = maxStamina(); say("MORE STAMINA"); save(); } else say("NOT ENOUGH COINS"); }
        else if (id == 4) { if (wood > 0) { wood--; coins = capNum(coins + woodPrice()); save(); } else say("NO WOOD"); }
        else if (id == 5) { if (maxWoodLevel >= 25) say("ALREADY MAX"); else if (coins >= maxWoodCost()) { coins -= maxWoodCost(); maxWoodLevel++; say("MAX WOOD UP"); save(); } else say("NOT ENOUGH COINS"); }
        else if (id == 6) { if (multLevel >= 10) say("ALREADY MAX"); else if (coins >= multCost()) { coins -= multCost(); multLevel++; say("WOOD MULTIPLIER UP"); save(); } else say("NOT ENOUGH COINS"); }
        else if (id >= 60 && id <= 62) shopTab_ = id - 60;
        else if (id == 70) {          // SPIN: costs coins, and the price rises with every spin
            if (spinning_) {}
            else if (coins >= spinCost()) { coins -= spinCost(); startSpin(); save(); }
            else say("NOT ENOUGH COINS");
        }
        else if (id >= 11 && id <= 20) goToWorld(id - 10);
        else if (id >= 41 && id <= 43) setPreset(id - 41);
        else if (id == 44 || id == 45) { resPercent = std::max(30, std::min(125, resPercent + (id == 45 ? 5 : -5))); preset = 3; applyGraphics(); save(); }
        else if (id == 46) { shadowsOn = !shadowsOn; preset = 3; applyGraphics(); save(); }
        else if (id == 47) { autoAdjust = !autoAdjust; save(); }
        else if (id == 48) { panel_ = P_NONE; game_->buildLevel(); say("WORLD RESTARTED"); }
        ui_->capture = panel_ != P_NONE;
        layoutPanel();
    }
    void drawPanel(GpuCanvas& cv) {
        const float W = (float)ui_->w, H = (float)ui_->h;
        const float px = W * 0.5f - 130, py = 6, pw = 260, ph = H - 12;
        const Color white{1, 1, 1}, gold{1.f, 0.85f, 0.4f}, soft{0.8f, 0.9f, 1.f};
        cv.rect(px, py, pw, ph, Color{0.04f, 0.06f, 0.09f}, 0.9f);
        UiText::draw(cv, panel_ == P_SHOP ? "FOOD STALL SHOP" : (panel_ == P_PORT ? "TRAVEL PORT" : "OPTIONS"), px + pw / 2, py + 3, 2, gold, 1);
        if (panel_ == P_SHOP) {
            UiText::draw(cv, "WOOD " + num(wood) + "   COINS " + num(coins), px + pw / 2, py + 42, 1, white, 1);
            if (shopTab_ == 0) {
                UiText::draw(cv, "EXTRA WOOD CHANCE " + std::to_string((int)(woodBonusChance() * 100 + 0.5f)) + "%   MULTIPLIER X" + multText(multLevel), px + pw / 2, py + 122, 1, soft, 1);
                UiText::draw(cv, "WOOD PER TREE UP TO " + std::to_string(maxWood()) + "   WORLD 2 = 10X WOOD", px + pw / 2, py + 132, 1, soft, 1);
            }
            if (shopTab_ == 2) drawSpin(cv, px, py, pw);
        }
        if (panel_ == P_PORT) {
            UiText::draw(cv, "COINS " + num(coins), px + pw / 2, py + 25, 1, white, 1);
            UiText::draw(cv, "LV " + std::to_string(level) + ": " + biomeName(level) + "  " + std::to_string(biomeTemp(level)) + " C", px + pw / 2, py + 112, 1, soft, 1);
            UiText::draw(cv, "WOOD REWARD X" + num(std::pow(10.0, level - 1)) + "  TREE HP " + num(100.0 * level), px + pw / 2, py + 124, 1, soft, 1);
        }
        if (panel_ == P_OPTIONS) {
            UiText::draw(cv, font.ok() ? "Made by Pranjal Nayak" : "MADE BY PRANJAL NAYAK", px + pw / 2, py + 30, 2, gold, 1);
            UiText::draw(cv, "RESOLUTION " + std::to_string(resPercent) + "%" + (resPercent == 100 ? "  FULL" : ""), px + pw / 2, py + 82, 1, white, 1);
        }
        for (const PBtn& b : pbtns_) {
            Color c = b.id == 99 ? Color{0.55f, 0.2f, 0.2f} : (b.on ? Color{0.85f, 0.6f, 0.15f} : Color{0.2f, 0.35f, 0.6f});
            cv.rect(b.x, b.y, b.w, b.h, c, 0.95f);
            int sc = (b.h >= 22 && UiText::width(b.label, 2) <= b.w - 6) ? 2 : 1;
            UiText::draw(cv, b.label, b.x + b.w / 2, b.y + b.h / 2 - 2.5f * sc, sc, white, 1);
        }
    }
    // The price-spinner tab: the sliding strip, the current price and the odds.
    void drawSpin(GpuCanvas& cv, float px, float py, float pw) {
        const Color white{1, 1, 1}, gold{1.f, 0.85f, 0.4f}, soft{0.8f, 0.9f, 1.f};
        const float wx = px + 10, wy = py + 52, ww = pw - 20, wh = 26, cx = wx + ww * 0.5f, pitch = kTileW + kTileGap;
        cv.rect(wx, wy, ww, wh, Color{0, 0, 0}, 0.55f);
        const float scroll = reelScroll(), edge = ww * 0.5f - kTileW * 0.5f;
        const int i0 = (int)std::floor((scroll - ww * 0.5f) / pitch), i1 = (int)std::ceil((scroll + ww * 0.5f) / pitch);
        for (int i = i0; i <= i1; i++) {
            const float tc = cx + i * pitch - scroll, d = std::fabs(tc - cx);
            if (d >= edge) continue;                                      // would stick out of the window
            const float a = clampf((edge - d) / 30.f, 0.f, 1.f);          // tiles fade in and out at the edges of the window
            const int t = reel_[((i % kReelLen) + kReelLen) % kReelLen];
            cv.rect(tc - kTileW * 0.5f, wy + 2, kTileW, wh - 4, tierColor(t), 0.95f * a);
            UiText::draw(cv, "X" + num(spinTiers()[t].mult), tc, wy + wh * 0.5f - 5.f, 2, white, 1, a);
        }
        // the marker: a gold frame around the middle tile
        const float fx = cx - kTileW * 0.5f - 1;
        cv.rect(fx, wy, kTileW + 2, 1, gold, 0.95f); cv.rect(fx, wy + wh - 1, kTileW + 2, 1, gold, 0.95f);
        cv.rect(fx, wy, 1, wh, gold, 0.95f); cv.rect(fx + kTileW + 1, wy, 1, wh, gold, 0.95f);
        UiText::draw(cv, "WOOD PRICE X" + num(woodPriceMult) + "  =  " + num(woodPrice()) + " EACH", px + pw * 0.5f, py + 81, 1, white, 1);
        // the odds, wrapped to fit the panel
        std::string line;
        float y = py + 116;
        for (int i = 0; i < kSpinTiers; i++) {
            const std::string item = "X" + num(spinTiers()[i].mult) + " " + gnum::percent(spinTiers()[i].weight) + "%";
            const std::string next = line.empty() ? item : line + "   " + item;
            if (!line.empty() && UiText::width(next, 1) > pw - 24) { UiText::draw(cv, line, px + pw * 0.5f, y, 1, soft, 1); y += 9; line = item; }
            else line = next;
        }
        if (!line.empty()) UiText::draw(cv, line, px + pw * 0.5f, y, 1, soft, 1);
    }
};
