package com.example.axesimulator3d;

import android.app.NativeActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * The game itself is C++ (NativeActivity). This small Java class only handles AdMob:
 *   1. the banner at the bottom of the screen, and
 *   2. the rewarded ad behind the shop's "WATCH AD - FREE SPIN" button.
 *
 * Why the banner is in a PopupWindow: NativeActivity hands ALL touches to the C++ code, so a normal Android view placed
 * on top of the game would never receive a tap. A PopupWindow is a separate window, so the banner can be tapped, while
 * touches anywhere else still go straight to the game.
 *
 * The C++ code (android_main.cpp) calls these methods: setBannerVisible, rewardedReady, showRewardedAd, pollAdResult.
 */
public class MainActivity extends NativeActivity {
    private static final String TAG = "AxeSimAds";

    // ============================== AD SETTINGS ==============================
    // Banner: your real ad unit (AdMob > Apps > Axe Simulator 3D > Ad units).
    private static final String BANNER_AD_UNIT_ID = "ca-app-pub-7435099394804874/6059099663";
    private static final String TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111";

    // Rewarded ad (the "WATCH AD" button): the AdMob ad unit named "industrial".
    // If you ever leave this empty, Google's test rewarded ad is shown instead (the button works but earns nothing).
    private static final String REWARDED_AD_UNIT_ID = "ca-app-pub-7435099394804874/4806118354";
    private static final String TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917";

    // true  = Google's test ads for everything (always safe to tap, earns nothing)
    // false = your real ads (this is what earns money)
    private static final boolean USE_TEST_ADS = false;
    // =========================================================================

    private static final long REWARDED_MAX_AGE_MS = 50L * 60L * 1000L;   // Google: a loaded ad expires after an hour
    private static final long RETRY_LOAD_MS = 30L * 1000L;
    private static final long RETRY_BANNER_MS = 60L * 1000L;

    // What the Options screen shows about each ad: 0 starting, 1 loading, 2 ready, 10 + code = failed.
    // The code is AdMob's error code (3 = no ad available for you right now, 2 = no internet, 1 = bad ad unit ID).
    private volatile int bannerState = 0;
    private volatile int rewardedState = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());

    // ---- banner ----
    private AdView adView;
    private PopupWindow popup;
    private boolean adLoaded = false;        // the first banner has arrived (nothing is shown before that)
    private boolean menuAllowsAd = true;     // false while a game menu is open

    // ---- rewarded ad ----
    private volatile RewardedAd rewardedAd;  // loaded and ready to show (null = none yet)
    private volatile long rewardedLoadedAt = 0L;
    private boolean rewardedLoading = false;
    private boolean rewardEarned = false;
    private final AtomicInteger adResult = new AtomicInteger(0);   // 0 nothing yet, 1 watched it, 2 closed early, 3 could not be shown

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Google recommends starting the ads SDK on a background thread. Everything else runs on the main thread.
        new Thread(() -> MobileAds.initialize(this, status -> runOnUiThread(this::onAdsReady))).start();
    }

    private void onAdsReady() {
        createBanner();
        loadRewarded();
    }

    // ============================== banner ==============================
    private void createBanner() {
        if (adView != null || isFinishing() || isDestroyed()) return;
        adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);                                   // 320 x 50 dp
        adView.setAdUnitId(USE_TEST_ADS ? TEST_BANNER_AD_UNIT_ID : BANNER_AD_UNIT_ID);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                adLoaded = true;
                bannerState = 2;
                updateBanner();
            }

            @Override
            public void onAdFailedToLoad(LoadAdError error) {
                // No ad (no internet, no ad available yet...). The banner simply stays hidden until one arrives.
                Log.w(TAG, "Banner failed to load: " + error.getMessage());
                if (!adLoaded) {
                    bannerState = 10 + error.getCode();
                    handler.postDelayed(MainActivity.this::retryBanner, RETRY_BANNER_MS);
                }
            }
        });
        popup = new PopupWindow(adView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setFocusable(false);   // never take the touch focus away from the game
        bannerState = 1;
        adView.loadAd(new AdRequest.Builder().build());
    }

    // If the first request failed (no internet, no ad available yet...), ask again a minute later.
    private void retryBanner() {
        if (adView == null || adLoaded || isFinishing() || isDestroyed()) return;
        bannerState = 1;
        adView.loadAd(new AdRequest.Builder().build());
    }

    // Shows or hides the banner depending on: has an ad loaded, and is a menu open.
    private void updateBanner() {
        if (popup == null) return;
        final boolean show = adLoaded && menuAllowsAd && !isFinishing() && !isDestroyed();
        try {
            if (show && !popup.isShowing()) {
                final View anchor = getWindow().getDecorView();
                if (anchor.getWindowToken() == null) {           // the game window is not ready yet: try again soon
                    anchor.postDelayed(this::updateBanner, 300);
                    return;
                }
                popup.showAtLocation(anchor, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
            } else if (!show && popup.isShowing()) {
                popup.dismiss();
            }
        } catch (RuntimeException e) {
            Log.w(TAG, "Could not update the banner: " + e);
        }
    }

    /** Called from C++ on the game thread. false = hide the banner (a menu is open). */
    public void setBannerVisible(final boolean visible) {
        runOnUiThread(() -> {
            menuAllowsAd = visible;
            updateBanner();
        });
    }

    // ============================== rewarded ad ==============================
    private void loadRewarded() {
        if (rewardedAd != null || rewardedLoading || isFinishing() || isDestroyed()) return;
        rewardedLoading = true;
        rewardedState = 1;
        final String id = (USE_TEST_ADS || REWARDED_AD_UNIT_ID.isEmpty()) ? TEST_REWARDED_AD_UNIT_ID : REWARDED_AD_UNIT_ID;
        RewardedAd.load(this, id, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
            @Override
            public void onAdLoaded(RewardedAd ad) {
                rewardedLoading = false;
                rewardedAd = ad;
                rewardedLoadedAt = SystemClock.elapsedRealtime();
                rewardedState = 2;
            }

            @Override
            public void onAdFailedToLoad(LoadAdError error) {
                rewardedLoading = false;
                rewardedAd = null;
                rewardedState = 10 + error.getCode();
                Log.w(TAG, "Rewarded ad failed to load: " + error.getMessage());
                handler.postDelayed(MainActivity.this::loadRewarded, RETRY_LOAD_MS);   // try again in 30 seconds
            }
        });
    }

    /** Called from C++: 1 = a rewarded ad is loaded and ready, 0 = not yet. */
    public int rewardedReady() {
        if (rewardedAd == null) return 0;
        if (SystemClock.elapsedRealtime() - rewardedLoadedAt > REWARDED_MAX_AGE_MS) {   // too old: throw it away and load a fresh one
            runOnUiThread(() -> {
                if (rewardedAd != null && SystemClock.elapsedRealtime() - rewardedLoadedAt > REWARDED_MAX_AGE_MS) {
                    rewardedAd = null;
                    loadRewarded();
                }
            });
            return 0;
        }
        return 1;
    }

    /** Called from C++ when the player taps WATCH AD. The outcome is read afterwards with pollAdResult(). */
    public void showRewardedAd() {
        runOnUiThread(() -> {
            final RewardedAd ad = rewardedAd;
            if (ad == null) {
                adResult.set(3);
                loadRewarded();
                return;
            }
            rewardEarned = false;
            rewardedAd = null;   // an ad can only be shown once
            rewardedState = 1;
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    adResult.set(rewardEarned ? 1 : 2);   // Google calls onUserEarnedReward BEFORE this
                    loadRewarded();                       // get the next one ready
                }

                @Override
                public void onAdFailedToShowFullScreenContent(AdError error) {
                    Log.w(TAG, "Rewarded ad failed to show: " + error.getMessage());
                    adResult.set(3);
                    loadRewarded();
                }
            });
            ad.show(MainActivity.this, new OnUserEarnedRewardListener() {
                @Override
                public void onUserEarnedReward(RewardItem reward) {
                    rewardEarned = true;
                }
            });
        });
    }

    /** Called from C++ for the Options screen. */
    public int bannerStatus() {
        return bannerState;
    }

    public int rewardedStatus() {
        return rewardedState;
    }

    /** Called from C++ while it waits: 0 = nothing yet, 1 = the player watched the ad, 2 = closed it early, 3 = could not be shown. */
    public int pollAdResult() {
        return adResult.getAndSet(0);
    }

    // ============================== lifecycle ==============================
    @Override
    protected void onResume() {
        super.onResume();
        if (adView != null) adView.resume();
    }

    @Override
    protected void onPause() {
        if (adView != null) adView.pause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try {
            if (popup != null && popup.isShowing()) popup.dismiss();
        } catch (RuntimeException ignored) {
        }
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        rewardedAd = null;
        super.onDestroy();
    }
}
