package com.example.axesimulator3d;

import android.app.NativeActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;

/**
 * The game itself is C++ (NativeActivity). This tiny Java class only adds the AdMob banner.
 *
 * Why a PopupWindow: NativeActivity hands ALL touches to the C++ code, so a normal Android view placed on top of
 * the game would never receive a tap. A PopupWindow is a separate window, so the banner can be tapped, while
 * touches anywhere else still go straight to the game.
 *
 * The C++ code (android_main.cpp) calls setBannerVisible() to hide the banner while a menu is open.
 */
public class MainActivity extends NativeActivity {
    private static final String TAG = "AxeSimAds";

    // ============================== AD SETTINGS ==============================
    // Your real banner ad unit (AdMob > Apps > Axe Simulator 3D > Ad units).
    private static final String BANNER_AD_UNIT_ID = "ca-app-pub-7435099394804874/6059099663";
    // Google's official TEST banner. It shows a "Test Ad" label and earns nothing, but it is always safe to tap.
    private static final String TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111";
    // true  = Google's test ad (use this while you are testing on your own phone)
    // false = your real ad (this is the one that earns money)
    private static final boolean USE_TEST_ADS = false;
    // =========================================================================

    private AdView adView;
    private PopupWindow popup;
    private boolean adLoaded = false;        // the first ad has arrived (nothing is shown before that)
    private boolean menuAllowsAd = true;     // false while a game menu is open

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Google recommends starting the ads SDK on a background thread.
        new Thread(() -> MobileAds.initialize(this, status -> runOnUiThread(this::createBanner))).start();
    }

    private void createBanner() {
        if (adView != null || isFinishing() || isDestroyed()) return;
        adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);                                   // 320 x 50 dp
        adView.setAdUnitId(USE_TEST_ADS ? TEST_BANNER_AD_UNIT_ID : BANNER_AD_UNIT_ID);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                adLoaded = true;
                updateBanner();
            }

            @Override
            public void onAdFailedToLoad(LoadAdError error) {
                // No ad (no internet, no fill yet...). The banner simply stays hidden. AdMob retries by itself.
                Log.w(TAG, "Banner failed to load: " + error.getMessage());
            }
        });
        popup = new PopupWindow(adView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setFocusable(false);   // never take the touch focus away from the game
        adView.loadAd(new AdRequest.Builder().build());
    }

    // Shows or hides the banner depending on: has an ad loaded, and is a menu open.
    private void updateBanner() {
        if (popup == null) return;
        final boolean show = adLoaded && menuAllowsAd && !isFinishing() && !isDestroyed();
        try {
            if (show && !popup.isShowing()) {
                final View anchor = getWindow().getDecorView();
                if (anchor.getWindowToken() == null) {           // the game window is not ready yet: try again soon
                    anchor.postDelayed(this::updateBanner, 300);
                    return;
                }
                popup.showAtLocation(anchor, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
            } else if (!show && popup.isShowing()) {
                popup.dismiss();
            }
        } catch (RuntimeException e) {
            Log.w(TAG, "Could not update the banner: " + e);
        }
    }

    /** Called from C++ (android_main.cpp) on the game thread. false = hide the banner (a menu is open). */
    public void setBannerVisible(final boolean visible) {
        runOnUiThread(() -> {
            menuAllowsAd = visible;
            updateBanner();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adView != null) adView.resume();
    }

    @Override
    protected void onPause() {
        if (adView != null) adView.pause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        try {
            if (popup != null && popup.isShowing()) popup.dismiss();
        } catch (RuntimeException ignored) {
        }
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        super.onDestroy();
    }
}
