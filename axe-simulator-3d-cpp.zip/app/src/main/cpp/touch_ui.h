// touch_ui.h - touch controls (multi-touch) and a tiny text font. No Android headers in here, so it can be tested anywhere.
// Include it AFTER engine.cpp (it uses Game, FrameBuffer and Color from there).
//
//   Left side of the screen : floating joystick. Up/down = walk, left/right = turn.
//   Right side              : drag to look around.
//   Buttons                 : classic layout = JUMP;  game layout (simLayout) = CHOP, JUMP, USE.
//   Small buttons (top)     : V camera view, W wireframe (C chat in game layout), R restart, Q quality.
//
// Everything is drawn through a "canvas" with rect(), disc() and ring().
#pragma once
#include <utility>

// Draws semi-transparent shapes into the software renderer's picture.
struct SoftCanvas {
    FrameBuffer& fb;
    void blendPx(int x, int y, const Color& c, float a) {
        if (x < 0 || y < 0 || x >= fb.w || y >= fb.h) return;
        Color& d = fb.pix[(size_t)y * fb.w + x];
        d = mix(d, c, a);
    }
    void disc(float cx, float cy, float r, const Color& c, float a) {
        for (int y = (int)(cy - r); y <= (int)(cy + r); y++)
            for (int x = (int)(cx - r); x <= (int)(cx + r); x++)
                if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) blendPx(x, y, c, a);
    }
    void ring(float cx, float cy, float r, const Color& c, float a) {
        for (int y = (int)(cy - r - 2); y <= (int)(cy + r + 2); y++)
            for (int x = (int)(cx - r - 2); x <= (int)(cx + r + 2); x++) {
                float d = std::sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy));
                if (std::fabs(d - r) < 1.2f) blendPx(x, y, c, a);
            }
    }
    void rect(float x0, float y0, float rw, float rh, const Color& c, float a) {
        for (int y = (int)y0; y < (int)(y0 + rh); y++)
            for (int x = (int)x0; x < (int)(x0 + rw); x++) blendPx(x, y, c, a);
    }
};

// A tiny 3x5 pixel font: letters (lower case is drawn as capitals), digits and a few symbols.
struct UiText {
    static const char* const* glyph(char ch) {
        static const struct { char c; const char* rows[5]; } font[] = {
            {'A', {".#.", "#.#", "###", "#.#", "#.#"}}, {'B', {"##.", "#.#", "##.", "#.#", "##."}},
            {'C', {".##", "#..", "#..", "#..", ".##"}}, {'D', {"##.", "#.#", "#.#", "#.#", "##."}},
            {'E', {"###", "#..", "##.", "#..", "###"}}, {'F', {"###", "#..", "##.", "#..", "#.."}},
            {'G', {".##", "#..", "#.#", "#.#", ".##"}}, {'H', {"#.#", "#.#", "###", "#.#", "#.#"}},
            {'I', {"###", ".#.", ".#.", ".#.", "###"}}, {'J', {".##", "..#", "..#", "#.#", ".#."}},
            {'K', {"#.#", "#.#", "##.", "#.#", "#.#"}}, {'L', {"#..", "#..", "#..", "#..", "###"}},
            {'M', {"#.#", "###", "###", "#.#", "#.#"}}, {'N', {"##.", "#.#", "#.#", "#.#", "#.#"}},
            {'O', {".#.", "#.#", "#.#", "#.#", ".#."}}, {'P', {"##.", "#.#", "##.", "#..", "#.."}},
            {'Q', {".#.", "#.#", "#.#", "###", "..#"}}, {'R', {"##.", "#.#", "##.", "#.#", "#.#"}},
            {'S', {".##", "#..", ".#.", "..#", "##."}}, {'T', {"###", ".#.", ".#.", ".#.", ".#."}},
            {'U', {"#.#", "#.#", "#.#", "#.#", "###"}}, {'V', {"#.#", "#.#", "#.#", "#.#", ".#."}},
            {'W', {"#.#", "#.#", "###", "###", "#.#"}}, {'X', {"#.#", "#.#", ".#.", "#.#", "#.#"}},
            {'Y', {"#.#", "#.#", ".#.", ".#.", ".#."}}, {'Z', {"###", "..#", ".#.", "#..", "###"}},
            {'0', {"###", "#.#", "#.#", "#.#", "###"}}, {'1', {".#.", "##.", ".#.", ".#.", "###"}},
            {'2', {"###", "..#", "###", "#..", "###"}}, {'3', {"###", "..#", "###", "..#", "###"}},
            {'4', {"#.#", "#.#", "###", "..#", "..#"}}, {'5', {"###", "#..", "###", "..#", "###"}},
            {'6', {"###", "#..", "###", "#.#", "###"}}, {'7', {"###", "..#", "..#", "..#", "..#"}},
            {'8', {"###", "#.#", "###", "#.#", "###"}}, {'9', {"###", "#.#", "###", "..#", "###"}},
            {'/', {"..#", "..#", ".#.", "#..", "#.."}}, {'.', {"...", "...", "...", "...", ".#."}},
            {',', {"...", "...", "...", ".#.", "#.."}}, {'!', {".#.", ".#.", ".#.", "...", ".#."}},
            {'?', {"##.", "..#", ".#.", "...", ".#."}}, {':', {"...", ".#.", "...", ".#.", "..."}},
            {'-', {"...", "...", "###", "...", "..."}}, {'+', {"...", ".#.", "###", ".#.", "..."}},
            {'\'', {".#.", ".#.", "...", "...", "..."}}, {'%', {"#.#", "..#", ".#.", "#..", "#.#"}},
            {'>', {"#..", ".#.", "..#", ".#.", "#.."}}};
        for (auto& g : font) if (g.c == ch) return g.rows;
        return nullptr;
    }
    static float width(const std::string& s, int scale) { return s.empty() ? 0.f : (float)(s.size() * 4 - 1) * scale; }
    // align: 0 = x is the left edge, 1 = x is the center, 2 = x is the right edge. y = top edge.
    template <class Canvas>
    static void draw(Canvas& cv, const std::string& s, float x, float y, int scale, const Color& c, int align = 0, float alpha = 0.95f) {
        float w = width(s, scale);
        float x0 = align == 1 ? x - w / 2 : (align == 2 ? x - w : x);
        for (size_t i = 0; i < s.size(); i++) {
            char ch = s[i];
            if (ch >= 'a' && ch <= 'z') ch = (char)(ch - 32);
            const char* const* g = glyph(ch);
            if (!g) continue;
            for (int row = 0; row < 5; row++)
                for (int col = 0; col < 3; col++)
                    if (g[row][col] == '#') cv.rect(x0 + (float)(i * 4 * scale) + col * scale, y + row * scale, (float)scale, (float)scale, c, alpha);
        }
    }
};

struct TouchUI {
    static constexpr int SMALL_BUTTONS = 4;
    int w = 320, h = 150;               // size of the area the controls are drawn in
    bool simLayout = false;             // game layout: CHOP + JUMP + USE
    bool useVisible = false;            // show the USE button (game layout)
    std::string useLabel = "USE";
    bool capture = false;               // a menu is open: touches become "taps" instead of controlling the player
    std::vector<std::pair<float, float>> taps;

    void resize(int W, int H) { w = W; h = H; }

    // action: 0 = finger down, 1 = finger moved, 2 = finger lifted. x, y are in the same units as w, h.
    void touch(int action, int id, float x, float y) {
        if (id < 0 || id >= MAXP) return;
        if (capture && action == 0) { taps.emplace_back(x, y); return; }
        Ptr& p = ptr_[id];
        if (action == 0) {
            p = Ptr();
            p.down = true; p.x = p.px = p.sx = x; p.y = p.py = p.sy = y;
            int b = buttonAt(x, y);
            if (b >= 0) { p.role = BUTTON; tap_[b] = true; }
            else if (x < w * 0.45f && stick_ < 0) { p.role = STICK; stick_ = id; }
            else p.role = LOOK;
        } else if (action == 1 && p.down) {
            p.px = p.x; p.py = p.y; p.x = x; p.y = y;
            if (p.role == LOOK) { lookX_ += (p.x - p.px) * 320.f / w; lookY_ += (p.y - p.py) * 320.f / w; }
        } else if (action == 2) {
            if (p.role == STICK && stick_ == id) stick_ = -1;
            p = Ptr();
        }
    }
    void releaseAll() { for (int i = 0; i < MAXP; i++) touch(2, i, 0, 0); for (bool& t : tap_) t = false; }

    // Call once per frame, after input.beginFrame(): hands the touch state to the game.
    void apply(Game& g, double now) {
        float ax, ay;
        axes(ax, ay);
        g.padTurn = ax;
        g.padMove = -ay;  // finger up = walk forward
        g.yaw += lookX_ * 0.012f;
        g.pitch = clampf(g.pitch - lookY_ * 0.012f, -1.2f, 1.2f);
        lookX_ = lookY_ = 0;
        static const char classic[7] = {' ', 'v', 'm', 'r', 'q', 0, 0};
        static const char game[7] = {'f', 'v', 'c', 'r', 'q', ' ', 'e'};
        const char* keys = simLayout ? game : classic;
        for (int i = 0; i < 7; i++)
            if (tap_[i]) { if (keys[i]) g.input.feed(keys[i], now); tap_[i] = false; }
    }

    // Draws the controls on top of the finished picture. Canvas needs rect(), disc() and ring().
    // coins < 0 hides the coin counter; fps < 0 hides the frame rate.
    template <class Canvas>
    void draw(Canvas& cv, int coins, int total, int fps = -1) const {
        float r = stickRadius(), cx = w * 0.17f, cy = h * 0.70f, kx = cx, ky = cy;
        if (stick_ >= 0) {
            const Ptr& p = ptr_[stick_];
            cx = p.sx; cy = p.sy;
            float dx = p.x - p.sx, dy = p.y - p.sy, d = std::sqrt(dx * dx + dy * dy);
            if (d > r) { dx *= r / d; dy *= r / d; }
            kx = cx + dx; ky = cy + dy;
        }
        bool on = stick_ >= 0;
        cv.ring(cx, cy, r, Color{1, 1, 1}, on ? 0.50f : 0.22f);
        cv.disc(kx, ky, r * 0.38f, Color{1, 1, 1}, on ? 0.60f : 0.28f);

        int sc = std::max(1, h / 75);
        cv.disc(mainX(), mainY(), mainR(), simLayout ? Color{1.f, 0.45f, 0.25f} : Color{1.f, 0.8f, 0.2f}, 0.50f);
        UiText::draw(cv, simLayout ? "CHOP" : "JUMP", mainX(), mainY() - 2.5f * sc, sc, Color{0, 0, 0}, 1);
        if (simLayout) {
            cv.disc(jumpX(), jumpY(), jumpR(), Color{1.f, 0.8f, 0.2f}, 0.50f);
            UiText::draw(cv, "JUMP", jumpX(), jumpY() - 2.5f, 1, Color{0, 0, 0}, 1);
            if (useVisible) {
                cv.disc(useX(), useY(), useR(), Color{0.4f, 0.9f, 0.5f}, 0.55f);
                UiText::draw(cv, useLabel, useX(), useY() - 2.5f, 1, Color{0, 0, 0}, 1);
            }
        }
        const char* labels[SMALL_BUTTONS] = {"V", simLayout ? "C" : "W", "R", "Q"};
        const Color cols[SMALL_BUTTONS] = {Color{0.4f, 0.7f, 1.f}, Color{0.5f, 0.9f, 0.5f}, Color{1.f, 0.5f, 0.5f}, Color{0.9f, 0.7f, 1.f}};
        for (int i = 0; i < SMALL_BUTTONS; i++) {
            cv.rect(smX(i), smY(), sm(), sm(), cols[i], 0.55f);
            UiText::draw(cv, labels[i], smX(i) + sm() / 2, smY() + sm() / 2 - 2.5f * sc, sc, Color{0, 0, 0}, 1);
        }
        char buf[16];
        if (coins >= 0) {
            snprintf(buf, sizeof buf, "%d/%d", coins, total);
            UiText::draw(cv, buf, 6.f, 4.f, sc, Color{1, 1, 1});
        }
        if (fps >= 0) {
            snprintf(buf, sizeof buf, "%d", fps);
            UiText::draw(cv, buf, 6.f, coins >= 0 ? 4.f + 10.f * sc : 4.f, sc, Color{0.8f, 0.8f, 0.8f});
        }
    }

private:
    static constexpr int MAXP = 10;  // fingers tracked at once
    enum Role { NONE, STICK, LOOK, BUTTON };
    struct Ptr { bool down = false; int role = NONE; float sx = 0, sy = 0, x = 0, y = 0, px = 0, py = 0; };
    Ptr ptr_[MAXP];
    int stick_ = -1;                 // which finger holds the joystick
    float lookX_ = 0, lookY_ = 0;    // look-drag movement waiting to be applied
    bool tap_[7] = {false, false, false, false, false, false, false};  // main, 4 small, jump (game layout), use (game layout)

    // --- layout (everything scales with the height) ---
    float stickRadius() const { return h * 0.26f; }
    float mainR() const { return h * (simLayout ? 0.20f : 0.17f); }
    float mainX() const { return w - mainR() * 1.6f; }
    float mainY() const { return h - mainR() * 1.6f; }
    float jumpR() const { return h * 0.105f; }
    float jumpX() const { return w - mainR() * 3.7f; }
    float jumpY() const { return h - mainR() * 0.95f; }
    float useR() const { return h * 0.115f; }
    float useX() const { return w - mainR() * 3.7f; }
    float useY() const { return h - mainR() * 2.75f; }
    float sm() const { return h * 0.13f; }  // small button size
    float smX(int i) const { return w - (SMALL_BUTTONS - i) * sm() * 1.35f; }
    float smY() const { return sm() * 0.35f; }
    static bool inDisc(float px, float py, float cx, float cy, float r) { float dx = px - cx, dy = py - cy; return dx * dx + dy * dy <= r * r; }
    int buttonAt(float x, float y) const {
        if (simLayout) {
            if (useVisible && inDisc(x, y, useX(), useY(), useR() * 1.2f)) return 6;
            if (inDisc(x, y, jumpX(), jumpY(), jumpR() * 1.25f)) return 5;
        }
        if (inDisc(x, y, mainX(), mainY(), mainR() * 1.18f)) return 0;
        for (int i = 0; i < SMALL_BUTTONS; i++)
            if (x >= smX(i) - 2 && x <= smX(i) + sm() + 2 && y >= smY() - 2 && y <= smY() + sm() + 2) return 1 + i;
        return -1;
    }
    void axes(float& ax, float& ay) const {
        ax = ay = 0;
        if (stick_ < 0) return;
        const Ptr& p = ptr_[stick_];
        ax = clampf((p.x - p.sx) / stickRadius(), -1.f, 1.f);
        ay = clampf((p.y - p.sy) / stickRadius(), -1.f, 1.f);
        if (std::fabs(ax) < 0.15f) ax = 0;  // small movements are ignored (dead zone)
        if (std::fabs(ay) < 0.15f) ay = 0;
    }
};
