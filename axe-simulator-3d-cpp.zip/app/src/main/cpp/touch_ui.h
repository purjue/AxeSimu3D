// touch_ui.h - touch controls (multi-touch) and text drawing. No Android headers in here, so it can be tested anywhere.
// Include it AFTER engine.cpp (it uses Game, FrameBuffer and Color from there).
//
//   Left half of the screen : dynamic joystick (small picture, big touch area). It only WALKS (forward/back/sideways).
//   Everything else         : drag to turn the camera.
//   Buttons                 : game layout = CHOP, JUMP, SHOP/PORT (same size) and OPTIONS (top left).
//
// Everything is drawn through a "canvas" with rect(), disc(), ring() and text().
#pragma once
#include <utility>

// The Kurland font as a picture made by tools/bake_font.py (an alpha picture + the position of every letter).
struct FontAtlas {
    struct Glyph { int x = 0, y = 0, w = 0, h = 0; float xoff = 0, yoff = 0, adv = 0; bool has = false; };
    int w = 0, h = 0;
    float size = 56, ascent = 47, descent = 12;
    Glyph g[128];
    std::vector<uint8_t> px;
    bool ok() const { return w > 0 && h > 0 && px.size() == (size_t)w * h; }
    const Glyph* glyph(char c) const { unsigned char u = (unsigned char)c; return (u < 128 && g[u].has) ? &g[u] : nullptr; }
    float width(const std::string& s) const { float x = 0; for (char c : s) { const Glyph* gl = glyph(c); if (gl) x += gl->adv; } return x; }
    bool load(const std::string& meta, const std::vector<uint8_t>& raw) {
        std::istringstream in(meta);
        float lineh = 0;
        in >> w >> h >> size >> ascent >> descent >> lineh;
        int code; Glyph gl;
        while (in >> code >> gl.x >> gl.y >> gl.w >> gl.h >> gl.xoff >> gl.yoff >> gl.adv)
            if (code >= 0 && code < 128) { g[code] = gl; g[code].has = true; }
        px = raw;
        return ok();
    }
};

// Draws semi-transparent shapes into the software renderer's picture (used only by the fallback demo).
struct SoftCanvas {
    FrameBuffer& fb;
    void blendPx(int x, int y, const Color& c, float a) {
        if (x < 0 || y < 0 || x >= fb.w || y >= fb.h) return;
        Color& d = fb.pix[(size_t)y * fb.w + x];
        d = mix(d, c, a);
    }
    void disc(float cx, float cy, float r, const Color& c, float a) {
        for (int y = (int)(cy - r); y <= (int)(cy + r); y++)
            for (int x = (int)(cx - r); x <= (int)(cx + r); x++)
                if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) blendPx(x, y, c, a);
    }
    void ring(float cx, float cy, float r, const Color& c, float a) {
        for (int y = (int)(cy - r - 2); y <= (int)(cy + r + 2); y++)
            for (int x = (int)(cx - r - 2); x <= (int)(cx + r + 2); x++) {
                float d = std::sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy));
                if (std::fabs(d - r) < 1.2f) blendPx(x, y, c, a);
            }
    }
    void rect(float x0, float y0, float rw, float rh, const Color& c, float a) {
        for (int y = (int)y0; y < (int)(y0 + rh); y++)
            for (int x = (int)x0; x < (int)(x0 + rw); x++) blendPx(x, y, c, a);
    }
    bool text(const std::string&, float, float, int, const Color&, int, float) { return false; }   // no font here: UiText uses its pixel font
};

// Text. With a font loaded (UiText::font) the GPU canvas draws it with Kurland; otherwise a tiny pixel font is used.
struct UiText {
    static inline const FontAtlas* font = nullptr;
    static const char* const* glyph(char ch) {
        static const struct { char c; const char* rows[5]; } table[] = {
            {'A', {".#.", "#.#", "###", "#.#", "#.#"}}, {'B', {"##.", "#.#", "##.", "#.#", "##."}},
            {'C', {".##", "#..", "#..", "#..", ".##"}}, {'D', {"##.", "#.#", "#.#", "#.#", "##."}},
            {'E', {"###", "#..", "##.", "#..", "###"}}, {'F', {"###", "#..", "##.", "#..", "#.."}},
            {'G', {".##", "#..", "#.#", "#.#", ".##"}}, {'H', {"#.#", "#.#", "###", "#.#", "#.#"}},
            {'I', {"###", ".#.", ".#.", ".#.", "###"}}, {'J', {".##", "..#", "..#", "#.#", ".#."}},
            {'K', {"#.#", "#.#", "##.", "#.#", "#.#"}}, {'L', {"#..", "#..", "#..", "#..", "###"}},
            {'M', {"#.#", "###", "###", "#.#", "#.#"}}, {'N', {"##.", "#.#", "#.#", "#.#", "#.#"}},
            {'O', {".#.", "#.#", "#.#", "#.#", ".#."}}, {'P', {"##.", "#.#", "##.", "#..", "#.."}},
            {'Q', {".#.", "#.#", "#.#", "###", "..#"}}, {'R', {"##.", "#.#", "##.", "#.#", "#.#"}},
            {'S', {".##", "#..", ".#.", "..#", "##."}}, {'T', {"###", ".#.", ".#.", ".#.", ".#."}},
            {'U', {"#.#", "#.#", "#.#", "#.#", "###"}}, {'V', {"#.#", "#.#", "#.#", "#.#", ".#."}},
            {'W', {"#.#", "#.#", "###", "###", "#.#"}}, {'X', {"#.#", "#.#", ".#.", "#.#", "#.#"}},
            {'Y', {"#.#", "#.#", ".#.", ".#.", ".#."}}, {'Z', {"###", "..#", ".#.", "#..", "###"}},
            {'0', {"###", "#.#", "#.#", "#.#", "###"}}, {'1', {".#.", "##.", ".#.", ".#.", "###"}},
            {'2', {"###", "..#", "###", "#..", "###"}}, {'3', {"###", "..#", "###", "..#", "###"}},
            {'4', {"#.#", "#.#", "###", "..#", "..#"}}, {'5', {"###", "#..", "###", "..#", "###"}},
            {'6', {"###", "#..", "###", "#.#", "###"}}, {'7', {"###", "..#", "..#", "..#", "..#"}},
            {'8', {"###", "#.#", "###", "#.#", "###"}}, {'9', {"###", "#.#", "###", "..#", "###"}},
            {'/', {"..#", "..#", ".#.", "#..", "#.."}}, {'.', {"...", "...", "...", "...", ".#."}},
            {',', {"...", "...", "...", ".#.", "#.."}}, {'!', {".#.", ".#.", ".#.", "...", ".#."}},
            {'?', {"##.", "..#", ".#.", "...", ".#."}}, {':', {"...", ".#.", "...", ".#.", "..."}},
            {'-', {"...", "...", "###", "...", "..."}}, {'+', {"...", ".#.", "###", ".#.", "..."}},
            {'%', {"#.#", "..#", ".#.", "#..", "#.#"}}, {'>', {"#..", ".#.", "..#", ".#.", "#.."}}};
        for (auto& g : table) if (g.c == ch) return g.rows;
        return nullptr;
    }
    // Width of a text in UI units.
    static float width(const std::string& s, int scale) {
        if (font && font->ok()) return font->width(s) * 7.5f * scale / font->size;
        return s.empty() ? 0.f : (float)(s.size() * 4 - 1) * scale;
    }
    // align: 0 = x is the left edge, 1 = x is the center, 2 = x is the right edge. y = top edge.
    template <class Canvas>
    static void draw(Canvas& cv, const std::string& s, float x, float y, int scale, const Color& c, int align = 0, float alpha = 0.95f) {
        if (cv.text(s, x, y, scale, c, align, alpha)) return;
        float w = (s.empty() ? 0.f : (float)(s.size() * 4 - 1) * scale);
        float x0 = align == 1 ? x - w / 2 : (align == 2 ? x - w : x);
        for (size_t i = 0; i < s.size(); i++) {
            char ch = s[i];
            if (ch >= 'a' && ch <= 'z') ch = (char)(ch - 32);
            const char* const* g = glyph(ch);
            if (!g) continue;
            for (int row = 0; row < 5; row++)
                for (int col = 0; col < 3; col++)
                    if (g[row][col] == '#') cv.rect(x0 + (float)(i * 4 * scale) + col * scale, y + row * scale, (float)scale, (float)scale, c, alpha);
        }
    }
};

struct TouchUI {
    struct Btn { char key; std::string label; bool round; float x, y, w, h; Color color; };   // round: x,y = center, w = radius
    int w = 320, h = 150;               // size of the area the controls are drawn in
    bool simLayout = false;             // game layout (CHOP, JUMP, SHOP/PORT, OPTIONS)
    bool useVisible = false;            // show the SHOP / PORT button (game layout)
    std::string useLabel = "SHOP";
    bool capture = false;               // a menu is open: touches become "taps" instead of controlling the player
    std::vector<std::pair<float, float>> taps;
    std::vector<Btn> btns;

    TouchUI() { layout(); }
    void resize(int W, int H) { w = W; h = H; layout(); }
    void setGameLayout(bool on) { simLayout = on; layout(); }

    // action: 0 = finger down, 1 = finger moved, 2 = finger lifted. x, y are in the same units as w, h.
    void touch(int action, int id, float x, float y) {
        if (id < 0 || id >= MAXP) return;
        if (capture && action == 0) { taps.emplace_back(x, y); return; }
        Ptr& p = ptr_[id];
        if (action == 0) {
            p = Ptr();
            p.down = true; p.x = p.px = p.sx = x; p.y = p.py = p.sy = y;
            int b = buttonAt(x, y);
            if (b >= 0) { p.role = BUTTON; tap_[b] = 1; }
            else if (x < w * 0.5f && stick_ < 0) { p.role = STICK; stick_ = id; }
            else p.role = LOOK;
        } else if (action == 1 && p.down) {
            p.px = p.x; p.py = p.y; p.x = x; p.y = y;
            if (p.role == LOOK) { lookX_ += (p.x - p.px) * 320.f / w; lookY_ += (p.y - p.py) * 320.f / w; }
            else if (p.role == STICK) {   // dynamic stick: its center follows the finger when the finger goes too far
                float dx = p.x - p.sx, dy = p.y - p.sy, d = std::sqrt(dx * dx + dy * dy), rr = respR();
                if (d > rr) { float k = (d - rr) / d; p.sx += dx * k; p.sy += dy * k; }
            }
        } else if (action == 2) {
            if (p.role == STICK && stick_ == id) stick_ = -1;
            p = Ptr();
        }
    }
    void releaseAll() { for (int i = 0; i < MAXP; i++) touch(2, i, 0, 0); for (char& t : tap_) t = 0; }

    // Call once per frame, after input.beginFrame(): hands the touch state to the game.
    void apply(Game& g, double now) {
        float ax, ay;
        axes(ax, ay);
        g.padStrafe = ax;   // the joystick only walks: it never turns the camera
        g.padMove = -ay;    // finger up = walk forward
        g.padTurn = 0.f;
        g.yaw += lookX_ * 0.012f;
        g.pitch = clampf(g.pitch - lookY_ * 0.012f, -1.2f, 1.2f);
        lookX_ = lookY_ = 0;
        for (size_t i = 0; i < btns.size(); i++)
            if (tap_[i]) { g.input.feed(btns[i].key, now); tap_[i] = 0; }
    }

    // The buttons' touch areas (what Android needs to know) in UI units.
    int buttonAt(float x, float y) const {
        for (int i = (int)btns.size() - 1; i >= 0; i--) {
            const Btn& b = btns[i];
            if (simLayout && i == 2 && !useVisible) continue;
            if (b.round) { float dx = x - b.x, dy = y - b.y, r = b.w * 1.3f; if (dx * dx + dy * dy <= r * r) return i; }
            else if (x >= b.x - 3 && x <= b.x + b.w + 3 && y >= b.y - 3 && y <= b.y + b.h + 3) return i;
        }
        return -1;
    }
    float stickVisibleRadius() const { return h * 0.10f; }   // small on screen...
    float stickTouchRadius() const { return respR(); }        // ...but a big area to move your finger in

    // Draws the controls. Canvas needs rect(), disc(), ring() and text(). coins < 0 hides the coin counter; fps < 0 hides the frame rate.
    template <class Canvas>
    void draw(Canvas& cv, int coins, int total, int fps = -1) const {
        if (!capture) {
            const float vr = stickVisibleRadius();
            float cx = w * 0.13f, cy = h * 0.74f, kx = cx, ky = cy;
            const bool on = stick_ >= 0;
            if (on) {
                const Ptr& p = ptr_[stick_];
                cx = p.sx; cy = p.sy;
                float dx = (p.x - p.sx) / respR(), dy = (p.y - p.sy) / respR(), d = std::sqrt(dx * dx + dy * dy);
                if (d > 1.f) { dx /= d; dy /= d; }
                kx = cx + dx * vr * 0.9f; ky = cy + dy * vr * 0.9f;
            }
            cv.ring(cx, cy, vr, Color{1, 1, 1}, on ? 0.45f : 0.18f);
            cv.disc(kx, ky, vr * 0.42f, Color{1, 1, 1}, on ? 0.55f : 0.22f);
            const int sc = 1;
            for (size_t i = 0; i < btns.size(); i++) {
                const Btn& b = btns[i];
                if (simLayout && i == 2 && !useVisible) continue;
                std::string label = (simLayout && i == 2) ? useLabel : b.label;
                if (b.round) { cv.disc(b.x, b.y, b.w, b.color, 0.55f); UiText::draw(cv, label, b.x, b.y - 2.5f * sc, sc, Color{0, 0, 0}, 1, 1.f); }
                else { cv.rect(b.x, b.y, b.w, b.h, b.color, 0.65f); UiText::draw(cv, label, b.x + b.w / 2, b.y + b.h / 2 - 2.5f * sc, sc, Color{1, 1, 1}, 1, 1.f); }
            }
        }
        char buf[16];
        if (coins >= 0) { snprintf(buf, sizeof buf, "%d/%d", coins, total); UiText::draw(cv, buf, 6.f, 4.f, 2, Color{1, 1, 1}); }
        if (fps >= 0) { snprintf(buf, sizeof buf, "%d", fps); UiText::draw(cv, buf, 6.f, coins >= 0 ? 24.f : 4.f, 1, Color{0.8f, 0.8f, 0.8f}); }
    }

private:
    static constexpr int MAXP = 10;  // fingers tracked at once
    enum Role { NONE, STICK, LOOK, BUTTON };
    struct Ptr { bool down = false; int role = NONE; float sx = 0, sy = 0, x = 0, y = 0, px = 0, py = 0; };
    Ptr ptr_[MAXP];
    int stick_ = -1;                 // which finger holds the joystick
    float lookX_ = 0, lookY_ = 0;    // look-drag movement waiting to be applied
    std::vector<char> tap_;

    float respR() const { return h * 0.20f; }   // how far you move your finger for full speed
    void layout() {
        btns.clear();
        if (simLayout) {
            const float r = h * 0.095f;   // CHOP, JUMP and SHOP/PORT are all the same small size
            btns.push_back({'f', "CHOP", true, w * 0.913f, h * 0.665f, r, 0, Color{1.f, 0.5f, 0.25f}});
            btns.push_back({' ', "JUMP", true, w * 0.917f, h * 0.885f, r, 0, Color{1.f, 0.8f, 0.2f}});
            btns.push_back({'e', "SHOP", true, w * 0.72f, h * 0.665f, r, 0, Color{0.4f, 0.9f, 0.5f}});
            btns.push_back({'o', "OPTIONS", false, 6.f, 33.f, 70.f, 17.f, Color{0.2f, 0.35f, 0.6f}});
        } else {
            const float R = h * 0.17f, sm = h * 0.13f;
            btns.push_back({' ', "JUMP", true, w - R * 1.6f, h - R * 1.6f, R, 0, Color{1.f, 0.8f, 0.2f}});
            const char keys[4] = {'v', 'm', 'r', 'q'};
            const char* labels[4] = {"V", "W", "R", "Q"};
            for (int i = 0; i < 4; i++) btns.push_back({keys[i], labels[i], false, w - (4 - i) * sm * 1.35f, sm * 0.35f, sm, sm, Color{0.4f, 0.6f, 0.9f}});
        }
        tap_.assign(btns.size(), 0);
    }
    void axes(float& ax, float& ay) const {
        ax = ay = 0;
        if (stick_ < 0) return;
        const Ptr& p = ptr_[stick_];
        ax = clampf((p.x - p.sx) / respR(), -1.f, 1.f);
        ay = clampf((p.y - p.sy) / respR(), -1.f, 1.f);
        if (std::fabs(ax) < 0.12f) ax = 0;  // small movements are ignored (dead zone)
        if (std::fabs(ay) < 0.12f) ay = 0;
    }
};
