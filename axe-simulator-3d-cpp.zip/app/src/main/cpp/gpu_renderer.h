// gpu_renderer.h - the GPU renderer (OpenGL ES 3.0).
// Include AFTER engine.cpp and gltf_loader.h. It draws a Scene with:
//   - physically based shading (metal / roughness, GGX highlights, Fresnel)
//   - a sun with soft shadows (shadow map + PCF)
//   - a procedural sky that also lights the world (ambient light + reflections)
//   - procedural surfaces (grass, bricks, wood) with bump mapping, and real textures / normal maps from .glb
//   - fog, ACES tone mapping and gamma correction
// The 3D picture is drawn at a lower resolution and scaled up (quality levels), then the touch controls on top.
#pragma once
#include "gl_api.h"
#include <unordered_map>

// ================================================================ shaders (GLSL ES 3.00)
static const char* const kGlslHead =
    "#version 300 es\n"
    "precision highp float;\nprecision highp int;\nprecision highp sampler2D;\nprecision highp sampler2DShadow;\n";

// Shared by the sky and surface shaders: noise, sky colors, tone mapping.
static const char* const kGlslCommon = R"GLSL(
const float PI = 3.14159265;
const float EXPOSURE = 0.85;

float hash31(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.71, 0.113, 0.419));
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float vnoise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    float a = mix(hash31(i), hash31(i + vec3(1.0, 0.0, 0.0)), f.x);
    float b = mix(hash31(i + vec3(0.0, 1.0, 0.0)), hash31(i + vec3(1.0, 1.0, 0.0)), f.x);
    float c = mix(hash31(i + vec3(0.0, 0.0, 1.0)), hash31(i + vec3(1.0, 0.0, 1.0)), f.x);
    float d = mix(hash31(i + vec3(0.0, 1.0, 1.0)), hash31(i + vec3(1.0, 1.0, 1.0)), f.x);
    return mix(mix(a, b, f.y), mix(c, d, f.y), f.z);
}
float fbm(vec3 p) {
    float a = 0.5, s = 0.0;
    for (int i = 0; i < 3; i++) { s += a * vnoise(p); p = p * 2.03 + 11.7; a *= 0.5; }
    return s;
}
// Color of the sky in direction d. sunToward = direction pointing at the sun.
vec3 skyColor(vec3 d, vec3 sunToward) {
    vec3 zenith = vec3(0.10, 0.27, 0.68);
    vec3 horizon = vec3(0.60, 0.72, 0.88);
    vec3 c = mix(horizon, zenith, pow(clamp(d.y, 0.0, 1.0), 0.5));
    c = mix(c, vec3(0.22, 0.24, 0.20), smoothstep(0.0, -0.25, d.y));
    float s = max(dot(d, sunToward), 0.0);
    c += vec3(1.0, 0.72, 0.42) * (pow(s, 6.0) * 0.20 + pow(s, 64.0) * 0.40);
    c += vec3(1.0, 0.95, 0.85) * smoothstep(0.9993, 0.9998, s) * 14.0;
    return c;
}
vec3 aces(vec3 x) { return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }
vec3 finishColor(vec3 c) { return pow(aces(c * EXPOSURE), vec3(1.0 / 2.2)); }
)GLSL";

static const char* const kPbrVS = R"GLSL(#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;
uniform mat4 uModel;
uniform mat3 uNormalMat;
uniform mat4 uVP;
uniform mat4 uLightVP;
out vec3 vWorld;
out vec3 vNormal;
out vec2 vUV;
out vec4 vLight;
void main() {
    vec4 w = uModel * vec4(aPos, 1.0);
    vWorld = w.xyz;
    vNormal = normalize(uNormalMat * aNormal);
    vUV = aUV;
    vLight = uLightVP * vec4(w.xyz + vNormal * 0.04, 1.0);   // pushed along the normal: avoids shadow acne
    gl_Position = uVP * w;
}
)GLSL";

static const char* const kPbrFS = R"GLSL(
in vec3 vWorld;
in vec3 vNormal;
in vec2 vUV;
in vec4 vLight;
out vec4 oColor;

uniform vec3 uCam;
uniform vec3 uSunToward;
uniform vec3 uSunColor;
uniform vec4 uBase;
uniform float uMetal;
uniform float uRough;
uniform vec3 uEmissive;
uniform int uPattern;
uniform int uFlags;      // 1 base tex, 2 normal tex, 4 metal-rough tex, 8 emissive tex, 16 shadows, 32 alpha mask, 64 unlit
uniform float uAlphaCut;
uniform float uShadowTexel;
uniform float uTime;
uniform sampler2D uTexBase;
uniform sampler2D uTexNormal;
uniform sampler2D uTexMR;
uniform sampler2D uTexEmis;
uniform sampler2DShadow uShadow;

// ---- procedural surfaces: each returns a surface height in "h" (used for bump mapping) ----
vec2 planarUV(vec3 p, vec3 n) {
    vec3 a = abs(n);
    if (a.y >= a.x && a.y >= a.z) return p.xz;
    if (a.x >= a.z) return p.zy;
    return p.xy;
}
void surfTerrain(vec3 p, out vec3 albedo, out float rough, out float h) {
    float large = fbm(p * 0.20);
    float mid = fbm(p * 1.1);
    float fine = vnoise(p * 11.0) * 0.6 + vnoise(p * 31.0) * 0.4;
    vec3 grassA = vec3(0.030, 0.085, 0.018);
    vec3 grassB = vec3(0.085, 0.170, 0.032);
    vec3 dirt = vec3(0.140, 0.092, 0.048);
    vec3 c = mix(grassA, grassB, smoothstep(0.2, 0.7, mid));
    c = mix(c, dirt, smoothstep(0.50, 0.66, large));
    albedo = c * (0.75 + 0.5 * fine);
    rough = 0.95;
    h = (mid * 0.5 + fine * 0.5) * 0.045;
}
void surfBricks(vec3 p, vec3 n, vec3 base, out vec3 albedo, out float rough, out float h) {
    vec2 uv = planarUV(p, n) * vec2(1.0, 2.2);
    float row = floor(uv.y);
    uv.x += 0.5 * mod(row, 2.0);
    vec2 cell = floor(uv);
    vec2 f = fract(uv);
    float edge = min(min(f.x, 1.0 - f.x) * 1.0, min(f.y, 1.0 - f.y) * 0.4545);
    float brick = smoothstep(0.0, 0.035, edge);
    float r = hash31(vec3(cell, 3.0));
    vec3 c = base * (0.65 + 0.7 * r) * (0.8 + 0.4 * fbm(p * 5.0));
    albedo = mix(vec3(0.20, 0.19, 0.17), c, brick);
    rough = mix(0.97, 0.85, brick);
    h = brick * 0.06 + fbm(p * 8.0) * 0.015;
}
void surfWood(vec3 p, vec3 n, vec3 base, out vec3 albedo, out float rough, out float h) {
    vec2 uv = planarUV(p, n);
    float plank = floor(uv.x * 2.5);
    float fx = fract(uv.x * 2.5);
    float seam = smoothstep(0.0, 0.05, min(fx, 1.0 - fx));
    float rnd = hash31(vec3(plank, 7.0, 1.0));
    float grain = vnoise(vec3(uv.x * 30.0 + rnd * 20.0, uv.y * 1.2, rnd * 10.0));
    float rings = 0.5 + 0.5 * sin((uv.x * 2.5 + grain * 0.6) * 22.0);
    albedo = base * (0.55 + 0.6 * mix(grain, rings, 0.5)) * (0.8 + 0.4 * rnd) * mix(0.35, 1.0, seam);
    rough = 0.62;
    h = (seam * 0.5 + grain * 0.5) * 0.02;
}

// Ground made from a photo texture: two scales are blended so the repeating pattern is hard to notice.
void surfGround(vec3 p, out vec3 albedo, out float rough, out float h) {
    vec3 a = texture(uTexBase, p.xz / 5.0).rgb;
    vec3 b = texture(uTexBase, p.xz * 0.047 + vec2(0.37, 0.11)).rgb;
    float m = smoothstep(0.35, 0.65, fbm(p * 0.07));
    albedo = mix(a, b, m * 0.5) * (0.82 + 0.36 * fbm(p * 0.8));
    albedo = mix(albedo, vec3(0.34, 0.28, 0.16), (1.0 - smoothstep(-3.6, -0.8, p.y)) * 0.92);   // beach sand near the water
    rough = 0.95;
    h = dot(albedo, vec3(0.3, 0.59, 0.11)) * 0.05;
}

// Water: moving waves (a height that changes with time, used for bump mapping) and a dark shiny surface.
void surfWater(vec3 p, out vec3 albedo, out float rough, out float h) {
    vec3 q = vec3(p.x * 0.35, p.z * 0.35, uTime * 0.25);
    float w1 = fbm(q + vec3(uTime * 0.12, 0.0, 0.0));
    float w2 = fbm(q * 2.3 + vec3(0.0, uTime * 0.2, 4.0));
    h = (w1 * 0.7 + w2 * 0.3) * 0.5;
    albedo = vec3(0.012, 0.075, 0.11);
    rough = 0.06;
}

// Bends the surface normal using the slope of a height value (screen-space derivatives).
vec3 bumpNormal(vec3 N, vec3 p, float h) {
    vec3 dpdx = dFdx(p);
    vec3 dpdy = dFdy(p);
    float dhdx = dFdx(h);
    float dhdy = dFdy(h);
    vec3 r1 = cross(dpdy, N);
    vec3 r2 = cross(N, dpdx);
    float det = dot(dpdx, r1);
    vec3 grad = sign(det) * (dhdx * r1 + dhdy * r2);
    return normalize(abs(det) * N - grad);
}
// Applies a normal map without needing tangents stored in the model.
vec3 normalMapNormal(vec3 N, vec3 p, vec2 uv, vec3 tn) {
    vec3 dp1 = dFdx(p);
    vec3 dp2 = dFdy(p);
    vec2 duv1 = dFdx(uv);
    vec2 duv2 = dFdy(uv);
    vec3 dp2perp = cross(dp2, N);
    vec3 dp1perp = cross(N, dp1);
    vec3 T = dp2perp * duv1.x + dp1perp * duv2.x;
    vec3 B = dp2perp * duv1.y + dp1perp * duv2.y;
    float invmax = inversesqrt(max(max(dot(T, T), dot(B, B)), 1e-12));
    return normalize(mat3(T * invmax, B * invmax, N) * tn);
}

// ---- lighting ----
vec3 hemi(vec3 n) { return mix(vec3(0.13, 0.115, 0.085), vec3(0.36, 0.48, 0.72), n.y * 0.5 + 0.5); }
float distGGX(float NoH, float a) { float a2 = a * a; float d = NoH * NoH * (a2 - 1.0) + 1.0; return a2 / (PI * d * d); }
float visSmith(float NoV, float NoL, float a) {
    float k = a * 0.5;
    return 0.25 / ((NoV * (1.0 - k) + k) * (NoL * (1.0 - k) + k));
}
vec3 fresnel(float VoH, vec3 f0) { return f0 + (1.0 - f0) * pow(1.0 - VoH, 5.0); }
vec3 envBRDF(vec3 f0, float roughness, float NoV) {   // cheap fit of the split-sum environment term
    const vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022);
    const vec4 c1 = vec4(1.0, 0.0425, 1.04, -0.04);
    vec4 r = roughness * c0 + c1;
    float a004 = min(r.x * r.x, exp2(-9.28 * NoV)) * r.x + r.y;
    vec2 ab = vec2(-1.04, 1.04) * a004 + r.zw;
    return f0 * ab.x + ab.y;
}
float shadowAmount(vec4 lp) {
    vec3 p = lp.xyz / lp.w * 0.5 + 0.5;
    if (p.z > 1.0 || p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) return 1.0;
    float s = 0.0;
    for (int x = -1; x <= 1; x++)
        for (int y = -1; y <= 1; y++)
            s += texture(uShadow, vec3(p.xy + vec2(float(x), float(y)) * uShadowTexel, p.z - 0.0006));
    return s / 9.0;
}

void main() {
    vec3 N = normalize(vNormal);
    vec3 V = normalize(uCam - vWorld);
    if (!gl_FrontFacing) N = -N;                         // two-sided surfaces
    vec3 Ng = N;

    vec4 base = uBase;
    float metal = uMetal;
    float rough = uRough;
    vec3 emis = uEmissive;
    float h = 0.0;
    bool bumped = false;

    if (uPattern == 1) { vec3 a; surfTerrain(vWorld, a, rough, h); base.rgb = a; bumped = true; }
    else if (uPattern == 2) { vec3 a; surfBricks(vWorld, Ng, base.rgb, a, rough, h); base.rgb = a; bumped = true; }
    else if (uPattern == 3) { vec3 a; surfWood(vWorld, Ng, base.rgb, a, rough, h); base.rgb = a; bumped = true; }
    else if (uPattern == 4) { vec3 a; surfGround(vWorld, a, rough, h); base.rgb *= a; bumped = true; }
    else if (uPattern == 5) { vec3 a; surfWater(vWorld, a, rough, h); base.rgb = a; metal = 0.0; bumped = true; }
    if ((uFlags & 1) != 0) base *= texture(uTexBase, vUV);
    if ((uFlags & 32) != 0 && base.a < uAlphaCut) discard;
    if ((uFlags & 4) != 0) { vec4 mr = texture(uTexMR, vUV); rough *= mr.g; metal *= mr.b; }
    if ((uFlags & 8) != 0) emis *= texture(uTexEmis, vUV).rgb;
    if ((uFlags & 2) != 0) N = normalMapNormal(N, vWorld, vUV, texture(uTexNormal, vUV).xyz * 2.0 - 1.0);
    else if (bumped) N = bumpNormal(N, vWorld, h);

    vec3 col;
    if ((uFlags & 64) != 0) {
        col = emis;                                      // unlit: just glows
    } else {
        rough = clamp(rough, 0.06, 1.0);
        float a = rough * rough;
        vec3 f0 = mix(vec3(0.04), base.rgb, metal);
        vec3 diffuseColor = base.rgb * (1.0 - metal);
        vec3 L = uSunToward;
        vec3 H = normalize(V + L);
        float NoL = clamp(dot(N, L), 0.0, 1.0);
        float NoV = max(dot(N, V), 1e-4);
        float NoH = clamp(dot(N, H), 0.0, 1.0);
        float VoH = clamp(dot(V, H), 0.0, 1.0);
        float sh = ((uFlags & 16) != 0) ? shadowAmount(vLight) : 1.0;
        sh *= smoothstep(0.0, 0.12, dot(Ng, L));           // no light leaking at grazing angles
        vec3 spec = distGGX(NoH, a) * visSmith(NoV, NoL, a) * fresnel(VoH, f0);
        vec3 direct = (diffuseColor / PI + spec) * uSunColor * NoL * sh;

        vec3 R = reflect(-V, N);
        vec3 env = mix(skyColor(R, uSunToward), hemi(R) * 2.2, rough * rough * 0.85);
        float horizonCut = smoothstep(-0.15, 0.25, R.y) * 0.8 + 0.2;
        vec3 ambient = hemi(N) * diffuseColor + env * envBRDF(f0, rough, NoV) * horizonCut * (0.35 + 0.65 * (0.4 + 0.6 * sh));
        col = direct + ambient + emis;
    }

    // fog: far things melt into the sky color
    vec3 toPix = vWorld - uCam;
    float dist = length(toPix);
    vec3 dir = toPix / max(dist, 1e-4);
    float fog = 1.0 - exp(-dist * 0.0065);
    col = mix(col, skyColor(vec3(dir.x, max(dir.y, 0.02), dir.z), uSunToward), fog);

    oColor = vec4(finishColor(col), 1.0);
}
)GLSL";

static const char* const kSkyVS = R"GLSL(#version 300 es
out vec2 vNdc;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));   // one big triangle covering the screen
    vNdc = p * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 0.0, 1.0);
}
)GLSL";

static const char* const kSkyFS = R"GLSL(
in vec2 vNdc;
out vec4 oColor;
uniform vec3 uCamF;
uniform vec3 uCamR;
uniform vec3 uCamU;
uniform vec2 uTan;
uniform vec3 uSunToward;
uniform float uTime;
void main() {
    vec3 d = normalize(uCamF + uCamR * (vNdc.x * uTan.x) + uCamU * (vNdc.y * uTan.y));
    vec3 c = skyColor(d, uSunToward);
    if (d.y > 0.01) {   // soft clouds
        vec2 q = d.xz / (d.y + 0.2) * 1.4 + vec2(uTime * 0.012, 0.0);
        float cl = smoothstep(0.50, 0.82, fbm(vec3(q, 1.7)));
        float fade = smoothstep(0.01, 0.30, d.y);
        vec3 cloudCol = mix(vec3(0.80, 0.82, 0.88), vec3(1.0, 0.96, 0.90), clamp(dot(d, uSunToward) * 0.5 + 0.5, 0.0, 1.0));
        c = mix(c, cloudCol * 1.15, cl * fade * 0.85);
    }
    oColor = vec4(finishColor(c), 1.0);
}
)GLSL";

static const char* const kShadowVS = R"GLSL(#version 300 es
layout(location = 0) in vec3 aPos;
uniform mat4 uModel;
uniform mat4 uLightVP;
void main() { gl_Position = uLightVP * uModel * vec4(aPos, 1.0); }
)GLSL";

static const char* const kShadowFS = R"GLSL(#version 300 es
precision mediump float;
out vec4 oColor;
void main() { oColor = vec4(1.0); }
)GLSL";

static const char* const kUiVS = R"GLSL(#version 300 es
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec4 aColor;
layout(location = 2) in vec2 aUV;
uniform vec2 uScreen;
out vec4 vColor;
out vec2 vUV;
void main() {
    vColor = aColor;
    vUV = aUV;
    gl_Position = vec4(aPos.x / uScreen.x * 2.0 - 1.0, 1.0 - aPos.y / uScreen.y * 2.0, 0.0, 1.0);
}
)GLSL";

static const char* const kUiFS = R"GLSL(#version 300 es
precision highp float;
in vec4 vColor;
in vec2 vUV;
uniform sampler2D uAtlas;
out vec4 oColor;
void main() {
    vec4 c = vColor;
    if (vUV.x >= 0.0) c.a *= textureLod(uAtlas, vUV, 0.0).r;   // text: the font picture gives the shape
    oColor = c;
}
)GLSL";

// ================================================================ helpers
struct GpuMesh { GLuint vao = 0, vbo = 0, ibo = 0; GLsizei count = 0; };
struct GpuMaterial { MatData d; GLuint tex[4] = {0, 0, 0, 0}; };  // textures: base, normal, metal-rough, emissive
struct GpuPart { GpuMesh mesh; Mat4 world; int mat = -1; };
struct GpuModel { std::vector<GpuPart> parts; std::vector<GpuMaterial> mats; };

// Collects the controls and text as colored triangles (the same canvas interface as SoftCanvas).
struct GpuCanvas {
    float k = 1.f;                      // UI units -> screen pixels
    const FontAtlas* font = nullptr;    // when set, text() draws with this font (Kurland)
    std::vector<float> v;               // per vertex: x, y, r, g, b, a, u, v   (u < 0 means plain color)
    void push(float x, float y, const Color& c, float a, float u = -1.f, float w = -1.f) { v.insert(v.end(), {x * k, y * k, c.r, c.g, c.b, a, u, w}); }
    void rect(float x, float y, float w, float h, const Color& c, float a) {
        push(x, y, c, a); push(x + w, y, c, a); push(x + w, y + h, c, a);
        push(x, y, c, a); push(x + w, y + h, c, a); push(x, y + h, c, a);
    }
    void disc(float cx, float cy, float r, const Color& c, float a) {
        const int N = 32;
        for (int i = 0; i < N; i++) {
            float a0 = 2 * PI * i / N, a1 = 2 * PI * (i + 1) / N;
            push(cx, cy, c, a); push(cx + std::cos(a0) * r, cy + std::sin(a0) * r, c, a); push(cx + std::cos(a1) * r, cy + std::sin(a1) * r, c, a);
        }
    }
    void ring(float cx, float cy, float r, const Color& c, float a) {
        const int N = 48;
        float r0 = r - 0.9f, r1 = r + 0.9f;
        for (int i = 0; i < N; i++) {
            float a0 = 2 * PI * i / N, a1 = 2 * PI * (i + 1) / N;
            float c0 = std::cos(a0), s0 = std::sin(a0), c1 = std::cos(a1), s1 = std::sin(a1);
            push(cx + c0 * r0, cy + s0 * r0, c, a); push(cx + c0 * r1, cy + s0 * r1, c, a); push(cx + c1 * r1, cy + s1 * r1, c, a);
            push(cx + c0 * r0, cy + s0 * r0, c, a); push(cx + c1 * r1, cy + s1 * r1, c, a); push(cx + c1 * r0, cy + s1 * r0, c, a);
        }
    }
    // Draws text with the font. y = top of the line. align: 0 left, 1 center, 2 right. Returns false if there is no font.
    bool text(const std::string& s, float x, float y, int scale, const Color& c, int align, float alpha) {
        if (!font || !font->ok()) return false;
        const float f = 7.5f * scale / font->size;
        const float w = font->width(s) * f;
        float pen = align == 1 ? x - w / 2 : (align == 2 ? x - w : x);
        const float base = y + font->ascent * f - 1.1f * scale;
        for (char ch : s) {
            const FontAtlas::Glyph* g = font->glyph(ch);
            if (!g) continue;
            if (g->w > 0 && g->h > 0) {
                float x0 = pen + g->xoff * f, y0 = base + g->yoff * f, x1 = x0 + g->w * f, y1 = y0 + g->h * f;
                float u0 = (float)g->x / font->w, v0 = (float)g->y / font->h, u1 = (float)(g->x + g->w) / font->w, v1 = (float)(g->y + g->h) / font->h;
                push(x0, y0, c, alpha, u0, v0); push(x1, y0, c, alpha, u1, v0); push(x1, y1, c, alpha, u1, v1);
                push(x0, y0, c, alpha, u0, v0); push(x1, y1, c, alpha, u1, v1); push(x0, y1, c, alpha, u0, v1);
            }
            pen += g->adv * f;
        }
        return true;
    }
};

inline void glMat4(GLint loc, const Mat4& m) {  // our matrices are row-major, OpenGL wants column-major
    float t[16];
    for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) t[c * 4 + r] = m.m[r][c];
    glUniformMatrix4fv(loc, 1, GL_FALSE, t);
}
// Matrix for transforming normals (the cofactor matrix of the upper-left 3x3 part).
inline void glNormalMat(GLint loc, const Mat4& m) {
    float a[3][3];
    for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) a[r][c] = m.m[r][c];
    float C[3][3] = {
        {a[1][1] * a[2][2] - a[1][2] * a[2][1], a[1][2] * a[2][0] - a[1][0] * a[2][2], a[1][0] * a[2][1] - a[1][1] * a[2][0]},
        {a[0][2] * a[2][1] - a[0][1] * a[2][2], a[0][0] * a[2][2] - a[0][2] * a[2][0], a[0][1] * a[2][0] - a[0][0] * a[2][1]},
        {a[0][1] * a[1][2] - a[0][2] * a[1][1], a[0][2] * a[1][0] - a[0][0] * a[1][2], a[0][0] * a[1][1] - a[0][1] * a[1][0]}};
    float det = a[0][0] * C[0][0] + a[0][1] * C[0][1] + a[0][2] * C[0][2];
    float sgn = det < 0 ? -1.f : 1.f;  // mirrored objects would flip the normals
    float t[9];
    for (int c = 0; c < 3; c++) for (int r = 0; r < 3; r++) t[c * 3 + r] = C[r][c] * sgn;
    glUniformMatrix3fv(loc, 1, GL_FALSE, t);
}
inline Mat4 orthoGL(float l, float r, float b, float t, float n, float f) {
    Mat4 m;
    m.m[0][0] = 2 / (r - l); m.m[1][1] = 2 / (t - b); m.m[2][2] = -2 / (f - n);
    m.m[0][3] = -(r + l) / (r - l); m.m[1][3] = -(t + b) / (t - b); m.m[2][3] = -(f + n) / (f - n);
    return m;
}
inline Vec3 toLinear(const Color& c) { return Vec3(std::pow(c.r, 2.2f), std::pow(c.g, 2.2f), std::pow(c.b, 2.2f)); }

// Compiles and links a shader program. On failure returns 0 and appends the reason to "log".
inline GLuint glBuildProgram(const std::string& vs, const std::string& fs, std::string& log) {
    auto compile = [&](GLenum type, const std::string& src) -> GLuint {
        GLuint s = glCreateShader(type);
        const char* p = src.c_str();
        glShaderSource(s, 1, &p, nullptr);
        glCompileShader(s);
        GLint ok = 0;
        glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
        if (!ok) {
            char buf[2048]; GLsizei n = 0;
            glGetShaderInfoLog(s, sizeof buf, &n, buf);
            log += (type == GL_VERTEX_SHADER ? "[vertex shader] " : "[fragment shader] ") + std::string(buf, (size_t)n) + "\n";
            glDeleteShader(s);
            return 0;
        }
        return s;
    };
    GLuint v = compile(GL_VERTEX_SHADER, vs), f = compile(GL_FRAGMENT_SHADER, fs);
    if (!v || !f) { if (v) glDeleteShader(v); if (f) glDeleteShader(f); return 0; }
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f);
    glLinkProgram(p);
    glDeleteShader(v); glDeleteShader(f);
    GLint ok = 0;
    glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char buf[2048]; GLsizei n = 0;
        glGetProgramInfoLog(p, sizeof buf, &n, buf);
        log += "[link] " + std::string(buf, (size_t)n) + "\n";
        glDeleteProgram(p);
        return 0;
    }
    return p;
}

// ================================================================ the renderer
class GpuRenderer {
public:
    int drawCalls = 0, trianglesDrawn = 0;

    struct Quality { float scale; int shadow; };   // picture size (1.0 = full screen) and shadow-map size (0 = off)

    // Needs a current OpenGL ES 3.0 context. Returns false (and a reason in "log") if the GPU cannot run it.
    bool init(int screenW, int screenH, std::string& log) {
        shutdown();
        sw_ = screenW; sh_ = screenH;
        const std::string head = kGlslHead;
        pbr_ = glBuildProgram(kPbrVS, head + kGlslCommon + kPbrFS, log);
        sky_ = glBuildProgram(kSkyVS, head + kGlslCommon + kSkyFS, log);
        shadowProg_ = glBuildProgram(kShadowVS, kShadowFS, log);
        uiProg_ = glBuildProgram(kUiVS, kUiFS, log);
        if (!pbr_ || !sky_ || !shadowProg_ || !uiProg_) { shutdown(); return false; }

        auto U = [](GLuint p, const char* n) { return glGetUniformLocation(p, n); };
        l_.model = U(pbr_, "uModel"); l_.normalMat = U(pbr_, "uNormalMat"); l_.vp = U(pbr_, "uVP"); l_.lightVP = U(pbr_, "uLightVP");
        l_.cam = U(pbr_, "uCam"); l_.sunToward = U(pbr_, "uSunToward"); l_.sunColor = U(pbr_, "uSunColor");
        l_.base = U(pbr_, "uBase"); l_.metal = U(pbr_, "uMetal"); l_.rough = U(pbr_, "uRough"); l_.emissive = U(pbr_, "uEmissive");
        l_.pattern = U(pbr_, "uPattern"); l_.flags = U(pbr_, "uFlags"); l_.alphaCut = U(pbr_, "uAlphaCut"); l_.shadowTexel = U(pbr_, "uShadowTexel");
        l_.texBase = U(pbr_, "uTexBase"); l_.texNormal = U(pbr_, "uTexNormal"); l_.texMR = U(pbr_, "uTexMR"); l_.texEmis = U(pbr_, "uTexEmis");
        l_.shadow = U(pbr_, "uShadow");
        l_.time = U(pbr_, "uTime");
        s_.f = U(sky_, "uCamF"); s_.r = U(sky_, "uCamR"); s_.u = U(sky_, "uCamU"); s_.tan = U(sky_, "uTan");
        s_.sun = U(sky_, "uSunToward"); s_.time = U(sky_, "uTime");
        shl_.model = U(shadowProg_, "uModel"); shl_.lightVP = U(shadowProg_, "uLightVP");
        uiScreen_ = U(uiProg_, "uScreen");
        uiAtlas_ = U(uiProg_, "uAtlas");

        glGenVertexArrays(1, &skyVao_);
        glGenVertexArrays(1, &uiVao_);
        glGenBuffers(1, &uiVbo_);
        glBindVertexArray(uiVao_);
        glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 32, (const void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 32, (const void*)8);
        glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 32, (const void*)24);
        glBindVertexArray(0);

        const unsigned char white[4] = {255, 255, 255, 255};
        glGenTextures(1, &white_);
        glBindTexture(GL_TEXTURE_2D, white_);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, white);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        if (!createTargets(log)) { shutdown(); return false; }
        ok_ = true;
        return true;
    }

    void shutdown() {
        ok_ = false;
        for (auto& kv : meshes_) freeMesh(kv.second);
        meshes_.clear();
        for (auto& m : models_) { for (auto& p : m.parts) freeMesh(p.mesh); for (auto& g : m.mats) for (GLuint t : g.tex) if (t) glDeleteTextures(1, &t); }
        models_.clear();
        for (GLuint t : textures_) glDeleteTextures(1, &t);
        textures_.clear();
        for (auto& m : customMeshes_) freeMesh(m);
        customMeshes_.clear();
        if (fontTex_) glDeleteTextures(1, &fontTex_);
        fontTex_ = 0;
        freeTargets();
        if (white_) glDeleteTextures(1, &white_);
        if (skyVao_) glDeleteVertexArrays(1, &skyVao_);
        if (uiVao_) glDeleteVertexArrays(1, &uiVao_);
        if (uiVbo_) glDeleteBuffers(1, &uiVbo_);
        for (GLuint p : {pbr_, sky_, shadowProg_, uiProg_}) if (p) glDeleteProgram(p);
        white_ = skyVao_ = uiVao_ = uiVbo_ = pbr_ = sky_ = shadowProg_ = uiProg_ = 0;
    }

    bool ready() const { return ok_; }
    float scale() const { return cur_.scale; }
    int shadowSize() const { return cur_.shadow; }
    int screenWidth() const { return sw_; }
    int screenHeight() const { return sh_; }
    void setScreenFramebuffer(GLuint fbo) { screenFbo_ = fbo; }  // 0 = the real screen

    // Sets the picture size (1.0 = full screen, below 1 = faster) and the shadow-map size (0 = no shadows).
    // Returns false if the GPU could not create the buffers.
    bool setSettings(float scale, int shadow) {
        scale = std::max(0.3f, std::min(1.5f, scale));
        if (std::fabs(scale - cur_.scale) < 0.001f && shadow == cur_.shadow && sceneFbo_) return true;
        cur_.scale = scale; cur_.shadow = shadow;
        if (!sceneFbo_) return true;   // before init(): used when the buffers are created
        std::string log;
        freeTargets();
        return createTargets(log);
    }
    // Sends your own triangles to the GPU (used for the hilly terrain). Returns a number to put in Entity::meshId.
    int addMesh(const MeshData& d) { customMeshes_.push_back(uploadMesh(d)); return (int)customMeshes_.size() - 1; }
    // Sends the font picture (Kurland) to the GPU.
    void setFont(const FontAtlas& f) {
        if (fontTex_) { glDeleteTextures(1, &fontTex_); fontTex_ = 0; }
        if (!f.ok()) return;
        glGenTextures(1, &fontTex_);
        glBindTexture(GL_TEXTURE_2D, fontTex_);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, f.w, f.h, 0, GL_RED, GL_UNSIGNED_BYTE, f.px.data());
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }

    // Sends a loaded .glb to the GPU. Returns its number (use it as Entity::model).
    int addModel(const ModelData& m) {
        GpuModel gm;
        for (const MatData& md : m.mats) {
            GpuMaterial g;
            g.d = md;
            const int src[4] = {md.texBase, md.texNormal, md.texMR, md.texEmis};
            const bool srgb[4] = {true, false, false, true};
            for (int i = 0; i < 4; i++)
                if (src[i] >= 0 && src[i] < (int)m.images.size() && m.images[src[i]].w > 0) g.tex[i] = makeTexture(m.images[src[i]], srgb[i]);
            gm.mats.push_back(g);
        }
        for (const PartData& p : m.parts) {
            GpuPart gp;
            gp.mesh = uploadMesh(p.mesh);
            gp.world = p.world;
            gp.mat = (p.mat >= 0 && p.mat < (int)m.mats.size()) ? p.mat : -1;
            gm.parts.push_back(gp);
        }
        models_.push_back(std::move(gm));
        return (int)models_.size() - 1;
    }

    // Sends a picture to the GPU (used for the ground). Returns its number (use it as Entity::tex), or -1.
    int addTexture(const ImageData& im, bool srgb = true) {
        if (im.w <= 0 || im.h <= 0 || im.rgba.empty()) return -1;
        textures_.push_back(makeTexture(im, srgb));
        return (int)textures_.size() - 1;
    }

    // Where a point in the world appears on the screen (pixels). False if it is behind the camera.
    bool project(const Vec3& p, float& sx, float& sy) const {
        Vec4 c = lastVP_ * Vec4{p.x, p.y, p.z, 1.f};
        if (c.w <= 0.05f || c.z > c.w) return false;
        sx = (c.x / c.w * 0.5f + 0.5f) * sw_;
        sy = (1.f - (c.y / c.w * 0.5f + 0.5f)) * sh_;
        return true;
    }

    // Draws the whole 3D scene (shadows, sky, objects) and puts it on the screen.
    // "focus" = the point the shadows are centered on (the player).
    void renderScene(const Scene& scene, const Camera& cam, const Vec3& focus, double time) {
        if (!ok_) return;
        drawCalls = trianglesDrawn = 0;
        const Quality& q = cur_;
        camPos_ = cam.pos; focus_ = focus;
        float aspect = (float)rw_ / (float)rh_;
        const float fov = radians(fovDeg_);
        Mat4 vp = Mat4::perspective(fov, aspect, 0.1f, 150.f) * cam.view();
        lastVP_ = vp;
        Vec3 sunToward = normalize(-scene.light.dir);
        Mat4 lightVP;
        bool shadows = q.shadow > 0;
        if (shadows) { lightVP = shadowMatrix(sunToward, focus, q.shadow); renderShadows(scene, lightVP); }

        glBindFramebuffer(GL_FRAMEBUFFER, sceneFbo_);
        glViewport(0, 0, rw_, rh_);
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        glDepthMask(GL_TRUE);
        glClearDepthf(1.f);
        glClearColor(0.5f, 0.6f, 0.8f, 1.f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // sky
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glUseProgram(sky_);
        Vec3 f = cam.forward(), r = normalize(cross(f, Vec3(0, 1, 0))), u = cross(r, f);
        float th = std::tan(fov * 0.5f);
        glUniform3f(s_.f, f.x, f.y, f.z); glUniform3f(s_.r, r.x, r.y, r.z); glUniform3f(s_.u, u.x, u.y, u.z);
        glUniform2f(s_.tan, th * aspect, th);
        glUniform3f(s_.sun, sunToward.x, sunToward.y, sunToward.z);
        glUniform1f(s_.time, (float)time);
        glBindVertexArray(skyVao_);
        glDrawArrays(GL_TRIANGLES, 0, 3);

        // objects
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
        glEnable(GL_CULL_FACE);
        glCullFace(GL_BACK);
        glFrontFace(GL_CCW);
        glUseProgram(pbr_);
        glMat4(l_.vp, vp);
        glMat4(l_.lightVP, lightVP);
        glUniform3f(l_.cam, cam.pos.x, cam.pos.y, cam.pos.z);
        glUniform3f(l_.sunToward, sunToward.x, sunToward.y, sunToward.z);
        glUniform3f(l_.sunColor, 9.0f, 8.2f, 7.0f);
        glUniform1f(l_.shadowTexel, shadows ? 1.f / q.shadow : 0.f);
        glUniform1f(l_.time, (float)time);
        glUniform1i(l_.texBase, 0); glUniform1i(l_.texNormal, 1); glUniform1i(l_.texMR, 2); glUniform1i(l_.texEmis, 3); glUniform1i(l_.shadow, 4);
        glActiveTexture(GL_TEXTURE0 + 4);
        glBindTexture(GL_TEXTURE_2D, shadowTex_);
        for (const auto& up : scene.entities) {
            const Entity& e = *up;
            if (!e.alive || !e.visible) continue;
            if (e.model >= 0 && !e.useMatrix) { float dx = e.pos.x - camPos_.x, dz = e.pos.z - camPos_.z; if (dx * dx + dz * dz > 135.f * 135.f) continue; }   // too far to see
            drawEntity(e, shadows);
        }

        // scale the picture up to the screen
        glBindFramebuffer(GL_READ_FRAMEBUFFER, sceneFbo_);
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER, screenFbo_);
        glBlitFramebuffer(0, 0, rw_, rh_, 0, 0, sw_, sh_, GL_COLOR_BUFFER_BIT, GL_LINEAR);
        glBindFramebuffer(GL_FRAMEBUFFER, screenFbo_);
        glViewport(0, 0, sw_, sh_);
    }

    // Draws the touch controls over the finished picture.
    void drawUI(const GpuCanvas& cv) {
        if (!ok_ || cv.v.empty()) return;
        glBindFramebuffer(GL_FRAMEBUFFER, screenFbo_);
        glViewport(0, 0, sw_, sh_);
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glUseProgram(uiProg_);
        glUniform2f(uiScreen_, (float)sw_, (float)sh_);
        glUniform1i(uiAtlas_, 0);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, fontTex_ ? fontTex_ : white_);
        glBindVertexArray(uiVao_);
        glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
        glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(cv.v.size() * sizeof(float)), cv.v.data(), GL_STREAM_DRAW);
        glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(cv.v.size() / 8));
        glDisable(GL_BLEND);
        glEnable(GL_DEPTH_TEST);
    }

private:
    // ---- surface description used for one draw call ----
    struct Surf {
        Vec3 base{1, 1, 1}; float alpha = 1, metal = 0, rough = 0.7f; Vec3 emissive{0, 0, 0};
        int pattern = 0, flags = 0; float cut = 0.5f; GLuint tex[4] = {0, 0, 0, 0}; bool dbl = false;
    };
    struct Locs { GLint model, normalMat, vp, lightVP, cam, sunToward, sunColor, base, metal, rough, emissive, pattern, flags, alphaCut, shadowTexel, time, texBase, texNormal, texMR, texEmis, shadow; } l_{};
    struct SkyLocs { GLint f, r, u, tan, sun, time; } s_{};
    struct ShadowLocs { GLint model, lightVP; } shl_{};

    bool ok_ = false;
    int sw_ = 1, sh_ = 1, rw_ = 1, rh_ = 1, quality_ = 1, shadowSize_ = 0;
    GLuint pbr_ = 0, sky_ = 0, shadowProg_ = 0, uiProg_ = 0, white_ = 0, skyVao_ = 0, uiVao_ = 0, uiVbo_ = 0;
    GLint uiScreen_ = 0;
    GLuint sceneFbo_ = 0, sceneColor_ = 0, sceneDepth_ = 0, shadowFbo_ = 0, shadowTex_ = 0, screenFbo_ = 0;
    std::unordered_map<const Mesh*, GpuMesh> meshes_;
    std::vector<GpuModel> models_;
    std::vector<GLuint> textures_;
    std::vector<GpuMesh> customMeshes_;
    GLuint fontTex_ = 0;
    GLint uiAtlas_ = 0;
    Quality cur_{0.75f, 1024};
    Mat4 lastVP_;
    Vec3 camPos_, focus_;
    float fovDeg_ = 66.f;

    GpuMesh uploadMesh(const MeshData& d) {
        GpuMesh m;
        glGenVertexArrays(1, &m.vao); glGenBuffers(1, &m.vbo); glGenBuffers(1, &m.ibo);
        glBindVertexArray(m.vao);
        glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
        glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(d.v.size() * sizeof(float)), d.v.data(), GL_STATIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ibo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(d.idx.size() * sizeof(uint32_t)), d.idx.data(), GL_STATIC_DRAW);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (const void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 32, (const void*)12);
        glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 32, (const void*)24);
        glBindVertexArray(0);
        m.count = (GLsizei)d.idx.size();
        return m;
    }
    void freeMesh(GpuMesh& m) {
        if (m.vao) glDeleteVertexArrays(1, &m.vao);
        if (m.vbo) glDeleteBuffers(1, &m.vbo);
        if (m.ibo) glDeleteBuffers(1, &m.ibo);
        m = GpuMesh();
    }
    GLuint makeTexture(const ImageData& im, bool srgb) {
        GLuint t = 0;
        glGenTextures(1, &t);
        glBindTexture(GL_TEXTURE_2D, t);
        glTexImage2D(GL_TEXTURE_2D, 0, srgb ? GL_SRGB8_ALPHA8 : GL_RGBA8, im.w, im.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, im.rgba.data());
        glGenerateMipmap(GL_TEXTURE_2D);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        return t;
    }

    // The picture buffer (smaller than the screen) and the shadow map.
    bool createTargets(std::string& log) {
        const Quality& q = cur_;
        rw_ = std::max(64, (int)(sw_ * q.scale)); rh_ = std::max(48, (int)(sh_ * q.scale));
        glGenFramebuffers(1, &sceneFbo_); glGenRenderbuffers(1, &sceneColor_); glGenRenderbuffers(1, &sceneDepth_);
        glBindRenderbuffer(GL_RENDERBUFFER, sceneColor_); glRenderbufferStorage(GL_RENDERBUFFER, GL_RGBA8, rw_, rh_);
        glBindRenderbuffer(GL_RENDERBUFFER, sceneDepth_); glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, rw_, rh_);
        glBindFramebuffer(GL_FRAMEBUFFER, sceneFbo_);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, sceneColor_);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, sceneDepth_);
        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) { log += "scene framebuffer incomplete\n"; return false; }

        shadowSize_ = q.shadow > 0 ? q.shadow : 4;
        glGenTextures(1, &shadowTex_);
        glBindTexture(GL_TEXTURE_2D, shadowTex_);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, shadowSize_, shadowSize_, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
        glGenFramebuffers(1, &shadowFbo_);
        glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo_);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowTex_, 0);
        const GLenum none = GL_NONE;
        glDrawBuffers(1, &none);
        glReadBuffer(GL_NONE);
        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) { log += "shadow framebuffer incomplete\n"; return false; }
        glBindFramebuffer(GL_FRAMEBUFFER, screenFbo_);
        return true;
    }
    void freeTargets() {
        if (sceneFbo_) glDeleteFramebuffers(1, &sceneFbo_);
        if (sceneColor_) glDeleteRenderbuffers(1, &sceneColor_);
        if (sceneDepth_) glDeleteRenderbuffers(1, &sceneDepth_);
        if (shadowFbo_) glDeleteFramebuffers(1, &shadowFbo_);
        if (shadowTex_) glDeleteTextures(1, &shadowTex_);
        sceneFbo_ = sceneColor_ = sceneDepth_ = shadowFbo_ = shadowTex_ = 0;
    }

    // Sun camera: a box around the player, snapped to the shadow-map pixels so shadows do not shimmer.
    Mat4 shadowMatrix(const Vec3& sunToward, const Vec3& focus, int size) {
        const float R = 26.f;
        Mat4 view = Mat4::lookAt(focus + sunToward * 70.f, focus, Vec3(0, 1, 0));
        Mat4 vp = orthoGL(-R, R, -R, R, 1.f, 150.f) * view;
        Vec4 o = vp * Vec4{focus.x, focus.y, focus.z, 1.f};
        float tx = o.x * size * 0.5f, ty = o.y * size * 0.5f;
        return Mat4::translate(Vec3((std::round(tx) - tx) * 2.f / size, (std::round(ty) - ty) * 2.f / size, 0)) * vp;
    }

    bool castsShadow(const Entity& e) const {
        if (!e.alive || e.unlit || e.name == "ground" || e.name == "held_axe" || e.pattern == 5) return false;
        return e.visible && (e.mesh || e.model >= 0);   // the player is only a collision box: never drawn, so it casts no shadow
    }

    void renderShadows(const Scene& scene, const Mat4& lightVP) {
        glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo_);
        glViewport(0, 0, shadowSize_, shadowSize_);
        glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDepthFunc(GL_LEQUAL);
        glEnable(GL_CULL_FACE); glCullFace(GL_BACK);
        glClearDepthf(1.f);
        glClear(GL_DEPTH_BUFFER_BIT);
        glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
        glEnable(GL_POLYGON_OFFSET_FILL);
        glPolygonOffset(2.5f, 5.f);
        glUseProgram(shadowProg_);
        glMat4(shl_.lightVP, lightVP);
        for (const auto& up : scene.entities) {
            const Entity& e = *up;
            if (!castsShadow(e)) continue;
            { float dx = e.pos.x - focus_.x, dz = e.pos.z - focus_.z; if (dx * dx + dz * dz > 48.f * 48.f) continue; }   // outside the shadow map
            Mat4 em = e.matrix();
            if (e.model >= 0 && e.model < (int)models_.size()) {
                for (const GpuPart& p : models_[e.model].parts) drawGeometry(p.mesh, em * p.world, true);
            } else {
                drawGeometry(meshFor(e.mesh), em, true);
            }
        }
        glDisable(GL_POLYGON_OFFSET_FILL);
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    }

    const GpuMesh& meshFor(const Mesh* m) {
        auto it = meshes_.find(m);
        if (it == meshes_.end()) it = meshes_.emplace(m, uploadMesh(buildMeshData(*m))).first;
        return it->second;
    }

    void drawGeometry(const GpuMesh& m, const Mat4& model, bool shadowPass) {
        if (shadowPass) glMat4(shl_.model, model);
        else { glMat4(l_.model, model); glNormalMat(l_.normalMat, model); }
        glBindVertexArray(m.vao);
        glDrawElements(GL_TRIANGLES, m.count, GL_UNSIGNED_INT, (const void*)0);
        drawCalls++; trianglesDrawn += m.count / 3;
    }

    void applySurf(const Surf& s, bool shadows) {
        int flags = s.flags | (shadows ? 16 : 0);
        glUniform4f(l_.base, s.base.x, s.base.y, s.base.z, s.alpha);
        glUniform1f(l_.metal, s.metal); glUniform1f(l_.rough, s.rough);
        glUniform3f(l_.emissive, s.emissive.x, s.emissive.y, s.emissive.z);
        glUniform1i(l_.pattern, s.pattern); glUniform1i(l_.flags, flags); glUniform1f(l_.alphaCut, s.cut);
        for (int i = 0; i < 4; i++) {
            glActiveTexture(GL_TEXTURE0 + i);
            glBindTexture(GL_TEXTURE_2D, s.tex[i] ? s.tex[i] : white_);
        }
        if (s.dbl) glDisable(GL_CULL_FACE); else glEnable(GL_CULL_FACE);
    }

    void drawEntity(const Entity& e, bool shadows) {
        Mat4 em = e.matrix();
        Vec3 tint = toLinear(e.color);
        if (e.model >= 0 && e.model < (int)models_.size()) {
            const GpuModel& gm = models_[e.model];
            for (const GpuPart& p : gm.parts) {
                Surf s;
                if (p.mat >= 0) {
                    const GpuMaterial& g = gm.mats[p.mat];
                    s.base = g.d.base * tint; s.alpha = g.d.alpha; s.metal = g.d.metal; s.rough = g.d.rough;
                    s.emissive = g.d.emissive + e.emissive; s.cut = g.d.cut; s.dbl = g.d.dbl;
                    if (g.d.mask) s.flags |= 32;
                    for (int i = 0; i < 4; i++) { s.tex[i] = g.tex[i]; if (g.tex[i]) s.flags |= (1 << i); }
                } else {
                    s.base = tint; s.metal = e.metallic; s.rough = e.roughness; s.emissive = e.emissive;
                }
                applySurf(s, shadows);
                drawGeometry(p.mesh, em * p.world, false);
            }
            return;
        }
        if (!e.mesh && e.meshId < 0) return;
        Surf s;
        s.base = tint; s.metal = e.metallic; s.rough = e.roughness; s.emissive = e.emissive; s.pattern = e.pattern;
        if (e.pattern == 4 && e.tex >= 0 && e.tex < (int)textures_.size()) s.tex[0] = textures_[e.tex];
        if (e.unlit) { s.flags |= 64; s.emissive = tint * 2.5f; }
        applySurf(s, shadows);
        if (e.meshId >= 0) { if (e.meshId < (int)customMeshes_.size()) drawGeometry(customMeshes_[e.meshId], em, false); }
        else drawGeometry(meshFor(e.mesh), em, false);
    }
};
