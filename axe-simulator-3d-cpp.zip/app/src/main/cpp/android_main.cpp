// android_main.cpp - the Android app around Axe Simulator 3D (all C++).
//
//   1. It starts the GPU renderer (OpenGL ES 3.0) and the game (axe_sim.h).
//   2. If the phone's GPU cannot run it, it falls back to the old software renderer (a plain demo world).
//   3. Touch controls work in both modes. Progress is saved in the app's private folder.
#include <cctype>
#include <jni.h>
#include <android/asset_manager.h>
#include <android/input.h>
#include <android/log.h>
#include <android/looper.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <EGL/egl.h>

#define main engine_terminal_main  // the terminal version's main() is not used on Android
#include "engine.cpp"
#undef main
#include "touch_ui.h"
#include "gltf_loader.h"
#include "gpu_renderer.h"
#include "axe_sim.h"

#ifndef EGL_OPENGL_ES3_BIT
#define EGL_OPENGL_ES3_BIT 0x00000040
#endif
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "AxeSim", __VA_ARGS__)

namespace {

constexpr int SOFTWARE_PICTURE_WIDTH = 320;  // used only by the software fallback

struct AndroidApp {
    using Clock = std::chrono::steady_clock;
    android_app* app = nullptr;
    Game game;
    TouchUI ui;
    GpuRenderer gpu;
    AxeSim sim;

    EGLDisplay dpy = EGL_NO_DISPLAY;
    EGLSurface surf = EGL_NO_SURFACE;
    EGLContext ctx = EGL_NO_CONTEXT;
    bool gpuOn = false, forceSoftware = false, assetsLoaded = false, worldBuilt = false;
    bool hasWindow = false, resumed = false;
    int screenW = 1, screenH = 1, quality = 1;
    Clock::time_point start = Clock::now(), last = Clock::now();
    double acc = 0, fpsTimer = 0;
    int fpsFrames = 0;

    bool running() const { return hasWindow && resumed; }

    // ---------------------------------------------------------------- AdMob banner (lives in MainActivity.java)
    // The banner sits at the bottom centre. The menus use that spot (their CLOSE button), so the banner is hidden
    // while a menu is open and shown again when it closes.
    bool bannerWanted = true;

    void setBannerVisible(bool visible) {
        ANativeActivity* act = app ? app->activity : nullptr;
        if (!act || !act->vm || !act->clazz) return;
        JNIEnv* env = nullptr;
        bool attached = false;
        if (act->vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
            if (act->vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
            attached = true;
        }
        jclass cls = env->GetObjectClass(act->clazz);
        jmethodID mid = cls ? env->GetMethodID(cls, "setBannerVisible", "(Z)V") : nullptr;
        if (mid) env->CallVoidMethod(act->clazz, mid, (jboolean)(visible ? JNI_TRUE : JNI_FALSE));
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (cls) env->DeleteLocalRef(cls);
        if (attached) act->vm->DetachCurrentThread();
    }

    void syncBanner() {
        if (!gpuOn || !worldBuilt) return;
        bool want = sim.panel() == AxeSim::P_NONE;
        if (want == bannerWanted) return;
        bannerWanted = want;
        setBannerVisible(want);
    }

    // ---------------------------------------------------------------- game files inside the APK
    void loadGameAssets() {
        if (assetsLoaded) return;
        assetsLoaded = true;
        sim.dataDir = app->activity->internalDataPath ? app->activity->internalDataPath : ".";
        sim.assets.read = [this](const std::string& name, std::vector<uint8_t>& out) {
            AAsset* a = AAssetManager_open(app->activity->assetManager, name.c_str(), AASSET_MODE_BUFFER);
            if (!a) return false;
            const uint8_t* b = (const uint8_t*)AAsset_getBuffer(a);
            size_t n = (size_t)AAsset_getLength(a);
            if (b) out.assign(b, b + n);
            AAsset_close(a);
            return b != nullptr;
        };
        std::string err;
        bool ok = sim.loadAssets(&err);
        LOGI("assets %s %s, textures %s", ok ? "loaded" : "NOT loaded:", err.c_str(), sim.grass.w > 0 ? "decoded" : "missing (stb_image.h not in the build)");
    }

    // ---------------------------------------------------------------- EGL (the link between OpenGL and the window)
    bool initEGL() {
        dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
        if (dpy == EGL_NO_DISPLAY || !eglInitialize(dpy, nullptr, nullptr)) return false;
        const EGLint cfgAttr[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                                  EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_NONE};
        EGLConfig cfg = nullptr;
        EGLint n = 0;
        if (!eglChooseConfig(dpy, cfgAttr, &cfg, 1, &n) || n < 1) return false;
        EGLint format = 0;
        eglGetConfigAttrib(dpy, cfg, EGL_NATIVE_VISUAL_ID, &format);
        ANativeWindow_setBuffersGeometry(app->window, 0, 0, format);
        surf = eglCreateWindowSurface(dpy, cfg, app->window, nullptr);
        const EGLint ctxAttr[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
        ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, ctxAttr);
        if (surf == EGL_NO_SURFACE || ctx == EGL_NO_CONTEXT) return false;
        if (!eglMakeCurrent(dpy, surf, surf, ctx)) return false;
        EGLint w = 0, h = 0;
        eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
        eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
        if (w > 0 && h > 0) { screenW = w; screenH = h; }
        eglSwapInterval(dpy, 1);
        return true;
    }
    void termEGL() {
        if (dpy != EGL_NO_DISPLAY) {
            eglMakeCurrent(dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
            if (ctx != EGL_NO_CONTEXT) eglDestroyContext(dpy, ctx);
            if (surf != EGL_NO_SURFACE) eglDestroySurface(dpy, surf);
            eglTerminate(dpy);
        }
        dpy = EGL_NO_DISPLAY; ctx = EGL_NO_CONTEXT; surf = EGL_NO_SURFACE;
    }
    void teardownGraphics() {
        if (gpuOn) { gpu.shutdown(); gpuOn = false; }
        termEGL();
    }

    // ---------------------------------------------------------------- window
    // Called when the window appears or changes size. Picks the GPU renderer if possible.
    void setupWindow() {
        if (!app->window) return;
        teardownGraphics();
        ANativeWindow_setBuffersGeometry(app->window, 0, 0, WINDOW_FORMAT_RGBA_8888);  // 0,0 = the real screen size
        screenW = std::max(1, (int)ANativeWindow_getWidth(app->window));
        screenH = std::max(1, (int)ANativeWindow_getHeight(app->window));
        loadGameAssets();

        if (!forceSoftware) {
            std::string log;
            if (initEGL() && gpu.init(screenW, screenH, log)) {
                gpuOn = true;
                LOGI("GPU renderer running: %s", (const char*)glGetString(GL_RENDERER));
            } else {
                LOGI("GPU renderer not available, using the software renderer. %s", log.c_str());
                forceSoftware = true;
                teardownGraphics();
                ANativeWindow_setBuffersGeometry(app->window, 0, 0, WINDOW_FORMAT_RGBA_8888);
            }
        }
        if (gpuOn) {
            ui.resize(400, std::max(120, 400 * screenH / screenW));
            sim.uploadToGpu(gpu);                     // models and ground picture go to the GPU
            if (!worldBuilt) { sim.attach(game, ui, gpu); game.buildLevel(); worldBuilt = true; }
        } else {
            int bw = SOFTWARE_PICTURE_WIDTH, bh = std::max(80, (int)((float)bw * screenH / screenW));
            ANativeWindow_setBuffersGeometry(app->window, bw, bh, WINDOW_FORMAT_RGBA_8888);
            game.renderer.resize(bw, bh);
            ui.resize(bw, bh);
        }
        hasWindow = true;
        LOGI("window %dx%d, mode: %s", screenW, screenH, gpuOn ? "GPU" : "software");
    }

    // ---------------------------------------------------------------- one frame
    void frame() {
        auto t = Clock::now();
        double dt = std::min(0.1, std::chrono::duration<double>(t - last).count());
        last = t;
        game.now = std::chrono::duration<double>(t - start).count();
        acc += dt;

        game.input.beginFrame();
        ui.apply(game, game.now);
        game.handleInput();
        if (gpuOn && worldBuilt) { sim.fps = game.fps; sim.update((float)dt, game.now); }
        while (acc >= Config::FIXED_DT) { game.update(Config::FIXED_DT); acc -= Config::FIXED_DT; }
        game.fps = game.fps * 0.9f + 0.1f * (float)(dt > 0 ? 1.0 / dt : 0.0);
        game.interpolateCamera((float)(acc / Config::FIXED_DT));   // smooth motion between physics steps
        if (gpuOn && worldBuilt) sim.lateUpdate();                 // the axe follows the FINAL camera (no more vibration)
        syncBanner();                                              // hide the ad while a menu is open

        if (gpuOn) renderGpu(dt); else renderSoftware();
    }

    void renderGpu(double) {
        gpu.renderScene(game.scene, game.cam, game.player->pos, game.now);
        GpuCanvas cv;
        cv.k = (float)screenW / ui.w;
        ui.draw(cv, -1, 0, -1);        // joystick and buttons
        sim.drawUI(cv);                // counters, menus (all in the Kurland font)
        gpu.drawUI(cv);
        if (!eglSwapBuffers(dpy, surf)) {
            LOGI("eglSwapBuffers failed (0x%x), restarting graphics", (unsigned)eglGetError());
            setupWindow();
        }
    }

    void renderSoftware() {
        game.render();
        SoftCanvas cv{game.renderer.fb};
        ui.draw(cv, game.coins, game.coinsTotal, (int)(game.fps + 0.5f));
        UiText::draw(cv, "NEEDS OPENGL ES 3 - SHOWING A DEMO", game.renderer.fb.w / 2.f, game.renderer.fb.h - 8.f, 1, Color{1.f, 0.6f, 0.4f}, 1);
        ANativeWindow_Buffer buf;
        if (ANativeWindow_lock(app->window, &buf, nullptr) != 0) return;
        const FrameBuffer& fb = game.renderer.fb;
        int w = std::min(fb.w, (int)buf.width), h = std::min(fb.h, (int)buf.height);
        uint32_t* out = (uint32_t*)buf.bits;
        auto q = [](float v) { return (uint32_t)(clampf(v, 0.f, 1.f) * 255.f); };
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                const Color& c = fb.pix[(size_t)y * fb.w + x];
                out[(size_t)y * buf.stride + x] = 0xFF000000u | (q(c.b) << 16) | (q(c.g) << 8) | q(c.r);
            }
        ANativeWindow_unlockAndPost(app->window);
    }
};

// Touch events from Android -> TouchUI (converted to the UI's own units).
int32_t onInput(android_app* app, AInputEvent* ev) {
    AndroidApp* a = (AndroidApp*)app->userData;
    if (AInputEvent_getType(ev) != AINPUT_EVENT_TYPE_MOTION) return 0;  // let Android handle keys (Back)
    int32_t act = AMotionEvent_getAction(ev);
    int kind = act & AMOTION_EVENT_ACTION_MASK;
    int index = (act & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    float sx = (float)a->ui.w / a->screenW, sy = (float)a->ui.h / a->screenH;
    auto send = [&](int action, int i) {
        a->ui.touch(action, AMotionEvent_getPointerId(ev, i), AMotionEvent_getX(ev, i) * sx, AMotionEvent_getY(ev, i) * sy);
    };
    if (kind == AMOTION_EVENT_ACTION_DOWN || kind == AMOTION_EVENT_ACTION_POINTER_DOWN) send(0, index);
    else if (kind == AMOTION_EVENT_ACTION_UP || kind == AMOTION_EVENT_ACTION_POINTER_UP) send(2, index);
    else if (kind == AMOTION_EVENT_ACTION_CANCEL) a->ui.releaseAll();
    else if (kind == AMOTION_EVENT_ACTION_MOVE)
        for (int i = 0; i < (int)AMotionEvent_getPointerCount(ev); i++) send(1, i);
    return 1;
}

// Lifecycle events: window created/destroyed, app paused/resumed.
void onCmd(android_app* app, int32_t cmd) {
    AndroidApp* a = (AndroidApp*)app->userData;
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
        case APP_CMD_WINDOW_RESIZED: a->setupWindow(); break;
        case APP_CMD_TERM_WINDOW: a->teardownGraphics(); a->hasWindow = false; break;
        case APP_CMD_RESUME:
        case APP_CMD_GAINED_FOCUS: a->resumed = true; a->last = AndroidApp::Clock::now(); break;
        case APP_CMD_PAUSE:
        case APP_CMD_LOST_FOCUS: a->resumed = false; a->ui.releaseAll(); if (a->worldBuilt) a->sim.save(); break;
        default: break;
    }
}

}  // namespace

// The entry point of a NativeActivity app (it replaces main()).
void android_main(android_app* state) {
    static AndroidApp a;
    a.app = state;
    a.hasWindow = a.resumed = false;
    a.bannerWanted = true;   // a fresh activity starts with the ad allowed
    state->userData = &a;
    state->onAppCmd = onCmd;
    state->onInputEvent = onInput;
    a.game.init("");

    while (true) {
        // Sleep until something happens while paused; do not wait while playing.
        for (;;) {
            int events = 0;
            android_poll_source* source = nullptr;
            int id = ALooper_pollOnce(a.running() ? 0 : -1, nullptr, &events, (void**)&source);
            if (id < 0) break;
            if (source) source->process(state, source);
            if (state->destroyRequested) { if (a.worldBuilt) a.sim.save(); a.teardownGraphics(); return; }
        }
        if (a.running()) a.frame();
    }
}
