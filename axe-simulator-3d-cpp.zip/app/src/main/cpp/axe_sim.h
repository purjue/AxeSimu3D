// axe_sim.h - Axe Simulator 3D: the game itself, written in C++.
// Include after engine.cpp, touch_ui.h, gltf_loader.h and gpu_renderer.h.
//
// What is in here:
//   CompanionBrain : the offline "brain" of the four companions. No internet. It remembers old chats in a file.
//   AxeSim         : the world (grass, 30 pine trees, food stall, travel port), the player's axe, chopping,
//                    shop, companions, menus, saving.
#pragma once
#include <sstream>

struct AxeAssets {
    std::function<bool(const std::string&, std::vector<uint8_t>&)> read;   // reads a file from the app's assets
};

// ================================================================ offline companion brain
class CompanionBrain {
public:
    static constexpr int COUNT = 4;
    enum Intent { GREET, HOW, WHO, CHOP, FOLLOW, REST, JOKE, REMEMBER, INTENTS };
    static const char* name(int i) { static const char* n[COUNT] = {"Pranjal", "Pro", "Devil", "Array"}; return n[i]; }
    static const char* phrase(int i) {
        static const char* p[INTENTS] = {"HI", "HOW ARE YOU", "WHO ARE YOU", "CHOP TREES", "FOLLOW ME", "REST", "TELL A JOKE", "REMEMBER ME?"};
        return p[i];
    }
    struct Memory { int talks = 0, chopped = 0, last = -1; std::vector<std::string> lines; };
    struct Facts { int staminaPct = 100, wood = 0, coins = 0, level = 1; };
    Memory mem[COUNT];

    // Answers a message and remembers the conversation.
    std::string talk(int who, int intent, const Facts& f) {
        Memory& m = mem[who];
        const int v = m.talks % 3;
        std::string r;
        switch (intent) {
            case GREET: {
                static const char* a[3] = {"Hello! Nice to see you.", "Hey boss! Ready to chop?", "Hi hi! Lovely day for wood."};
                r = a[v];
                if (m.talks > 0) r += " Good to talk again.";
                break;
            }
            case HOW:
                r = "I have " + std::to_string(f.staminaPct) + " percent energy. ";
                r += f.staminaPct > 60 ? "Feeling strong!" : (f.staminaPct > 25 ? "A bit tired." : "I need a rest!");
                break;
            case WHO: r = std::string("I am ") + name(who) + ", your axe buddy on level " + std::to_string(f.level) + "."; break;
            case CHOP: r = "Okay! I will chop trees near you."; break;
            case FOLLOW: r = "Sure, I will stay close to you."; break;
            case REST: r = "Thanks, I will rest a little."; break;
            case JOKE: {
                static const char* j[3] = {"Why did the tree get a job? To branch out!", "I told my axe a joke. It split its sides.", "What do trees do online? They log in."};
                r = j[v];
                break;
            }
            case REMEMBER:
                if (m.talks == 0) r = "We just met! Tell me more.";
                else r = "Yes! We talked " + std::to_string(m.talks) + " times. Last you said " + (m.last >= 0 ? phrase(m.last) : "hello") +
                         ". I chopped " + std::to_string(m.chopped) + " trees for you.";
                break;
            default: r = "Hmm?"; break;
        }
        static const char* sig[COUNT] = {"Happy to help, friend!", "Easy work.", "Hehe, watch me.", "Calculating... done."};
        r += " ";
        r += sig[who];
        m.lines.push_back(std::string("you: ") + phrase(intent));
        m.lines.push_back(std::string(name(who)) + ": " + r);
        while (m.lines.size() > 24) m.lines.erase(m.lines.begin());
        m.last = intent;
        m.talks++;
        return r;
    }
    void save(std::ostream& o) const {
        for (int i = 0; i < COUNT; i++) {
            o << "M " << i << " " << mem[i].talks << " " << mem[i].chopped << " " << mem[i].last << "\n";
            for (const std::string& l : mem[i].lines) o << "H " << i << " " << l << "\n";
        }
    }
    void load(std::istream& in) {
        for (auto& m : mem) m = Memory();
        std::string line;
        while (std::getline(in, line)) {
            std::istringstream ss(line);
            std::string tag;
            int idx = -1;
            ss >> tag >> idx;
            if (idx < 0 || idx >= COUNT) continue;
            if (tag == "M") ss >> mem[idx].talks >> mem[idx].chopped >> mem[idx].last;
            else if (tag == "H") {
                std::string rest;
                std::getline(ss, rest);
                if (!rest.empty() && rest[0] == ' ') rest.erase(0, 1);
                mem[idx].lines.push_back(rest);
            }
        }
    }
};

// ================================================================ the game
class AxeSim {
public:
    enum Panel { P_NONE, P_SHOP, P_PORT, P_CHAT };
    struct PBtn { float x, y, w, h; std::string label; int id; bool on; };

    // ---- set up by the platform code ----
    AxeAssets assets;
    std::string dataDir = ".";                                             // where the save files go
    std::function<void(const std::string&, ModelData&)> afterModelLoad;    // used by tests
    ImageData grass;                                                       // ground picture
    CompanionBrain brain;
    float fps = 0.f;

    // ---- progress (saved) ----
    int wood = 0, coins = 0, axeLevel = 1, staminaLevel = 1, level = 1, chopped = 0;
    float stamina = 100.f;

    static constexpr float kWorldHalf = 120.f;   // trees grow inside a 240 x 240 m square (the ground is 256 m)
    static constexpr int kWoodPrice = 3;
    float maxStamina() const { return 100.f + 20.f * (staminaLevel - 1); }
    float axeDamage() const { return 10.f + 5.f * (axeLevel - 1); }
    int axeCost() const { return 30 * axeLevel; }
    int staminaCost() const { return 25 * staminaLevel; }

    // ---------------------------------------------------------------- loading
    bool loadAssets(std::string* err = nullptr) {
        auto model = [&](const char* file, ModelData& m) -> bool {
            std::vector<uint8_t> bytes;
            std::string e;
            if (!assets.read || !assets.read(file, bytes)) { if (err) *err += std::string("missing ") + file + "; "; return false; }
            if (!loadGLB(bytes.data(), bytes.size(), m, &e)) { if (err) *err += std::string(file) + ": " + e + "; "; return false; }
            if (afterModelLoad) afterModelLoad(file, m);
            return true;
        };
        bool ok = model("models/axe.glb", axe_);
        ok = model("models/food_stall_in_edo.glb", stall_) && ok;
        ok = model("models/pine_tree_low-poly.glb", pine_) && ok;
        if (!stall_.parts.empty()) fitModelOnGround(stall_, 3.4f);
        if (!pine_.parts.empty()) fitModelOnGround(pine_, 9.f);
        std::vector<uint8_t> bytes;
        if (assets.read && assets.read("textures/grass_1k.jpg", bytes)) decodeImage(bytes.data(), bytes.size(), grass);
        return ok;
    }
    // Sends the models and the ground picture to the GPU. Call again if the GPU was restarted.
    void uploadToGpu(GpuRenderer& gpu) {
        axeId_ = axe_.parts.empty() ? -1 : gpu.addModel(axe_);
        stallId_ = stall_.parts.empty() ? -1 : gpu.addModel(stall_);
        pineId_ = pine_.parts.empty() ? -1 : gpu.addModel(pine_);
        groundTex_ = gpu.addTexture(grass, true);
    }
    void attach(Game& g, TouchUI& ui, GpuRenderer& gpu) {
        game_ = &g; ui_ = &ui; gpu_ = &gpu;
        ui.simLayout = true;
        g.playerStart = Vec3(0, 0.85f, 12);
        g.eyeHeight = 0.72f;
        g.levelOverride = [this](Game& gg) { buildWorld(gg); };
        g.onLevelBuilt = [this](Game& gg) { afterLevelBuilt(gg); };
        load();
    }

    // ---------------------------------------------------------------- saving
    void save() const {
        { std::ofstream f(dataDir + "/axe_save.txt");
          f << "wood=" << wood << "\ncoins=" << coins << "\naxe=" << axeLevel << "\nstamina=" << staminaLevel << "\nlevel=" << level << "\nchopped=" << chopped << "\n"; }
        std::ofstream m(dataDir + "/axe_memory.txt");
        brain.save(m);
    }
    void load() {
        { std::ifstream f(dataDir + "/axe_save.txt");
          std::string line;
          while (std::getline(f, line)) {
              size_t p = line.find('=');
              if (p == std::string::npos) continue;
              std::string k = line.substr(0, p);
              int v = std::atoi(line.c_str() + p + 1);
              if (k == "wood") wood = v; else if (k == "coins") coins = v; else if (k == "axe") axeLevel = std::max(1, v);
              else if (k == "stamina") staminaLevel = std::max(1, v); else if (k == "level") level = (v == 2 ? 2 : 1); else if (k == "chopped") chopped = v;
          } }
        std::ifstream m(dataDir + "/axe_memory.txt");
        if (m) brain.load(m);
        stamina = maxStamina();
    }

    // ---------------------------------------------------------------- the world
    void buildWorld(Game& g) {
        Scene& sc = g.scene;
        trees_.clear(); mates_.clear(); held_ = nullptr;
        rng_ = 987654u + (uint32_t)level * 7919u;
        panel_ = P_NONE; swingT_ = -1.f; nearby_ = 0;

        Entity* ground = sc.add("ground", &groundMesh_, Vec3(0, 0, 0), Vec3(1, 1, 1), level == 2 ? Color{1.0f, 0.85f, 0.6f} : Color{0.70f, 1.15f, 0.95f});   // green meadow / warm autumn
        ground->pattern = groundTex_ >= 0 ? 4 : 1;
        ground->tex = groundTex_;
        ground->roughness = 0.95f;
        Entity* slab = sc.add("slab", &cubeMesh_, Vec3(0, -0.5f, 0), Vec3(300, 1, 300), Color{1, 1, 1});   // invisible floor to stand on
        slab->solid = true; slab->visible = false;
        const float e = 128.5f;                                                                           // invisible walls at the edge
        const Vec3 wp[4] = {{0, 3, -e}, {0, 3, e}, {-e, 3, 0}, {e, 3, 0}}, ws[4] = {{260, 8, 1}, {260, 8, 1}, {1, 8, 260}, {1, 8, 260}};
        for (int i = 0; i < 4; i++) { Entity* w = sc.add("wall", &cubeMesh_, wp[i], ws[i], Color{1, 1, 1}); w->solid = true; w->visible = false; }

        // food stall (the shop): its counter faces the start point
        Entity* stall = sc.add("stall", nullptr, Vec3(kStallX, 0, kStallZ), Vec3(1, 1, 1), Color{1, 1, 1});
        stall->model = stallId_; stall->rot.y = -PI / 2;
        Entity* stallBox = sc.add("stallbox", &cubeMesh_, Vec3(kStallX, 1.7f, kStallZ), Vec3(3.7f, 3.4f, 2.4f), Color{1, 1, 1});
        stallBox->solid = true; stallBox->visible = false;

        // travel port: a wooden gate with a glowing portal
        const Color wood3{0.55f, 0.36f, 0.22f};
        Entity* p1 = sc.add("post", &cubeMesh_, Vec3(kPortX, 2.1f, kPortZ - 1.8f), Vec3(0.5f, 4.2f, 0.5f), wood3);
        Entity* p2 = sc.add("post", &cubeMesh_, Vec3(kPortX, 2.1f, kPortZ + 1.8f), Vec3(0.5f, 4.2f, 0.5f), wood3);
        Entity* beam = sc.add("beam", &cubeMesh_, Vec3(kPortX, 4.45f, kPortZ), Vec3(0.7f, 0.5f, 4.8f), wood3);
        p1->solid = p2->solid = true; p1->pattern = p2->pattern = beam->pattern = 3;
        Entity* portal = sc.add("portal", &cubeMesh_, Vec3(kPortX, 2.0f, kPortZ), Vec3(0.1f, 3.6f, 3.2f), Color{0.2f, 0.9f, 0.95f});
        portal->unlit = true;

        // trees
        const int count = level == 2 ? 45 : 30;
        for (int i = 0; i < count; i++) {
            float x, z;
            if (!pickSpot(x, z, -1, false)) break;
            addTree(sc, x, z);
        }

        // companions
        const Color cols[CompanionBrain::COUNT] = {{0.25f, 0.45f, 0.95f}, {0.9f, 0.3f, 0.25f}, {0.6f, 0.25f, 0.8f}, {0.25f, 0.75f, 0.4f}};
        for (int i = 0; i < CompanionBrain::COUNT; i++) {
            Mate m;
            float a = 0.8f + i * 1.3f;
            Vec3 start = g.playerStart + Vec3(std::cos(a) * 3.f, 0.f, std::sin(a) * 3.f);
            m.body = sc.add("mate", &cubeMesh_, Vec3(start.x, 0.5f, start.z), Vec3(0.55f, 1.0f, 0.55f), cols[i]);
            m.body->dynamic = true; m.body->roughness = 0.8f;
            m.head = sc.add("matehead", &sphereMesh_, Vec3(start.x, 1.25f, start.z), Vec3(0.42f, 0.42f, 0.42f), Color{0.93f, 0.75f, 0.6f});
            m.stamina = 100.f;
            mates_.push_back(m);
        }

        // the axe in the player's hands (moved every frame to stay in front of the camera)
        held_ = sc.add("held_axe", nullptr, Vec3(0, 0, 0), Vec3(1, 1, 1), Color{1, 1, 1});
        held_->model = axeId_; held_->useMatrix = true;
    }
    void afterLevelBuilt(Game& g) {   // the player is a tall box in this game
        Entity* p = g.player;
        p->scale = Vec3(0.7f, 1.7f, 0.7f);
        p->half = p->scale * 0.5f;
        p->pos = g.playerStart;
    }

    // ---------------------------------------------------------------- every frame
    void update(float dt, double now) {
        if (!game_ || !ui_ || !game_->player) return;
        Game& g = *game_;
        time_ = now;
        handleTaps();
        const bool menu = panel_ != P_NONE;
        ui_->capture = menu;
        if (menu) { g.padMove = g.padTurn = 0; }

        // find something to use (shop / port)
        Vec3 pp = g.player->pos;
        nearby_ = 0;
        if (hdist(pp.x, pp.z, kStallX, kStallZ) < 4.6f) nearby_ = 1;
        else if (hdist(pp.x, pp.z, kPortX, kPortZ) < 4.4f) nearby_ = 2;
        ui_->useVisible = nearby_ != 0 && !menu;
        ui_->useLabel = nearby_ == 1 ? "SHOP" : "PORT";

        if (!menu) {
            if (g.input.pressed('c')) openPanel(P_CHAT);
            else if (g.input.pressed('e') && nearby_ != 0) openPanel(nearby_ == 1 ? P_SHOP : P_PORT);
            else if (g.input.pressed('f')) startSwing();
        }

        // stamina
        idle_ += dt;
        if (swingT_ < 0 && idle_ > 0.6f) stamina = std::min(maxStamina(), stamina + 10.f * dt);
        stamina = std::min(stamina, maxStamina());
        if (tiredT_ > 0) tiredT_ -= dt;
        if (toastT_ > 0) toastT_ -= dt;

        // axe swing
        if (swingT_ >= 0) {
            swingT_ += dt;
            if (!swingHit_ && swingT_ >= 0.24f) { swingHit_ = true; playerHit(); }
            if (swingT_ >= 0.45f) swingT_ = -1.f;
        }
        updateTrees(dt);
        updateMates(dt);
        updateHeld(g);
        saveT_ += dt;
        if (saveT_ > 20.f) { saveT_ = 0; save(); }
        layoutPanel();
    }

    // ---------------------------------------------------------------- drawing (menus and HUD)
    void drawUI(GpuCanvas& cv) {
        if (!game_ || !ui_) return;
        const float W = (float)ui_->w, H = (float)ui_->h;
        const Color white{1, 1, 1}, gold{1.f, 0.85f, 0.4f}, ice{0.8f, 0.9f, 1.f};
        UiText::draw(cv, "WOOD " + std::to_string(wood), 6, 4, 2, gold);
        UiText::draw(cv, "COINS " + std::to_string(coins), 6, 16, 2, Color{1.f, 0.95f, 0.6f});
        UiText::draw(cv, level == 1 ? "LEVEL 1 MEADOW" : "LEVEL 2 AUTUMN WOODS", 6, 29, 1, ice);
        UiText::draw(cv, "AXE LV " + std::to_string(axeLevel) + "  TREES " + std::to_string(chopped), 6, 37, 1, ice);
        float bw = 90, bx = W * 0.5f - bw / 2, fr = clampf(stamina / maxStamina(), 0.f, 1.f);
        cv.rect(bx - 1, 3, bw + 2, 8, Color{0, 0, 0}, 0.5f);
        cv.rect(bx, 4, bw * fr, 6, fr > 0.25f ? Color{0.4f, 0.9f, 0.4f} : Color{0.95f, 0.4f, 0.3f}, 0.9f);
        UiText::draw(cv, "STAMINA", W * 0.5f, 12, 1, white, 1, 0.7f);
        if (tiredT_ > 0) UiText::draw(cv, "TIRED!", W * 0.5f, H * 0.33f, 2, Color{1.f, 0.5f, 0.4f}, 1);
        if (toastT_ > 0) UiText::draw(cv, toast_, W * 0.5f, H * 0.42f - (1.5f - toastT_) * 8.f, 2, gold, 1, clampf(toastT_, 0.f, 1.f));
        UiText::draw(cv, std::to_string((int)(fps + 0.5f)), 6, H - 9, 1, Color{0.7f, 0.7f, 0.7f});
        if (panel_ == P_NONE) cv.rect(W * 0.5f - 1, H * 0.5f - 1, 2, 2, white, 0.8f);   // crosshair

        // companion name tags
        if (panel_ == P_NONE && gpu_ && gpu_->screenWidth() > 0)
            for (int i = 0; i < (int)mates_.size(); i++) {
                Vec3 hp = mates_[i].head->pos + Vec3(0, 0.55f, 0);
                if (hdist(hp.x, hp.z, game_->cam.pos.x, game_->cam.pos.z) > 30.f) continue;
                float sx, sy;
                if (!gpu_->project(hp, sx, sy)) continue;
                UiText::draw(cv, CompanionBrain::name(i), sx * W / gpu_->screenWidth(), sy * H / gpu_->screenHeight() - 4, 1, white, 1);
            }
        if (panel_ != P_NONE) drawPanel(cv);
    }

    // ---------------------------------------------------------------- test helpers (read-only views)
    int treeTotal() const { return (int)trees_.size(); }
    int treesStanding() const { int n = 0; for (auto& t : trees_) if (t.state == 0) n++; return n; }
    Vec3 treePos(int i) const { return Vec3(trees_[i].x, 0, trees_[i].z); }
    int treeState(int i) const { return trees_[i].state; }
    float treeHp(int i) const { return trees_[i].hp; }
    float treeHeight(int i) const { return trees_[i].h; }
    int mateCount() const { return (int)mates_.size(); }
    Vec3 matePos(int i) const { return mates_[i].body->pos; }
    float mateStamina(int i) const { return mates_[i].stamina; }
    int mateMode(int i) const { return mates_[i].mode; }
    Panel panel() const { return panel_; }
    const std::vector<PBtn>& panelButtons() const { return pbtns_; }
    const std::vector<std::string>& chatLog() const { return chatLog_; }
    void openPanelForTest(Panel p) { openPanel(p); }

private:
    struct TreeInfo { Entity* vis = nullptr; Entity* col = nullptr; float x = 0, z = 0, h = 9, hp = 100, shake = 0, fall = 0, yaw = 0, respawn = 0; int state = 0; };   // state: 0 standing, 1 falling, 2 gone
    struct Mate { Entity* body = nullptr; Entity* head = nullptr; float stamina = 100, hitT = 0, restT = 0, stuck = 0, side = 0; bool wantChop = true; int mode = 0; Vec3 last{}; };   // mode: 0 follow, 1 chop, 2 rest

    static constexpr float kStallX = 6.f, kStallZ = 3.f, kPortX = -9.f, kPortZ = 3.f;
    Game* game_ = nullptr; TouchUI* ui_ = nullptr; GpuRenderer* gpu_ = nullptr;
    ModelData axe_, stall_, pine_;
    int axeId_ = -1, stallId_ = -1, pineId_ = -1, groundTex_ = -1;
    Mesh cubeMesh_ = Shapes::cube(), sphereMesh_ = Shapes::sphere(10), groundMesh_ = Shapes::ground(16, 16.f, Vec3(1, 1, 1), Vec3(1, 1, 1));
    std::vector<TreeInfo> trees_;
    std::vector<Mate> mates_;
    Entity* held_ = nullptr;
    uint32_t rng_ = 1;
    double time_ = 0;
    float swingT_ = -1.f, idle_ = 0, tiredT_ = 0, toastT_ = 0, saveT_ = 0;
    bool swingHit_ = false;
    int nearby_ = 0, chatWho_ = 0;
    std::string toast_;
    Panel panel_ = P_NONE;
    std::vector<PBtn> pbtns_;
    std::vector<std::string> chatLog_;

    static float hdist(float ax, float az, float bx, float bz) { return std::sqrt((ax - bx) * (ax - bx) + (az - bz) * (az - bz)); }
    float rand01() { rng_ = rng_ * 1664525u + 1013904223u; return (float)((rng_ >> 8) & 0xFFFFFF) / 16777216.f; }
    void say(const std::string& s) { toast_ = s; toastT_ = 1.5f; }

    // ---- trees ----
    bool pickSpot(float& x, float& z, int ignore, bool avoidPlayer) {
        for (int tries = 0; tries < 500; tries++) {
            float px = (rand01() * 2 - 1) * kWorldHalf, pz = (rand01() * 2 - 1) * kWorldHalf;
            if (hdist(px, pz, 0, 12) < 14.f || hdist(px, pz, kStallX, kStallZ) < 8.f || hdist(px, pz, kPortX, kPortZ) < 8.f) continue;
            if (avoidPlayer && game_ && game_->player && hdist(px, pz, game_->player->pos.x, game_->player->pos.z) < 12.f) continue;
            bool ok = true;
            for (int j = 0; j < (int)trees_.size(); j++) {
                if (j == ignore || trees_[j].state == 2) continue;
                if (hdist(px, pz, trees_[j].x, trees_[j].z) < 6.5f) { ok = false; break; }
            }
            if (ok) { x = px; z = pz; return true; }
        }
        return false;
    }
    void addTree(Scene& sc, float x, float z) {
        TreeInfo t;
        t.x = x; t.z = z; t.h = 7.5f + rand01() * 3.5f;
        float s = t.h / 9.f;
        t.vis = sc.add("tree", nullptr, Vec3(x, 0, z), Vec3(s, s, s), Color{1, 1, 1});
        t.vis->model = pineId_; t.vis->rot.y = rand01() * 6.28f; t.vis->roughness = 0.9f;
        t.col = sc.add("treecol", &cubeMesh_, Vec3(x, t.h / 2, z), Vec3(0.9f, t.h, 0.9f), Color{1, 1, 1});
        t.col->solid = true; t.col->visible = false;
        trees_.push_back(t);
    }
    void hitTree(int i, float dmg, const Vec3& from, int mate) {
        TreeInfo& t = trees_[i];
        if (t.state != 0) return;
        t.hp -= dmg; t.shake = 0.35f;
        if (t.hp > 0) return;
        t.state = 1; t.fall = 0;
        t.yaw = std::atan2(t.x - from.x, t.z - from.z);   // falls away from whoever chopped it
        t.col->solid = false;
        int gain = 4 + (int)(rand01() * 4);
        wood += gain; chopped++;
        if (mate >= 0) brain.mem[mate].chopped++;
        say("+" + std::to_string(gain) + " WOOD");
    }
    int nearestTree(const Vec3& p, float maxDist) const {
        int best = -1; float bd = maxDist;
        for (int i = 0; i < (int)trees_.size(); i++) {
            if (trees_[i].state != 0) continue;
            float d = hdist(p.x, p.z, trees_[i].x, trees_[i].z);
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }
    void updateTrees(float dt) {
        for (int i = 0; i < (int)trees_.size(); i++) {
            TreeInfo& t = trees_[i];
            if (t.state == 0) {
                if (t.shake > 0) { t.shake -= dt * 1.4f; t.vis->rot.z = std::sin((float)time_ * 45.f) * 0.05f * std::max(0.f, t.shake); }
                else t.vis->rot.z = 0;
            } else if (t.state == 1) {
                t.fall += dt;
                float k = t.fall / 1.5f;
                t.vis->rot.y = t.yaw; t.vis->rot.z = 0;
                t.vis->rot.x = std::min(1.5f, k * k * 1.55f);
                if (t.fall >= 1.8f) { t.state = 2; t.vis->visible = false; t.respawn = 35.f; }
            } else {
                t.respawn -= dt;
                if (t.respawn <= 0) {
                    float x, z;
                    if (pickSpot(x, z, i, true)) {
                        float s = t.h / 9.f;
                        t.x = x; t.z = z; t.hp = 100; t.state = 0; t.shake = 0;
                        t.vis->pos = Vec3(x, 0, z); t.vis->rot = Vec3(0, rand01() * 6.28f, 0); t.vis->scale = Vec3(s, s, s); t.vis->visible = true;
                        t.col->pos = Vec3(x, t.h / 2, z); t.col->solid = true;
                    } else t.respawn = 5.f;
                }
            }
        }
    }

    // ---- the player's axe ----
    void startSwing() {
        if (swingT_ >= 0) return;
        if (stamina < kSwingCost) { tiredT_ = 1.2f; return; }
        stamina -= kSwingCost; swingT_ = 0; swingHit_ = false; idle_ = 0;
    }
    static constexpr float kSwingCost = 6.f;
    void playerHit() {
        Game& g = *game_;
        Vec3 p = g.player->pos;
        float fx = std::sin(g.yaw), fz = -std::cos(g.yaw);
        int best = -1; float bd = 1e9f;
        for (int i = 0; i < (int)trees_.size(); i++) {
            if (trees_[i].state != 0) continue;
            float dx = trees_[i].x - p.x, dz = trees_[i].z - p.z, d = std::sqrt(dx * dx + dz * dz);
            if (d > 3.1f || d < 0.01f) continue;
            if ((dx * fx + dz * fz) / d < 0.72f) continue;   // must be in front of you
            if (d < bd) { bd = d; best = i; }
        }
        if (best >= 0) hitTree(best, axeDamage(), p, -1);
    }
    float swingAngle() const {   // radians about the camera's right axis; negative = head swings forward and down
        if (swingT_ < 0) return 0.f;
        auto sm = [](float x) { x = clampf(x, 0.f, 1.f); return x * x * (3.f - 2.f * x); };
        float t = swingT_;
        if (t < 0.12f) return lerpf(0.f, 0.6f, sm(t / 0.12f));
        if (t < 0.26f) return lerpf(0.6f, -1.35f, sm((t - 0.12f) / 0.14f));
        return lerpf(-1.35f, 0.f, sm((t - 0.26f) / 0.19f));
    }
    void updateHeld(Game& g) {
        if (!held_) return;
        held_->visible = g.firstPerson && axeId_ >= 0;
        const Vec3 f = g.cam.forward(), r = normalize(cross(f, Vec3(0, 1, 0))), u = cross(r, f);
        auto rot = [](const Vec3& v, const Vec3& k, float a) { float c = std::cos(a), s = std::sin(a); return v * c + cross(k, v) * s + k * (dot(k, v) * (1.f - c)); };
        const float sw = swingAngle(), pitch = -0.20f + sw, roll = -0.35f;
        // the axe's own directions (handle = x, face = y, blade side = z) as seen from the camera
        Vec3 ax = -u, ay = -r, az = f;
        ax = rot(rot(ax, r, pitch), f, roll); ay = rot(rot(ay, r, pitch), f, roll); az = rot(rot(az, r, pitch), f, roll);
        const Vec3 shoulder = g.cam.pos + r * 0.36f - u * 0.66f - f * 0.10f;
        const Vec3 hand0 = g.cam.pos + r * 0.40f - u * 0.40f + f * 0.74f;
        const Vec3 hand = shoulder + rot(hand0 - shoulder, r, sw);
        const float s = 0.32f;
        const Vec3 grip(0.5f, 0.f, -0.2f);   // where the hand holds the handle (axe model units)
        const Vec3 off = hand - (ax * (s * grip.x) + ay * (s * grip.y) + az * (s * grip.z));
        Mat4 m;
        m.m[0][0] = ax.x * s; m.m[1][0] = ax.y * s; m.m[2][0] = ax.z * s;
        m.m[0][1] = ay.x * s; m.m[1][1] = ay.y * s; m.m[2][1] = ay.z * s;
        m.m[0][2] = az.x * s; m.m[1][2] = az.y * s; m.m[2][2] = az.z * s;
        m.m[0][3] = off.x; m.m[1][3] = off.y; m.m[2][3] = off.z;
        held_->customMatrix = m;
    }

    // ---- companions ----
    void updateMates(float dt) {
        Game& g = *game_;
        const Vec3 pp = g.player->pos;
        for (int i = 0; i < (int)mates_.size(); i++) {
            Mate& m = mates_[i];
            const Vec3 p = m.body->pos;
            float a = i * 1.57f + 0.6f;
            Vec3 goal = Vec3(pp.x + std::cos(a) * 3.4f, 0, pp.z + std::sin(a) * 3.4f);
            float stopDist = 1.2f;
            int tgt = -1;
            if (m.mode == 2) {
                m.stamina = std::min(100.f, m.stamina + 8.f * dt);
                m.restT -= dt;
                if (m.restT <= 0 && m.stamina > 60.f) m.mode = 0;
            } else {
                m.mode = 0;
                if (m.stamina <= 6.f) { m.mode = 2; m.restT = 8.f; }
                else if (m.wantChop) {
                    tgt = nearestTree(Vec3(pp.x, 0, pp.z), 45.f);
                    if (tgt >= 0) { goal = Vec3(trees_[tgt].x, 0, trees_[tgt].z); stopDist = 2.2f; m.mode = 1; }
                }
            }
            Vec3 d = goal - Vec3(p.x, 0, p.z);
            float dist = length(d), speed = 0.f;
            Vec3 dir(0, 0, 0);
            if (m.mode != 2 && dist > stopDist + 0.3f) {
                speed = m.mode == 1 ? 4.2f : (dist > 9.f ? 7.f : 4.4f);
                dir = d * (1.f / dist);
                m.body->rot.y = std::atan2(-dir.x, -dir.z);
            }
            // sidestep when stuck behind something
            if (speed > 0 && length(Vec3(p.x - m.last.x, 0, p.z - m.last.z)) < 0.25f * dt) m.stuck += dt; else m.stuck = 0;
            if (m.stuck > 0.9f) { m.stuck = 0; m.side = 0.7f; m.body->vel.y = 7.f; }
            if (m.side > 0) { m.side -= dt; Vec3 sd(-dir.z, 0, dir.x); dir = normalize(dir + sd * 1.2f); }
            m.body->vel.x = dir.x * speed; m.body->vel.z = dir.z * speed;
            m.last = p;
            if (dist > 55.f) { m.body->pos = Vec3(pp.x + 2.f, 1.f, pp.z + 2.f); }   // got lost: come back

            if (m.mode == 1) {
                m.stamina -= (dist <= stopDist + 0.6f ? 0.55f : 0.1f) * dt;   // companions tire very slowly
                if (dist <= stopDist + 0.6f) {
                    m.hitT += dt;
                    if (m.hitT >= 1.6f) { m.hitT = 0; hitTree(tgt, 6.f + 1.5f * (axeLevel - 1), p, i); }
                }
            } else m.hitT = 0;
            m.head->pos = m.body->pos + Vec3(0, 0.78f + (speed > 0 ? 0.04f * std::sin((float)time_ * 9.f + i) : 0.f), 0);
        }
    }

    // ---- menus ----
    void openPanel(Panel p) { panel_ = p; ui_->releaseAll(); layoutPanel(); }
    void layoutPanel() {
        pbtns_.clear();
        if (panel_ == P_NONE || !ui_) return;
        const float W = (float)ui_->w, H = (float)ui_->h;
        const float px = W * 0.5f - 130, py = 6, pw = 260, ph = H - 12;
        auto add = [&](float x, float y, float w, float h, const std::string& l, int id, bool on = false) { pbtns_.push_back({x, y, w, h, l, id, on}); };
        if (panel_ == P_SHOP) {
            add(px + 10, py + 40, pw - 20, 24, "SELL ALL WOOD +" + std::to_string(wood * kWoodPrice), 1);
            add(px + 10, py + 70, pw - 20, 24, "AXE LV " + std::to_string(axeLevel) + ">" + std::to_string(axeLevel + 1) + " COST " + std::to_string(axeCost()), 2);
            add(px + 10, py + 100, pw - 20, 24, "STAMINA LV " + std::to_string(staminaLevel) + ">" + std::to_string(staminaLevel + 1) + " COST " + std::to_string(staminaCost()), 3);
            add(px + 10, py + ph - 28, pw - 20, 22, "CLOSE", 99);
        } else if (panel_ == P_PORT) {
            add(px + 10, py + 40, pw - 20, 26, "LEVEL 1 MEADOW", 11, level == 1);
            add(px + 10, py + 72, pw - 20, 26, "LEVEL 2 AUTUMN WOODS", 12, level == 2);
            add(px + 10, py + ph - 28, pw - 20, 22, "CLOSE", 99);
        } else {
            const float bw = (pw - 20 - 9) / 4;
            for (int i = 0; i < CompanionBrain::COUNT; i++) add(px + 10 + i * (bw + 3), py + 20, bw, 16, CompanionBrain::name(i), 20 + i, i == chatWho_);
            const float cw = (pw - 20 - 4) / 2;
            for (int i = 0; i < CompanionBrain::INTENTS; i++) add(px + 10 + (i % 2) * (cw + 4), py + 86 + (i / 2) * 18, cw, 16, CompanionBrain::phrase(i), 30 + i);
            add(px + 10, py + ph - 18, pw - 20, 16, "CLOSE", 99);
        }
    }
    void handleTaps() {
        if (!ui_) return;
        auto taps = ui_->taps;
        ui_->taps.clear();
        for (auto& t : taps) {
            if (panel_ == P_NONE) break;
            layoutPanel();
            for (const PBtn& b : pbtns_)
                if (t.first >= b.x && t.first <= b.x + b.w && t.second >= b.y && t.second <= b.y + b.h) { onPanelButton(b.id); break; }
        }
    }
    static std::vector<std::string> wrap(const std::string& s, size_t maxChars) {
        std::vector<std::string> out;
        std::istringstream ss(s);
        std::string word, line;
        while (ss >> word) {
            if (!line.empty() && line.size() + 1 + word.size() > maxChars) { out.push_back(line); line.clear(); }
            line += (line.empty() ? "" : " ") + word;
        }
        if (!line.empty()) out.push_back(line);
        return out;
    }
    void onPanelButton(int id) {
        if (id == 99) { panel_ = P_NONE; save(); return; }
        if (id == 1) { coins += wood * kWoodPrice; if (wood > 0) say("SOLD!"); wood = 0; save(); }
        else if (id == 2) { if (coins >= axeCost()) { coins -= axeCost(); axeLevel++; say("AXE UPGRADED"); save(); } else say("NOT ENOUGH COINS"); }
        else if (id == 3) { if (coins >= staminaCost()) { coins -= staminaCost(); staminaLevel++; stamina = maxStamina(); say("MORE STAMINA"); save(); } else say("NOT ENOUGH COINS"); }
        else if (id == 11 || id == 12) {
            int to = id - 10;
            panel_ = P_NONE;
            if (to != level) { level = to; save(); game_->buildLevel(); say(level == 1 ? "LEVEL 1" : "LEVEL 2"); }
        } else if (id >= 20 && id < 24) chatWho_ = id - 20;
        else if (id >= 30 && id < 30 + CompanionBrain::INTENTS) {
            int who = chatWho_, intent = id - 30;
            CompanionBrain::Facts f;
            f.staminaPct = (int)mates_[who].stamina; f.wood = wood; f.coins = coins; f.level = level;
            std::string reply = brain.talk(who, intent, f);
            if (intent == CompanionBrain::CHOP) mates_[who].wantChop = true;
            if (intent == CompanionBrain::FOLLOW) mates_[who].wantChop = false;
            if (intent == CompanionBrain::REST) { mates_[who].mode = 2; mates_[who].restT = 10.f; }
            chatLog_.push_back("YOU: " + std::string(CompanionBrain::phrase(intent)));
            auto lines = wrap(std::string(CompanionBrain::name(who)) + ": " + reply, 58);
            for (auto& l : lines) chatLog_.push_back(l);
            while (chatLog_.size() > 40) chatLog_.erase(chatLog_.begin());
            save();
        }
        layoutPanel();
    }
    void drawPanel(GpuCanvas& cv) {
        const float W = (float)ui_->w, H = (float)ui_->h;
        const float px = W * 0.5f - 130, py = 6, pw = 260, ph = H - 12;
        const Color white{1, 1, 1}, gold{1.f, 0.85f, 0.4f};
        cv.rect(px, py, pw, ph, Color{0.04f, 0.06f, 0.09f}, 0.88f);
        std::string title = panel_ == P_SHOP ? "FOOD STALL SHOP" : (panel_ == P_PORT ? "TRAVEL PORT" : "CHAT WITH COMPANIONS");
        UiText::draw(cv, title, px + pw / 2, py + 5, 2, gold, 1);
        if (panel_ == P_SHOP) UiText::draw(cv, "WOOD " + std::to_string(wood) + "  COINS " + std::to_string(coins), px + pw / 2, py + 26, 1, white, 1);
        if (panel_ == P_PORT) UiText::draw(cv, "CHOOSE WHERE TO GO", px + pw / 2, py + 26, 1, white, 1);
        if (panel_ == P_CHAT) {
            const int shown = 6;
            int start = std::max(0, (int)chatLog_.size() - shown);
            for (int i = start; i < (int)chatLog_.size(); i++) UiText::draw(cv, chatLog_[i], px + 10, py + 42 + (i - start) * 7, 1, Color{0.85f, 0.95f, 0.85f});
            if (chatLog_.empty()) UiText::draw(cv, "PICK A NAME, THEN TAP A MESSAGE", px + 10, py + 42, 1, Color{0.7f, 0.7f, 0.7f});
        }
        for (const PBtn& b : pbtns_) {
            Color c = b.id == 99 ? Color{0.55f, 0.2f, 0.2f} : (b.on ? Color{0.85f, 0.6f, 0.15f} : Color{0.2f, 0.35f, 0.6f});
            cv.rect(b.x, b.y, b.w, b.h, c, 0.95f);
            int sc = (b.h >= 22 && UiText::width(b.label, 2) <= b.w - 6) ? 2 : 1;
            UiText::draw(cv, b.label, b.x + b.w / 2, b.y + b.h / 2 - 2.5f * sc, sc, white, 1);
        }
    }
};
