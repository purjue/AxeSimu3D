// ============================================================================
//  TermEngine  -  a small 3D game engine in ONE file (C++17, no libraries)
//
//  It draws real 3D (triangles, depth buffer, lighting, camera, physics)
//  straight into the Termux terminal, using colored "half block" characters.
//
//  BUILD :  clang++ -O2 -std=c++17 engine.cpp -o engine
//  RUN   :  ./engine                  (play the demo)
//           ./engine --obj model.obj  (also show your own .obj model)
//           ./engine --test 200       (headless self-test, prints a picture)
//
//  CONTROLS
//     w / s ......... move forward / back        a / d ........ turn left / right
//     arrow keys .... turn and look up/down      space ........ jump
//     v camera mode   m wireframe   b collider boxes   r restart   p pause   q quit
//     t hide/show the touch buttons
//
//  TOUCH (phone): buttons are drawn under the picture. Tap TURN LEFT / TURN RIGHT /
//     FORWARD / BACK (hold or tap), JUMP, AUTO RUN (walks by itself, tap again to stop),
//     VIEW, WIRE, PAUSE, RESET. QUIT needs two taps. Swiping the screen looks up/down.
//
//  FILE MAP (read top to bottom, each part builds on the one before it)
//     PART 1  Settings
//     PART 2  Math          Vec3, Vec4, Mat4
//     PART 3  Meshes        cube, sphere, pyramid, cylinder, ground, .obj loader
//     PART 4  FrameBuffer   pixels, depth buffer, filling triangles
//     PART 5  Renderer      camera, lighting, clipping, lines
//     PART 6  Terminal      drawing to the screen + reading the keyboard
//     PART 7  Scene         entities, physics, triggers
//     PART 8  The game      level, player, main loop
// ============================================================================
#include <algorithm>
#include <chrono>
#include <cmath>
#include <csignal>
#include <ctime>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <memory>
#include <sstream>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>

// ============================== PART 1: SETTINGS ============================
namespace Config {
constexpr float FOV_DEG    = 70.f;        // field of view in degrees
constexpr float NEAR_PLANE = 0.1f;        // closer than this is not drawn
constexpr float FAR_PLANE  = 60.f;        // farther than this fades into fog
constexpr float FIXED_DT   = 1.f / 60.f;  // physics step: 60 times per second
constexpr int   TARGET_FPS = 30;          // how many pictures per second to draw
constexpr float GRAVITY    = -18.f;       // units per second, per second
constexpr float KEY_HOLD   = 0.25f;       // a key counts as "held" this long after its last event
}  // namespace Config

// ============================== PART 2: MATH ================================
// Everything in 3D is built from a few small number types.

constexpr float PI = 3.14159265f;
inline float radians(float deg) { return deg * PI / 180.f; }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
inline float frand(float lo, float hi) { return lo + (hi - lo) * (std::rand() / (float)RAND_MAX); }

// A point or a direction in 3D. x = right, y = up, z = toward you.
struct Vec3 {
    float x = 0, y = 0, z = 0;
    Vec3() = default;
    Vec3(float X, float Y, float Z) : x(X), y(Y), z(Z) {}
    Vec3 operator+(const Vec3& o) const { return {x + o.x, y + o.y, z + o.z}; }
    Vec3 operator-(const Vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    Vec3 operator*(float s) const { return {x * s, y * s, z * s}; }
    Vec3 operator*(const Vec3& o) const { return {x * o.x, y * o.y, z * o.z}; }
    Vec3 operator-() const { return {-x, -y, -z}; }
    Vec3& operator+=(const Vec3& o) { x += o.x; y += o.y; z += o.z; return *this; }
};
inline float dot(const Vec3& a, const Vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline Vec3 cross(const Vec3& a, const Vec3& b) {
    return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}
inline float length(const Vec3& v) { return std::sqrt(dot(v, v)); }
inline Vec3 normalize(const Vec3& v) {
    float l = length(v);
    return l > 1e-8f ? v * (1.f / l) : Vec3(0, 0, 0);
}
// Read or write x, y or z by number (0, 1, 2). Handy for physics on one axis.
inline float& axis(Vec3& v, int i) { return i == 0 ? v.x : (i == 1 ? v.y : v.z); }
inline float axis(const Vec3& v, int i) { return i == 0 ? v.x : (i == 1 ? v.y : v.z); }

// A point in "clip space" (after the camera matrix). w is the perspective divider.
struct Vec4 { float x, y, z, w; };

// A 4x4 matrix. One matrix can hold move + rotate + scale + camera + perspective.
// Multiplying matrices combines their effects. Convention: result = M * point.
struct Mat4 {
    float m[4][4];  // m[row][column]
    Mat4() {
        for (auto& row : m) for (float& v : row) v = 0;
        for (int i = 0; i < 4; i++) m[i][i] = 1;  // starts as the "do nothing" matrix
    }
    Mat4 operator*(const Mat4& b) const {
        Mat4 r;
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++) {
                float s = 0;
                for (int k = 0; k < 4; k++) s += m[i][k] * b.m[k][j];
                r.m[i][j] = s;
            }
        return r;
    }
    Vec4 operator*(const Vec4& v) const {
        return {m[0][0] * v.x + m[0][1] * v.y + m[0][2] * v.z + m[0][3] * v.w,
                m[1][0] * v.x + m[1][1] * v.y + m[1][2] * v.z + m[1][3] * v.w,
                m[2][0] * v.x + m[2][1] * v.y + m[2][2] * v.z + m[2][3] * v.w,
                m[3][0] * v.x + m[3][1] * v.y + m[3][2] * v.z + m[3][3] * v.w};
    }
    Vec3 point(const Vec3& p) const { Vec4 r = *this * Vec4{p.x, p.y, p.z, 1.f}; return {r.x, r.y, r.z}; }

    static Mat4 translate(const Vec3& t) {
        Mat4 r; r.m[0][3] = t.x; r.m[1][3] = t.y; r.m[2][3] = t.z; return r;
    }
    static Mat4 scale(const Vec3& s) {
        Mat4 r; r.m[0][0] = s.x; r.m[1][1] = s.y; r.m[2][2] = s.z; return r;
    }
    static Mat4 rotateX(float a) {
        Mat4 r; float c = std::cos(a), s = std::sin(a);
        r.m[1][1] = c; r.m[1][2] = -s; r.m[2][1] = s; r.m[2][2] = c; return r;
    }
    static Mat4 rotateY(float a) {
        Mat4 r; float c = std::cos(a), s = std::sin(a);
        r.m[0][0] = c; r.m[0][2] = s; r.m[2][0] = -s; r.m[2][2] = c; return r;
    }
    static Mat4 rotateZ(float a) {
        Mat4 r; float c = std::cos(a), s = std::sin(a);
        r.m[0][0] = c; r.m[0][1] = -s; r.m[1][0] = s; r.m[1][1] = c; return r;
    }
    // Camera matrix: moves the whole world so the camera sits at the origin looking down -Z.
    static Mat4 lookAt(const Vec3& eye, const Vec3& target, const Vec3& up) {
        Vec3 f = normalize(target - eye);
        Vec3 s = normalize(cross(f, up));
        Vec3 u = cross(s, f);
        Mat4 r;
        r.m[0][0] = s.x;  r.m[0][1] = s.y;  r.m[0][2] = s.z;  r.m[0][3] = -dot(s, eye);
        r.m[1][0] = u.x;  r.m[1][1] = u.y;  r.m[1][2] = u.z;  r.m[1][3] = -dot(u, eye);
        r.m[2][0] = -f.x; r.m[2][1] = -f.y; r.m[2][2] = -f.z; r.m[2][3] = dot(f, eye);
        return r;
    }
    // Perspective matrix: far things get smaller. This is what makes it look 3D.
    static Mat4 perspective(float fovY, float aspect, float n, float f) {
        float t = 1.f / std::tan(fovY * 0.5f);
        Mat4 r;
        r.m[0][0] = t / aspect; r.m[1][1] = t;
        r.m[2][2] = (f + n) / (n - f); r.m[2][3] = 2.f * f * n / (n - f);
        r.m[3][2] = -1.f; r.m[3][3] = 0.f;
        return r;
    }
};

// ============================== PART 3: MESHES ==============================
// A mesh is a list of points (vertices) and a list of triangles joining them.

struct Triangle {
    int a, b, c;            // indexes into Mesh::verts
    Vec3 tint{1, 1, 1};     // multiplies the object's color (used for the checkerboard)
};

struct Mesh {
    std::vector<Vec3> verts;
    std::vector<Triangle> tris;
};

namespace Shapes {

// For closed, roughly round shapes: flips any triangle that faces inward,
// so we never have to get the triangle order right by hand.
inline void orientOutward(Mesh& m) {
    Vec3 c;
    for (auto& v : m.verts) c += v;
    c = c * (1.f / (float)m.verts.size());
    for (auto& t : m.tris) {
        const Vec3 &a = m.verts[t.a], &b = m.verts[t.b], &d = m.verts[t.c];
        Vec3 n = cross(b - a, d - a);
        Vec3 mid = (a + b + d) * (1.f / 3.f);
        if (dot(n, mid - c) < 0) std::swap(t.b, t.c);
    }
}

inline void addQuad(Mesh& m, int a, int b, int c, int d) {
    m.tris.push_back({a, b, c});
    m.tris.push_back({a, c, d});
}

// 1 x 1 x 1 cube centered on the origin.
inline Mesh cube() {
    Mesh m;
    for (int i = 0; i < 8; i++)  // bit 0 = x, bit 1 = y, bit 2 = z
        m.verts.push_back({(i & 1) ? 0.5f : -0.5f, (i & 2) ? 0.5f : -0.5f, (i & 4) ? 0.5f : -0.5f});
    addQuad(m, 0, 2, 6, 4); addQuad(m, 1, 3, 7, 5);  // left, right
    addQuad(m, 0, 1, 5, 4); addQuad(m, 2, 3, 7, 6);  // bottom, top
    addQuad(m, 0, 1, 3, 2); addQuad(m, 4, 5, 7, 6);  // back, front
    orientOutward(m);
    return m;
}

// Square pyramid, 1 wide and 1 tall.
inline Mesh pyramid() {
    Mesh m;
    m.verts = {{-0.5f, -0.5f, -0.5f}, {0.5f, -0.5f, -0.5f}, {0.5f, -0.5f, 0.5f}, {-0.5f, -0.5f, 0.5f}, {0, 0.5f, 0}};
    for (int i = 0; i < 4; i++) m.tris.push_back({i, (i + 1) % 4, 4});  // 4 sides
    addQuad(m, 0, 1, 2, 3);                                              // bottom
    orientOutward(m);
    return m;
}

// Sphere with diameter 1. "seg" = detail (more = rounder but slower).
inline Mesh sphere(int seg = 10) {
    Mesh m;
    int rings = seg, slices = seg * 2;
    for (int i = 0; i <= rings; i++) {
        float phi = PI * i / rings;
        for (int j = 0; j <= slices; j++) {
            float th = 2 * PI * j / slices;
            m.verts.push_back({0.5f * std::sin(phi) * std::cos(th), 0.5f * std::cos(phi), 0.5f * std::sin(phi) * std::sin(th)});
        }
    }
    int row = slices + 1;
    for (int i = 0; i < rings; i++)
        for (int j = 0; j < slices; j++) {
            int a = i * row + j, b = a + 1, c = a + row, d = c + 1;
            m.tris.push_back({a, c, b});
            m.tris.push_back({b, c, d});
        }
    orientOutward(m);
    return m;
}

// Cylinder standing up, diameter 1, height 1.
inline Mesh cylinder(int seg = 12) {
    Mesh m;
    for (int i = 0; i < seg; i++) {
        float a = 2 * PI * i / seg;
        m.verts.push_back({0.5f * std::cos(a), -0.5f, 0.5f * std::sin(a)});  // bottom ring
        m.verts.push_back({0.5f * std::cos(a), 0.5f, 0.5f * std::sin(a)});   // top ring
    }
    int bc = (int)m.verts.size();
    m.verts.push_back({0, -0.5f, 0});  // bottom center
    m.verts.push_back({0, 0.5f, 0});   // top center
    for (int i = 0; i < seg; i++) {
        int b0 = i * 2, t0 = b0 + 1, b1 = ((i + 1) % seg) * 2, t1 = b1 + 1;
        addQuad(m, b0, b1, t1, t0);
        m.tris.push_back({b0, b1, bc});
        m.tris.push_back({t0, t1, bc + 1});
    }
    orientOutward(m);
    return m;
}

// Flat checkerboard floor made of tiles x tiles squares, facing up (+Y).
inline Mesh ground(int tiles, float tileSize, Vec3 tintA, Vec3 tintB) {
    Mesh m;
    float half = tiles * tileSize * 0.5f;
    for (int z = 0; z <= tiles; z++)
        for (int x = 0; x <= tiles; x++) m.verts.push_back({x * tileSize - half, 0, z * tileSize - half});
    int row = tiles + 1;
    for (int z = 0; z < tiles; z++)
        for (int x = 0; x < tiles; x++) {
            int a = z * row + x, b = a + row, c = b + 1, d = a + 1;
            Vec3 tint = ((x + z) % 2 == 0) ? tintA : tintB;
            m.tris.push_back({a, b, c, tint});
            m.tris.push_back({a, c, d, tint});
        }
    return m;
}

// Loads a Wavefront .obj file (vertices + faces only), centers it and scales it to size 1.
inline bool loadOBJ(const std::string& path, Mesh& out) {
    std::ifstream f(path);
    if (!f) return false;
    std::string line;
    while (std::getline(f, line)) {
        std::istringstream ss(line);
        std::string tag;
        ss >> tag;
        if (tag == "v") {
            float x, y, z;
            ss >> x >> y >> z;
            out.verts.push_back({x, y, z});
        } else if (tag == "f") {
            std::vector<int> idx;
            std::string tok;
            while (ss >> tok) {
                int i = std::atoi(tok.c_str());  // reads the number before any '/'
                idx.push_back(i < 0 ? (int)out.verts.size() + i : i - 1);
            }
            for (size_t k = 2; k < idx.size(); k++) {  // split big faces into triangles
                int a = idx[0], b = idx[k - 1], c = idx[k], n = (int)out.verts.size();
                if (a >= 0 && b >= 0 && c >= 0 && a < n && b < n && c < n) out.tris.push_back({a, b, c});
            }
        }
    }
    if (out.tris.empty()) return false;
    Vec3 lo = out.verts[0], hi = out.verts[0];
    for (auto& v : out.verts) {
        lo = {std::min(lo.x, v.x), std::min(lo.y, v.y), std::min(lo.z, v.z)};
        hi = {std::max(hi.x, v.x), std::max(hi.y, v.y), std::max(hi.z, v.z)};
    }
    Vec3 mid = (lo + hi) * 0.5f, size = hi - lo;
    float big = std::max(size.x, std::max(size.y, size.z));
    if (big < 1e-6f) return false;
    for (auto& v : out.verts) v = (v - mid) * (1.f / big);
    return true;
}

// Checks that every triangle of a closed shape faces outward. Used by --test.
inline bool facesOutward(const Mesh& m) {
    Vec3 c;
    for (auto& v : m.verts) c += v;
    c = c * (1.f / (float)m.verts.size());
    for (auto& t : m.tris) {
        const Vec3 &a = m.verts[t.a], &b = m.verts[t.b], &d = m.verts[t.c];
        Vec3 n = cross(b - a, d - a);
        if (dot(n, (a + b + d) * (1.f / 3.f) - c) < -1e-6f) return false;
    }
    return true;
}

}  // namespace Shapes

// ============================== PART 4: FRAMEBUFFER =========================
// The framebuffer is the picture we draw into: one color per pixel, plus a
// "depth" per pixel so near things correctly hide far things (the z-buffer).

struct Color { float r = 0, g = 0, b = 0; };  // each channel from 0 to 1
inline Color mix(const Color& a, const Color& b, float t) {
    return {lerpf(a.r, b.r, t), lerpf(a.g, b.g, t), lerpf(a.b, b.b, t)};
}

class FrameBuffer {
public:
    int w = 0, h = 0;
    std::vector<Color> pix;
    std::vector<float> depth;

    void resize(int W, int H) {
        w = W; h = H;
        pix.assign((size_t)w * h, Color{});
        depth.assign((size_t)w * h, 1e9f);
    }
    // Fill with a sky gradient and reset the depth buffer.
    void clear(const Color& top, const Color& bottom) {
        for (int y = 0; y < h; y++) {
            Color c = mix(top, bottom, h > 1 ? (float)y / (h - 1) : 0.f);
            for (int x = 0; x < w; x++) pix[(size_t)y * w + x] = c;
        }
        std::fill(depth.begin(), depth.end(), 1e9f);
    }
    // Draw one pixel, but only if it is closer than what is already there.
    void plot(int x, int y, float z, const Color& c) {
        if (x < 0 || y < 0 || x >= w || y >= h) return;
        size_t i = (size_t)y * w + x;
        if (z < depth[i]) { depth[i] = z; pix[i] = c; }
    }
    // A straight line between two screen points (x, y, depth).
    void line(const Vec3& a, const Vec3& b, const Color& c) {
        int steps = (int)std::min(3000.f, std::max(std::fabs(b.x - a.x), std::fabs(b.y - a.y)));
        for (int i = 0; i <= steps; i++) {
            float t = steps ? (float)i / steps : 0.f;
            plot((int)lerpf(a.x, b.x, t), (int)lerpf(a.y, b.y, t), lerpf(a.z, b.z, t) - 0.002f, c);
        }
    }
    // Fill a triangle. Points are (pixel x, pixel y, depth).
    // For every pixel in its bounding box we ask: is this pixel inside the triangle?
    void triangle(const Vec3& a, const Vec3& b, const Vec3& c, const Color& col) {
        float area = edge(a, b, c);
        if (std::fabs(area) < 1e-5f) return;
        float fx = (float)(w - 1), fy = (float)(h - 1);
        int x0 = (int)clampf(std::floor(std::min(a.x, std::min(b.x, c.x))), 0, fx);
        int x1 = (int)clampf(std::ceil(std::max(a.x, std::max(b.x, c.x))), 0, fx);
        int y0 = (int)clampf(std::floor(std::min(a.y, std::min(b.y, c.y))), 0, fy);
        int y1 = (int)clampf(std::ceil(std::max(a.y, std::max(b.y, c.y))), 0, fy);
        float inv = 1.f / area;
        for (int y = y0; y <= y1; y++)
            for (int x = x0; x <= x1; x++) {
                Vec3 p(x + 0.5f, y + 0.5f, 0);
                float w0 = edge(b, c, p) * inv, w1 = edge(c, a, p) * inv, w2 = edge(a, b, p) * inv;
                if (w0 < 0 || w1 < 0 || w2 < 0) continue;  // outside the triangle
                plot(x, y, w0 * a.z + w1 * b.z + w2 * c.z, col);
            }
    }
private:
    static float edge(const Vec3& a, const Vec3& b, const Vec3& p) {
        return (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x);
    }
};

// ============================== PART 5: RENDERER ============================

struct Camera {
    Vec3 pos{0, 2, 6};
    float yaw = 0, pitch = 0;  // yaw 0 = looking toward -Z. Positive yaw turns right.
    Vec3 forward() const {
        return {std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch)};
    }
    Mat4 view() const { return Mat4::lookAt(pos, pos + forward(), Vec3(0, 1, 0)); }
};

struct Light {
    Vec3 dir = normalize(Vec3(-0.5f, -1.f, -0.35f));  // direction the light travels (like the sun)
    float ambient = 0.30f;                             // minimum brightness in shadow
};

class Renderer {
public:
    FrameBuffer fb;
    bool wireframe = false;
    bool cullBack = true;      // skip triangles that face away from the camera
    int trianglesDrawn = 0;
    Color skyTop{0.20f, 0.40f, 0.85f}, skyBottom{0.78f, 0.88f, 0.97f};

    void resize(int w, int h) { fb.resize(w, h); }

    // Call once per frame before drawing anything.
    void begin(const Camera& cam) {
        cam_ = cam;
        float aspect = fb.h > 0 ? (float)fb.w / fb.h : 1.f;
        vp_ = Mat4::perspective(radians(Config::FOV_DEG), aspect, Config::NEAR_PLANE, Config::FAR_PLANE) * cam.view();
        fb.clear(skyTop, skyBottom);
        trianglesDrawn = 0;
    }

    // Draw a mesh. "model" = where/how it sits in the world. "base" = its color.
    void drawMesh(const Mesh& mesh, const Mat4& model, const Color& base, const Light& light, bool unlit) {
        Mat4 mvp = vp_ * model;
        std::vector<Vec4> clip(mesh.verts.size());
        std::vector<Vec3> world(mesh.verts.size());
        for (size_t i = 0; i < mesh.verts.size(); i++) {
            const Vec3& v = mesh.verts[i];
            world[i] = model.point(v);
            clip[i] = mvp * Vec4{v.x, v.y, v.z, 1.f};
        }
        const float fogStart = Config::FAR_PLANE * 0.5f;
        for (const Triangle& t : mesh.tris) {
            const Vec3 &a = world[t.a], &b = world[t.b], &c = world[t.c];
            Vec3 n = normalize(cross(b - a, c - a));
            float facing = dot(n, cam_.pos - a);
            if (facing <= 0) {
                if (cullBack) continue;  // back side: not visible
                n = -n;                  // when culling is off, light the back side too
            }
            // Lighting: the more a surface faces the light, the brighter it is.
            float shade = 1.f;
            if (!unlit) shade = light.ambient + (1.f - light.ambient) * std::max(0.f, dot(n, -light.dir));
            Color col{base.r * t.tint.x * shade, base.g * t.tint.y * shade, base.b * t.tint.z * shade};
            // Fog: distant things fade into the sky color.
            float dist = length((a + b + c) * (1.f / 3.f) - cam_.pos);
            col = mix(col, skyBottom, clampf((dist - fogStart) / (Config::FAR_PLANE - fogStart), 0.f, 1.f));
            drawClipped(clip[t.a], clip[t.b], clip[t.c], col);
        }
    }

    // A 3D line (used for debug boxes).
    void drawLine(const Vec3& a, const Vec3& b, const Color& col) {
        Vec4 p = vp_ * Vec4{a.x, a.y, a.z, 1.f}, q = vp_ * Vec4{b.x, b.y, b.z, 1.f};
        float dp = p.z + p.w, dq = q.z + q.w;
        if (dp < 0 && dq < 0) return;  // both behind the camera
        if (dp < 0 || dq < 0) {        // one end behind the camera: cut the line at the near plane
            float t = dp / (dp - dq);
            Vec4 cut{p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, p.z + (q.z - p.z) * t, p.w + (q.w - p.w) * t};
            if (dp < 0) p = cut; else q = cut;
        }
        fb.line(toScreen(p), toScreen(q), col);
    }
    void drawBox(const Vec3& c, const Vec3& h, const Color& col) {
        Vec3 v[8];
        for (int i = 0; i < 8; i++) v[i] = c + Vec3((i & 1) ? h.x : -h.x, (i & 2) ? h.y : -h.y, (i & 4) ? h.z : -h.z);
        for (int i = 0; i < 8; i++)
            for (int bit = 1; bit <= 4; bit <<= 1)
                if (!(i & bit)) drawLine(v[i], v[i | bit], col);
    }

private:
    Camera cam_;
    Mat4 vp_;

    // Clip space -> pixel coordinates (x, y) plus depth.
    Vec3 toScreen(const Vec4& p) const {
        float iw = 1.f / p.w;
        return {(p.x * iw * 0.5f + 0.5f) * fb.w, (1.f - (p.y * iw * 0.5f + 0.5f)) * fb.h, p.z * iw};
    }

    // Throw away what the camera cannot see, cut off the part behind the camera, then draw.
    void drawClipped(const Vec4& a, const Vec4& b, const Vec4& c, const Color& col) {
        if (a.x > a.w && b.x > b.w && c.x > c.w) return;     // all off the right side
        if (a.x < -a.w && b.x < -b.w && c.x < -c.w) return;  // all off the left side
        if (a.y > a.w && b.y > b.w && c.y > c.w) return;     // all above
        if (a.y < -a.w && b.y < -b.w && c.y < -c.w) return;  // all below
        if (a.z > a.w && b.z > b.w && c.z > c.w) return;     // all beyond the far plane
        const Vec4 in[3] = {a, b, c};
        Vec4 poly[4];
        int n = 0;
        for (int i = 0; i < 3; i++) {  // keep the part with z >= -w (in front of the near plane)
            const Vec4 &p = in[i], &q = in[(i + 1) % 3];
            float dp = p.z + p.w, dq = q.z + q.w;
            if (dp >= 0) poly[n++] = p;
            if ((dp >= 0) != (dq >= 0)) {
                float t = dp / (dp - dq);
                poly[n++] = {p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, p.z + (q.z - p.z) * t, p.w + (q.w - p.w) * t};
            }
        }
        if (n < 3) return;
        Vec3 s[4];
        for (int i = 0; i < n; i++) s[i] = toScreen(poly[i]);
        for (int i = 1; i + 1 < n; i++) {
            trianglesDrawn++;
            if (wireframe) {
                Color edge{std::min(1.f, col.r + 0.3f), std::min(1.f, col.g + 0.3f), std::min(1.f, col.b + 0.3f)};
                fb.line(s[0], s[i], edge); fb.line(s[i], s[i + 1], edge); fb.line(s[i + 1], s[0], edge);
            } else {
                fb.triangle(s[0], s[i], s[i + 1], col);
            }
        }
    }
};

// ============================== PART 6: TERMINAL ============================
// Output: every text character shows TWO pixels, using the "upper half block"
// character: its text color is the top pixel, its background is the bottom pixel.
// Input: we put the terminal in "raw" mode so key presses arrive instantly.

enum Key { KEY_UP = 1001, KEY_DOWN, KEY_RIGHT, KEY_LEFT };

// One thing the user did: a key press, or a touch (terminals call a touch a "mouse click").
struct Event {
    bool mouse = false, press = false;
    int key = -1;                  // for key events
    int button = 0, x = 0, y = 0;  // for touches: button code and 1-based text position
};

// A touch button drawn on the text screen under the picture.
struct Btn {
    char key;                 // what it does (also its name)
    int col, row, w, h;       // position and size in text cells (0-based)
    std::string label;
    int shade;                // 0, 1 or 2: picks its color
    bool active;              // lit up while pressed or switched on
};

static volatile std::sig_atomic_t g_quit = 0;     // set to 1 when Ctrl+C is pressed
static void onSignal(int) { g_quit = 1; }

class Terminal {
public:
    int cols = 80, rows = 24;
    bool active = false;
    ~Terminal() { leave(); }

    bool enter() {
        if (!isatty(STDIN_FILENO)) return false;
        tcgetattr(STDIN_FILENO, &saved_);
        termios raw = saved_;
        raw.c_lflag &= ~(ICANON | ECHO);  // no waiting for Enter, no echo
        raw.c_cc[VMIN] = 0;               // read() returns immediately...
        raw.c_cc[VTIME] = 0;              // ...even when no key is pressed
        tcsetattr(STDIN_FILENO, TCSANOW, &raw);
        out("\x1b[?1049h\x1b[?25l\x1b[2J\x1b[?1000h\x1b[?1006h");  // second screen, hide cursor, clear, touch reporting on
        active = true;
        querySize();
        return true;
    }
    void leave() {
        if (!active) return;
        active = false;
        out("\x1b[?1006l\x1b[?1000l\x1b[0m\x1b[?25h\x1b[?1049l");  // touch reporting off, restore colors, cursor, screen
        tcsetattr(STDIN_FILENO, TCSANOW, &saved_);
    }
    // Returns true if the terminal size changed (for example the keyboard opened).
    bool querySize() {
        winsize ws{};
        if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 0 && ws.ws_row > 0) {
            bool changed = (ws.ws_col != cols || ws.ws_row != rows);
            cols = ws.ws_col; rows = ws.ws_row;
            return changed;
        }
        return false;
    }
    void invalidate() {  // force a full redraw next frame
        prevTop_.clear(); prevBot_.clear(); prevBtn_.clear();
        out("\x1b[0m\x1b[2J");
    }

    // Reads one thing the user did. Returns false when nothing is waiting.
    // Keys and touches both arrive here. A touch looks like:  ESC [ < button ; x ; y M (down) or m (up)
    bool readEvent(Event& ev) {
        ev = Event();
        unsigned char ch;
        if (read(STDIN_FILENO, &ch, 1) != 1) return false;
        if (ch != 27) {
            if (ch >= 'A' && ch <= 'Z') ch += 32;  // capital letters count as lowercase
            ev.key = ch;
            return true;
        }
        unsigned char c;
        if (read(STDIN_FILENO, &c, 1) != 1 || c != '[') return true;  // a lone ESC: ignore it
        if (read(STDIN_FILENO, &c, 1) != 1) return true;
        if (c == 'A') ev.key = KEY_UP;           // arrow keys
        else if (c == 'B') ev.key = KEY_DOWN;
        else if (c == 'C') ev.key = KEY_RIGHT;
        else if (c == 'D') ev.key = KEY_LEFT;
        else if (c == '<') {                     // touch
            int v[3] = {0, 0, 0}, n = 0;
            char tail = 0;
            while (read(STDIN_FILENO, &c, 1) == 1) {
                if (c >= '0' && c <= '9') v[n] = v[n] * 10 + (c - '0');
                else if (c == ';' && n < 2) n++;
                else { tail = (char)c; break; }
            }
            if (tail == 'M' || tail == 'm') {
                ev.mouse = true; ev.press = (tail == 'M');
                ev.button = v[0]; ev.x = v[1]; ev.y = v[2];
            }
        } else if ((c >= '0' && c <= '9') || c == ';') {  // other escape codes: skip them
            while (read(STDIN_FILENO, &c, 1) == 1 && !(c >= 0x40 && c <= 0x7E)) {}
        }
        return true;
    }

    // Send the picture to the screen. Only cells that changed are sent (much faster).
    void present(const FrameBuffer& fb, const std::string& hud, const std::vector<Btn>& btns = {}) {
        int cellRows = fb.h / 2;
        size_t cells = (size_t)fb.w * cellRows;
        if (prevTop_.size() != cells) {
            prevTop_.assign(cells, 0xFFFFFFFFu);
            prevBot_.assign(cells, 0xFFFFFFFFu);
        }
        std::string o;
        o.reserve(cells * 4);
        long fg = -1, bg = -1;
        int curRow = -1, curCol = -1;  // where the screen cursor is right now
        for (int r = 0; r < cellRows; r++)
            for (int c = 0; c < fb.w; c++) {
                size_t i = (size_t)r * fb.w + c;
                uint32_t top = pack(fb.pix[(size_t)(2 * r) * fb.w + c]);
                uint32_t bot = pack(fb.pix[(size_t)(2 * r + 1) * fb.w + c]);
                if (top == prevTop_[i] && bot == prevBot_[i]) continue;  // unchanged
                prevTop_[i] = top; prevBot_[i] = bot;
                if (curRow != r || curCol != c) {
                    o += "\x1b["; num(o, r + 1); o += ';'; num(o, c + 1); o += 'H';
                }
                if ((long)top != fg) { o += "\x1b[38;2;"; rgb(o, top); o += 'm'; fg = top; }
                if ((long)bot != bg) { o += "\x1b[48;2;"; rgb(o, bot); o += 'm'; bg = bot; }
                o += "\xE2\x96\x80";  // the "upper half block" character
                curRow = r;
                curCol = (c + 1 < fb.w) ? c + 1 : -1;
            }
        o += "\x1b["; num(o, cellRows + 1); o += ";1H\x1b[0m\x1b[2K";  // status line under the picture
        o += hud.substr(0, (size_t)std::max(0, cols - 1));
        drawButtons(o, btns);
        fwrite(o.data(), 1, o.size(), stdout);
        fflush(stdout);
    }

private:
    termios saved_{};
    std::vector<uint32_t> prevTop_, prevBot_;
    std::vector<std::string> prevBtn_;

    static void out(const char* s) { fputs(s, stdout); fflush(stdout); }

    // Draw the touch buttons (only the ones whose look changed since last frame).
    void drawButtons(std::string& o, const std::vector<Btn>& btns) {
        static const int colors[3][3] = {{40, 70, 140}, {30, 110, 100}, {75, 75, 90}};
        for (size_t i = 0; i < btns.size(); i++) {
            const Btn& b = btns[i];
            std::string sig = b.label + (b.active ? "#" : "_") + std::to_string(b.col) + "," + std::to_string(b.row) + "," + std::to_string(b.w);
            if (prevBtn_.size() <= i) prevBtn_.resize(i + 1);
            if (prevBtn_[i] == sig) continue;
            prevBtn_[i] = sig;
            int r = 240, g = 170, bl = 40;  // bright orange when active
            if (!b.active) { r = colors[b.shade][0]; g = colors[b.shade][1]; bl = colors[b.shade][2]; }
            int inner = std::max(1, b.w - 1);  // leave one column as a gap between buttons
            for (int line = 0; line < b.h; line++) {
                o += "\x1b["; num(o, b.row + line + 1); o += ';'; num(o, b.col + 1); o += 'H';
                o += "\x1b[48;2;"; num(o, r); o += ';'; num(o, g); o += ';'; num(o, bl); o += 'm';
                o += b.active ? "\x1b[38;2;0;0;0m" : "\x1b[38;2;255;255;255m";
                std::string text((size_t)inner, ' ');
                if (line == (b.h - 1) / 2) {  // label goes in the middle row
                    std::string lab = b.label.substr(0, (size_t)inner);
                    text.replace((size_t)(inner - (int)lab.size()) / 2, lab.size(), lab);
                }
                o += text;
                o += "\x1b[0m";
            }
        }
    }
    static uint32_t pack(const Color& c) {  // 0..1 floats -> one 24-bit number (slightly rounded)
        auto q = [](float v) { return (uint32_t)(clampf(v, 0.f, 1.f) * 255.f) & 0xF8u; };
        return (q(c.r) << 16) | (q(c.g) << 8) | q(c.b);
    }
    static void num(std::string& s, int v) { s += std::to_string(v); }
    static void rgb(std::string& s, uint32_t p) {
        num(s, (p >> 16) & 255); s += ';'; num(s, (p >> 8) & 255); s += ';'; num(s, p & 255);
    }
};

// Remembers which keys were pressed lately. A terminal only reports "key typed",
// never "key released", so we treat a key as held for a short time after each event.
class Input {
public:
    void beginFrame() { pressed_.clear(); }
    void feed(int key, double now) { lastSeen_[key] = now; pressed_.push_back(key); }  // key typed / button tapped
    void hold(int key, double now) { holdUntil_[key] = now + 3.0; lastSeen_[key] = now; }  // finger down on a button
    void release(int key, double now) { holdUntil_[key] = 0; lastSeen_[key] = now; }       // finger lifted
    bool down(int key, double now) const {  // is the key (or button) being held?
        auto h = holdUntil_.find(key);
        if (h != holdUntil_.end() && h->second > now) return true;
        auto it = lastSeen_.find(key);
        return it != lastSeen_.end() && now - it->second < Config::KEY_HOLD;
    }
    bool pressed(int key) const {           // was the key typed this frame?
        return std::find(pressed_.begin(), pressed_.end(), key) != pressed_.end();
    }
private:
    std::unordered_map<int, double> lastSeen_, holdUntil_;
    std::vector<int> pressed_;
};

// ============================== PART 7: SCENE ===============================
// A scene is a list of entities. An entity is "a thing in the world":
// a mesh plus position, size, color, and optional physics and behavior.

struct AABB {  // axis-aligned bounding box: the simplest collision shape
    Vec3 lo, hi;
    bool overlaps(const AABB& o) const {
        return lo.x < o.hi.x && hi.x > o.lo.x && lo.y < o.hi.y && hi.y > o.lo.y && lo.z < o.hi.z && hi.z > o.lo.z;
    }
};

struct Entity {
    std::string name;
    const Mesh* mesh = nullptr;
    Vec3 pos{0, 0, 0}, rot{0, 0, 0}, scale{1, 1, 1};  // rot = angles in radians
    Color color{1, 1, 1};
    bool visible = true, unlit = false, alive = true;

    // Physics settings
    bool solid = false;      // other things cannot pass through it
    bool dynamic = false;    // gravity and collisions move it
    bool trigger = false;    // does not block, but calls onTouch when the player overlaps it
    bool onGround = false;
    Vec3 vel{0, 0, 0};       // speed in units per second
    Vec3 half{0.5f, 0.5f, 0.5f};  // half the size of its collision box
    float bounce = 0.f;      // 0 = no bounce, 0.8 = bouncy

    float age = 0;           // seconds since it was created
    float life = -1;         // if >= 0 the entity removes itself after this many seconds

    // Look (used by the GPU renderer in the Android app; the terminal renderer ignores these)
    float metallic = 0.f, roughness = 0.7f;  // PBR material: 0..1 each (1 = metal / rough)
    Vec3 emissive{0, 0, 0};                  // light the object gives off by itself
    int pattern = 0;                         // procedural surface: 0 plain, 1 grass, 2 bricks, 3 wood
    int model = -1;                          // number of a loaded .glb model to draw instead of a basic shape
    int tex = -1;                            // number of a loaded texture (used by pattern 4 = textured ground)
    bool useMatrix = false;                  // true = draw with customMatrix instead of pos / rot / scale
    Mat4 customMatrix;

    std::function<void(Entity&, float)> onUpdate;  // your own behavior, called every step
    std::function<void(Entity&)> onTouch;          // called when the player touches a trigger

    Mat4 matrix() const {  // scale first, then rotate, then move
        if (useMatrix) return customMatrix;
        return Mat4::translate(pos) * Mat4::rotateY(rot.y) * Mat4::rotateX(rot.x) * Mat4::rotateZ(rot.z) * Mat4::scale(scale);
    }
    AABB box() const { return {pos - half, pos + half}; }
};

class Scene {
public:
    std::vector<std::unique_ptr<Entity>> entities;
    Light light;
    Entity* player = nullptr;

    Entity* add(const std::string& name, const Mesh* mesh, const Vec3& pos, const Vec3& scale, const Color& color) {
        auto e = std::make_unique<Entity>();
        e->name = name; e->mesh = mesh; e->pos = pos; e->scale = scale; e->color = color;
        e->half = scale * 0.5f;  // all our basic shapes are 1 unit big
        entities.push_back(std::move(e));
        return entities.back().get();
    }
    Entity* find(const std::string& name) {
        for (auto& e : entities) if (e->name == name) return e.get();
        return nullptr;
    }
    void clear() { entities.clear(); player = nullptr; }

    // One physics/game step. dt = seconds (always 1/60).
    void update(float dt) {
        for (size_t i = 0; i < entities.size(); i++) {  // index loop: callbacks may add entities
            Entity& e = *entities[i];
            if (!e.alive) continue;
            e.age += dt;
            if (e.onUpdate) e.onUpdate(e, dt);
            if (e.dynamic) physics(e, dt);
            if (e.life >= 0) { e.life -= dt; if (e.life <= 0) e.alive = false; }
        }
        if (player)
            for (size_t i = 0; i < entities.size(); i++) {
                Entity& e = *entities[i];
                if (e.alive && e.trigger && e.onTouch && e.box().overlaps(player->box())) e.onTouch(e);
            }
        entities.erase(std::remove_if(entities.begin(), entities.end(),
                                      [](const std::unique_ptr<Entity>& e) { return !e->alive; }),
                       entities.end());
    }

    void render(Renderer& r, bool debugBoxes) {
        for (auto& up : entities) {
            const Entity& e = *up;
            if (!e.alive) continue;
            if (e.visible && e.mesh) r.drawMesh(*e.mesh, e.matrix(), e.color, light, e.unlit);
            if (debugBoxes && (e.solid || e.trigger || e.dynamic))
                r.drawBox(e.pos, e.half, e.trigger ? Color{1, 1, 0} : Color{0, 1, 0});
        }
    }

private:
    void physics(Entity& e, float dt) {
        e.vel.y = std::max(e.vel.y + Config::GRAVITY * dt, -40.f);  // gravity pulls down
        e.onGround = false;
        moveAxis(e, 0, e.vel.x * dt);  // move one axis at a time so we know
        moveAxis(e, 2, e.vel.z * dt);  // which wall or floor we hit
        moveAxis(e, 1, e.vel.y * dt);
    }
    // Move along one axis; if we end up inside a solid box, push back out.
    void moveAxis(Entity& e, int ax, float amount) {
        if (amount == 0) return;
        axis(e.pos, ax) += amount;
        for (auto& up : entities) {
            Entity& o = *up;
            if (&o == &e || !o.solid || !o.alive || !e.box().overlaps(o.box())) continue;
            AABB b = o.box();
            if (amount > 0) axis(e.pos, ax) = axis(b.lo, ax) - axis(e.half, ax);  // hit its near side
            else            axis(e.pos, ax) = axis(b.hi, ax) + axis(e.half, ax);  // hit its far side
            if (ax == 1 && amount < 0) e.onGround = true;                        // landed on top
            float v = axis(e.vel, ax);
            if (ax == 1 && e.bounce > 0 && std::fabs(v) > 2.f) axis(e.vel, ax) = -v * e.bounce;
            else axis(e.vel, ax) = 0;
        }
    }
};

// ============================== PART 8: THE GAME ============================

struct Game {
    // Shared meshes: many entities can use the same mesh (saves memory).
    Mesh cube = Shapes::cube(), ball = Shapes::sphere(10), pyramid = Shapes::pyramid(), cylinder = Shapes::cylinder(12);
    Mesh floorMesh = Shapes::ground(20, 2.f, Vec3(1, 1, 1), Vec3(0.78f, 0.78f, 0.78f));
    Mesh model;
    bool hasModel = false;

    Scene scene;
    Camera cam;
    Renderer renderer;
    Input input;
    Entity* player = nullptr;

    float yaw = 0, pitch = 0, fps = 0;
    bool firstPerson = true, paused = false, showBoxes = false, jumpQueued = false;
    bool autoRun = false;        // walk forward by itself (handy with touch controls)
    bool padOn = true, refit = false;
    int padRows = 0;             // text rows used by the touch buttons
    double quitArmedUntil = 0;   // QUIT needs two taps within 2 seconds
    char heldBtn = 0;            // movement button the finger is on right now
    std::vector<Btn> pad;
    std::function<void(Game&)> onLevelBuilt;  // the Android app uses this to add loaded .glb models
    std::function<void(Game&)> levelOverride; // if set, builds the level instead of the built-in demo level
    Vec3 playerStart{0, 0.5f, 10};
    float eyeHeight = 0.3f;     // how far above the player's center the camera sits
    float padMove = 0, padTurn = 0;  // analog touch joystick (-1 to 1), used by the Android app
    int coins = 0, coinsTotal = 0;
    double now = 0;  // current time in seconds

    void init(const std::string& objPath) {
        if (!objPath.empty()) {
            hasModel = Shapes::loadOBJ(objPath, model);
            if (!hasModel) fprintf(stderr, "Could not load %s (showing the demo without it)\n", objPath.c_str());
        }
        renderer.cullBack = !hasModel;  // .obj files often have mixed triangle directions
        buildLevel();
    }

    // ---- The level. Change this function to build your own world! ----
    //
    //   Add a red box that spins:
    //     Entity* e = scene.add("mybox", &cube, {0, 1, 0}, {1, 1, 1}, {1, 0, 0});
    //     e->onUpdate = [](Entity& self, float dt) { self.rot.y += dt; };
    //
    //   Make it solid so the player cannot walk through it:  e->solid = true;
    void buildLevel() {
        scene.clear();
        coins = coinsTotal = 0;
        yaw = pitch = 0;
        autoRun = false;

        if (levelOverride) {
            levelOverride(*this);
        } else {
        Entity* gnd = scene.add("ground", &floorMesh, {0, 0, 0}, {1, 1, 1}, {0.35f, 0.70f, 0.30f});
        gnd->pattern = 1; gnd->roughness = 0.95f;
        Entity* slab = scene.add("slab", &cube, {0, -0.5f, 0}, {40, 1, 40}, {1, 1, 1});  // invisible floor to stand on
        slab->solid = true; slab->visible = false;

        // Four walls around the arena.
        const Vec3 wallPos[4] = {{0, 1, -20.5f}, {0, 1, 20.5f}, {-20.5f, 1, 0}, {20.5f, 1, 0}};
        const Vec3 wallSize[4] = {{41, 2, 1}, {41, 2, 1}, {1, 2, 41}, {1, 2, 41}};
        for (int i = 0; i < 4; i++) {
            Entity* w = scene.add("wall", &cube, wallPos[i], wallSize[i], {0.55f, 0.5f, 0.45f});
            w->solid = true; w->pattern = 2; w->roughness = 0.9f;
        }

        // A staircase you can jump up (each step is 0.7 higher).
        for (int i = 0; i < 4; i++) {
            float h = 0.7f * (i + 1);
            Entity* s = scene.add("step", &cube, {7, h / 2, -4.f - 3.f * i}, {3, h, 3}, {0.75f, 0.55f, 0.35f});
            s->solid = true; s->pattern = 3; s->roughness = 0.7f;
        }

        // Pillars and a windmill.
        Entity* p1 = scene.add("pillar", &cube, {-6, 1.5f, -6}, {1.5f, 3, 1.5f}, {0.6f, 0.6f, 0.7f});
        Entity* p2 = scene.add("pillar", &cube, {3, 1, -12}, {1.5f, 2, 1.5f}, {0.6f, 0.6f, 0.7f});
        p1->solid = p2->solid = true;
        p1->pattern = p2->pattern = 2; p1->roughness = p2->roughness = 0.85f;
        Entity* tower = scene.add("tower", &cube, {-12, 2, -10}, {1.5f, 4, 1.5f}, {0.85f, 0.85f, 0.8f});
        tower->solid = true; tower->pattern = 2;
        Entity* blade = scene.add("blade", &cube, {-12, 3.5f, -9.1f}, {5, 0.35f, 0.15f}, {0.8f, 0.2f, 0.2f});
        blade->onUpdate = [](Entity& e, float dt) { e.rot.z += 1.5f * dt; };
        blade->roughness = 0.5f;

        // Spinning gems for decoration.
        const Vec3 gemSpots[3] = {{-3, 1.2f, -3}, {10, 1.2f, 6}, {-10, 1.2f, 4}};
        for (const Vec3& g : gemSpots) {
            Entity* e = scene.add("gem", &pyramid, g, {0.8f, 1.0f, 0.8f}, {0.7f, 0.3f, 0.9f});
            e->onUpdate = [g](Entity& self, float dt) { self.rot.y += 2.f * dt; self.pos.y = g.y + 0.2f * std::sin(self.age * 2.f); };
            e->metallic = 0.1f; e->roughness = 0.12f; e->emissive = Vec3(0.25f, 0.08f, 0.4f);
        }

        // A bouncy ball that falls and bounces forever.
        Entity* b = scene.add("ball", &ball, {-4, 6, -1}, {1.2f, 1.2f, 1.2f}, {0.9f, 0.2f, 0.3f});
        b->dynamic = b->solid = true;
        b->bounce = 0.85f;
        b->roughness = 0.18f;  // glossy
        b->onUpdate = [](Entity& e, float) {  // when it nearly stops, give it a kick so it never settles
            if (e.onGround && std::fabs(e.vel.y) < 2.f) e.vel.y = 11.f;
        };

        // Coins: touch them all to win.
        const Vec3 coinSpots[10] = {{-4, 0.8f, 5}, {4, 0.8f, 2}, {-9, 0.8f, -4}, {0, 0.8f, -8}, {-12, 0.8f, 8},
                                    {12, 0.8f, -12}, {-3, 0.8f, -14}, {7, 1.4f, -4}, {7, 2.8f, -10}, {7, 3.5f, -13}};
        for (const Vec3& p : coinSpots) {
            Entity* c = scene.add("coin", &cylinder, p, {0.6f, 0.1f, 0.6f}, {1.f, 0.85f, 0.1f});
            c->rot.z = PI / 2;                        // stand the disc up
            c->metallic = 1.f; c->roughness = 0.22f; c->emissive = Vec3(0.30f, 0.22f, 0.02f);
            c->half = {0.35f, 0.35f, 0.35f};
            c->trigger = true;
            c->onUpdate = [p](Entity& e, float dt) { e.rot.y += 3.f * dt; e.pos.y = p.y + 0.15f * std::sin(e.age * 3.f); };
            c->onTouch = [this](Entity& e) { e.alive = false; coins++; burst(e.pos); };
            coinsTotal++;
        }

        if (hasModel) {  // your own .obj model, floating and spinning in the middle
            Entity* m = scene.add("model", &model, {0, 1.6f, -2}, {2.2f, 2.2f, 2.2f}, {0.8f, 0.85f, 0.95f});
            m->onUpdate = [](Entity& e, float dt) { e.rot.y += dt; };
        }

        }
        // The player: an orange box. The camera follows it.
        player = scene.add("player", &cube, playerStart, {0.7f, 0.9f, 0.7f}, {1.f, 0.55f, 0.15f});
        player->dynamic = true;
        scene.player = player;
        if (onLevelBuilt) onLevelBuilt(*this);
        updateCamera();
    }

    // A little fountain of sparks (used when a coin is collected).
    void burst(const Vec3& p) {
        for (int i = 0; i < 10; i++) {
            Entity* s = scene.add("spark", &cube, p, {0.15f, 0.15f, 0.15f}, {1.f, 0.9f, 0.3f});
            s->dynamic = true; s->unlit = true;
            s->bounce = 0.5f; s->life = 0.8f;
            s->vel = {frand(-3, 3), frand(2, 6), frand(-3, 3)};
            s->onUpdate = [](Entity& e, float) {  // shrink as it ages
                float k = std::max(0.f, e.life / 0.8f);
                e.scale = Vec3(0.15f, 0.15f, 0.15f) * k;
                e.half = e.scale * 0.5f;
            };
        }
    }

    // ---- Touch controls ----
    // Builds the buttons under the picture. firstRow = first text row below the status line.
    void layoutPad(int cols, int firstRow, int rows) {
        pad.clear();
        padRows = (rows >= 6) ? rows : 0;
        if (!padRows) return;
        struct Def { char key; int shade; };
        const Def line1[3] = {{'a', 0}, {'w', 0}, {'d', 0}};
        const Def line2[3] = {{' ', 1}, {'s', 1}, {'g', 1}};
        const Def line3[5] = {{'v', 2}, {'m', 2}, {'p', 2}, {'r', 2}, {'q', 2}};
        auto addLine = [&](const Def* defs, int n, int line) {
            for (int i = 0; i < n; i++) {
                int x0 = cols * i / n, x1 = cols * (i + 1) / n;
                pad.push_back({defs[i].key, x0, firstRow + line * 2, x1 - x0, 2, "", defs[i].shade, false});
            }
        };
        addLine(line1, 3, 0); addLine(line2, 3, 1); addLine(line3, 5, 2);
        refreshPad();
    }

    // Updates button labels and which ones are lit.
    void refreshPad() {
        for (Btn& b : pad) {
            switch (b.key) {
                case 'a': b.label = "TURN LEFT"; break;
                case 'd': b.label = "TURN RIGHT"; break;
                case 'w': b.label = "FORWARD"; break;
                case 's': b.label = "BACK"; break;
                case ' ': b.label = "JUMP"; break;
                case 'g': b.label = autoRun ? "STOP" : "AUTO RUN"; break;
                case 'v': b.label = firstPerson ? "VIEW 1" : "VIEW 3"; break;
                case 'm': b.label = "WIRE"; break;
                case 'p': b.label = paused ? "PLAY" : "PAUSE"; break;
                case 'r': b.label = "RESET"; break;
                case 'q': b.label = now < quitArmedUntil ? "SURE?" : "QUIT"; break;
            }
            bool move = b.key == 'a' || b.key == 'd' || b.key == 'w' || b.key == 's';
            b.active = (move && input.down(b.key, now)) || (b.key == 'g' && autoRun) ||
                       (b.key == 'm' && renderer.wireframe) || (b.key == 'p' && paused) ||
                       (b.key == 'q' && now < quitArmedUntil);
        }
    }

    const Btn* hitButton(int x, int y) const {  // x, y = 1-based text cell that was touched
        for (const Btn& b : pad)
            if (x - 1 >= b.col && x - 1 < b.col + b.w && y - 1 >= b.row && y - 1 < b.row + b.h) return &b;
        return nullptr;
    }

    // A finger touched or left the screen.
    void handleTouch(const Event& ev) {
        if (ev.button == 64) { input.feed(KEY_UP, now); return; }    // swipe: look up
        if (ev.button == 65) { input.feed(KEY_DOWN, now); return; }  // swipe: look down
        if ((ev.button & 3) != 0 || (ev.button & 32)) return;        // only the main touch, not drags
        if (ev.press) {
            const Btn* b = hitButton(ev.x, ev.y);
            heldBtn = 0;
            if (!b) return;
            switch (b->key) {
                case 'a': case 'd': case 'w': case 's': heldBtn = b->key; input.hold(b->key, now); break;
                case 'g': autoRun = !autoRun; break;
                case 'q': if (now < quitArmedUntil) { g_quit = 1; quitArmedUntil = 0; } else quitArmedUntil = now + 2.0; break;
                default: input.feed(b->key, now);  // jump, view, wire, pause, reset
            }
        } else if (heldBtn) {
            input.release(heldBtn, now);  // finger lifted: keep going for a moment, then stop
            heldBtn = 0;
        }
    }

    // Called once per drawn frame: keys that switch things on and off.
    void handleInput() {
        if (input.pressed('v')) firstPerson = !firstPerson;
        if (input.pressed('m')) renderer.wireframe = !renderer.wireframe;
        if (input.pressed('b')) showBoxes = !showBoxes;
        if (input.pressed('p')) paused = !paused;
        if (input.pressed('r')) buildLevel();
        if (input.pressed('t')) { padOn = !padOn; refit = true; }
        jumpQueued = input.pressed(' ');
    }

    // One game step (called 60 times per second).
    void update(float dt) {
        if (paused) return;
        auto held = [&](int k) { return input.down(k, now) ? 1.f : 0.f; };
        yaw += (held('d') + held(KEY_RIGHT) > 0 ? 1.f : 0.f) * 2.2f * dt;   // turn right
        yaw -= (held('a') + held(KEY_LEFT) > 0 ? 1.f : 0.f) * 2.2f * dt;    // turn left
        yaw += padTurn * 2.2f * dt;                                         // joystick turn (Android)
        pitch = clampf(pitch + (held(KEY_UP) - held(KEY_DOWN)) * 1.2f * dt, -1.2f, 1.2f);

        float move = clampf(held('w') - held('s') + (autoRun ? 1.f : 0.f) + padMove, -1.f, 1.f);  // walk
        player->vel.x = std::sin(yaw) * move * 6.f;
        player->vel.z = -std::cos(yaw) * move * 6.f;
        if (jumpQueued && player->onGround) { player->vel.y = 7.5f; jumpQueued = false; }

        scene.update(dt);
        updateCamera();
    }

    void updateCamera() {
        Vec3 eye = player->pos + Vec3(0, eyeHeight, 0);
        cam.yaw = yaw; cam.pitch = pitch;
        if (firstPerson) {
            cam.pos = eye;
            player->visible = false;
        } else {  // third person: float behind and above the player, looking at it
            player->visible = true;
            cam.pos = eye + cam.forward() * -4.5f + Vec3(0, 1.2f, 0);
            cam.pos.y = std::max(cam.pos.y, 0.3f);
            Vec3 d = normalize(eye - cam.pos);
            cam.yaw = std::atan2(d.x, -d.z);
            cam.pitch = std::asin(clampf(d.y, -1.f, 1.f));
        }
    }

    void render() {
        if (padRows > 0) refreshPad();
        renderer.begin(cam);
        scene.render(renderer, showBoxes);
    }

    std::string hud() const {
        char buf[200];
        if (coinsTotal > 0 && coins == coinsTotal)
            snprintf(buf, sizeof buf, "YOU WIN! All %d coins!  RESET (or r) = play again", coinsTotal);
        else
            snprintf(buf, sizeof buf, "Coins %d/%d  FPS %.0f%s%s", coins, coinsTotal, fps, paused ? "  PAUSED" : "",
                     padRows > 0 ? "" : "  | wasd space v m b r p q t");
        return buf;
    }

    // ---- Self-test: runs the game with no screen and prints a picture ----
    int runHeadless(int frames) {
        printf("mesh check  cube:%d pyramid:%d sphere:%d cylinder:%d (1 = faces outward)\n",
               Shapes::facesOutward(cube), Shapes::facesOutward(pyramid), Shapes::facesOutward(ball),
               Shapes::facesOutward(cylinder));
        renderer.resize(64, 32);
        double t = 0;
        for (int i = 0; i < frames; i++) {  // pretend a player walks forward, turns and jumps
            t += Config::FIXED_DT; now = t;
            input.beginFrame();
            input.feed('w', t);
            if (i % 120 < 30) input.feed('d', t);
            if (i % 100 == 50) input.feed(' ', t);
            handleInput();
            update(Config::FIXED_DT);
        }
        firstPerson = false;  // show the player in the picture
        updateCamera();
        render();
        const char* ramp = " .:-=+*#%@";
        for (int y = 0; y < renderer.fb.h; y++) {
            for (int x = 0; x < renderer.fb.w; x++) {
                const Color& c = renderer.fb.pix[(size_t)y * renderer.fb.w + x];
                float l = clampf(0.3f * c.r + 0.59f * c.g + 0.11f * c.b, 0.f, 0.999f);
                putchar(ramp[(int)(l * 10)]);
            }
            putchar('\n');
        }
        bool ok = std::isfinite(player->pos.x) && std::isfinite(player->pos.y) && std::isfinite(player->pos.z) &&
                  renderer.trianglesDrawn > 0;
        printf("frames:%d  player:(%.2f, %.2f, %.2f)  coins:%d/%d  triangles drawn:%d  entities:%zu\n", frames,
               player->pos.x, player->pos.y, player->pos.z, coins, coinsTotal, renderer.trianglesDrawn,
               scene.entities.size());
        puts(ok ? "RESULT: OK" : "RESULT: PROBLEM");
        return ok ? 0 : 1;
    }
};

// ============================== MAIN LOOP ===================================
// Every game engine is this loop:  read input -> update the world -> draw -> repeat.
// Physics runs at a fixed 60 steps per second, no matter how fast drawing is.

int main(int argc, char** argv) {
    std::string objPath;
    int testFrames = 0;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--obj" && i + 1 < argc) objPath = argv[++i];
        else if (a == "--test") testFrames = (i + 1 < argc) ? std::atoi(argv[++i]) : 200;
        else { puts("usage: engine [--obj model.obj] [--test frames]"); return a == "--help" ? 0 : 1; }
    }
    std::srand(testFrames > 0 ? 1u : (unsigned)std::time(nullptr));

    Game game;
    game.init(objPath);
    if (testFrames > 0) return game.runHeadless(testFrames);

    Terminal term;
    if (!term.enter()) { fprintf(stderr, "Please run this inside a terminal such as Termux.\n"); return 1; }
    std::signal(SIGINT, onSignal);   // Ctrl+C ends the loop cleanly
    std::signal(SIGTERM, onSignal);

    // Fit the picture to the terminal: 1 character wide = 1 pixel, 1 character tall = 2 pixels.
    auto fitScreen = [&]() {
        int padRows = (game.padOn && term.rows >= 22) ? 6 : 0;               // room for the touch buttons?
        int cellRows = std::min(40, std::max(4, term.rows - 1 - padRows));   // text rows used by the picture
        int w = std::min(std::max(16, term.cols), 120);
        game.renderer.resize(w, cellRows * 2);
        game.layoutPad(term.cols, cellRows + 1, padRows);
        term.invalidate();
    };
    fitScreen();

    using Clock = std::chrono::steady_clock;
    auto start = Clock::now(), last = start;
    double acc = 0;
    while (!g_quit) {
        auto t0 = Clock::now();
        double dt = std::min(0.1, std::chrono::duration<double>(t0 - last).count());
        last = t0;
        game.now = std::chrono::duration<double>(t0 - start).count();

        if (term.querySize()) fitScreen();       // keyboard opened/closed? resize the picture
        game.input.beginFrame();                  // 1. input (keys and touches)
        Event ev;
        while (term.readEvent(ev)) {
            if (ev.mouse) game.handleTouch(ev);
            else if (ev.key >= 0) game.input.feed(ev.key, game.now);
        }
        if (game.input.pressed('q') || g_quit) break;
        game.handleInput();
        if (game.refit) { game.refit = false; fitScreen(); }

        acc += dt;                                // 2. update, in fixed steps
        while (acc >= Config::FIXED_DT) { game.update(Config::FIXED_DT); acc -= Config::FIXED_DT; }

        game.fps = game.fps * 0.9f + 0.1f * (float)(dt > 0 ? 1.0 / dt : 0.0);
        game.render();                            // 3. draw
        term.present(game.renderer.fb, game.hud(), game.pad);

        double spent = std::chrono::duration<double>(Clock::now() - t0).count();  // wait to hit the target FPS
        double wait = 1.0 / Config::TARGET_FPS - spent;
        if (wait > 0) std::this_thread::sleep_for(std::chrono::duration<double>(wait));
    }
    return 0;  // the Terminal destructor restores your screen
}
