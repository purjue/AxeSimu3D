AXE SIMULATOR 3D  -  an Android game written in C++ (OpenGL ES 3.0 engine, no Godot, no Java)
===============================================================================================

THE GAME
  - Chop 30 pine trees in a 256 m meadow with your axe. Trees fall; they grow back after a while.
  - Sell wood at the food stall (SHOP) and buy a better axe and more stamina.
  - Travel port: go to Level 2 (autumn woods, 45 trees).
  - Four companions: Pranjal, Pro, Devil and Array. They follow you and chop trees, and they get tired
    very slowly. Tap C to chat. They have an OFFLINE brain (no internet): it remembers your old chats,
    saved in a file inside the app. Ask "REMEMBER ME?" to test it.
  - Progress is saved automatically.

CONTROLS (landscape)
  Left side  : floating joystick (up = walk, left/right = turn)
  Right side : drag to look around (two fingers at once are fine)
  CHOP       : swing the axe at the tree in front of you (uses stamina)
  JUMP       : jump          USE (appears near the stall / gate) : open the shop / the port
  V = camera view, C = chat, R = rebuild the world, Q = graphics quality (the game also lowers it by itself if slow)

BUILD THE APP FROM YOUR PHONE (free, about 15 minutes the first time)
  You need: Termux and a free GitHub account (https://github.com/signup)
  1. In Termux (only the first time):
       termux-setup-storage
       pkg install unzip git gh -y
  2. Unzip (the zip is in your Downloads folder):
       cp ~/storage/downloads/axe-simulator-3d-cpp.zip ~/
       unzip axe-simulator-3d-cpp.zip -d axe3d
       cd axe3d
  3. git config --global user.name "yourname"
     git config --global user.email "you@example.com"
  4. gh auth login      (GitHub.com -> HTTPS -> Yes -> Login with a web browser; open github.com/login/device and type the code)
  5. git init -b main
     git add .
     git commit -m "first build"
     gh repo create axe-simulator-3d --private --source=. --push
  6. Wait 6-10 minutes at  https://github.com/YOURNAME/axe-simulator-3d/actions  (green check = done)
  7. Open  https://github.com/YOURNAME/axe-simulator-3d/releases  and tap AxeSimulator3D.apk to install.
     Allow "install unknown apps" if asked. If Play Protect warns, choose "Install anyway".

IF IT FAILS TO BUILD: open the failed run, open the red step, copy the last 20 lines and send them to Claude.

YOUR ASSETS (in app/src/main/assets)
  models/axe.glb, models/food_stall_in_edo.glb, models/pine_tree_low-poly.glb
  textures/grass_1k.jpg  (your 2k grass picture, shrunk to 1024 pixels so it loads fast on a phone)
  The app icon comes from your icon.png (app/src/main/res/mipmap-*).

CODE MAP (all C++)  app/src/main/cpp/
  axe_sim.h        the game: world, trees, axe, shop, port, companions, chat brain, menus, saving
  engine.cpp       engine core: math, scene, physics (also runs in a terminal)
  gpu_renderer.h   GPU renderer and shaders (materials, shadows, sky)
  gltf_loader.h    .glb model loader
  touch_ui.h       joystick, buttons and the text font
  android_main.cpp the Android app: window, GPU setup, touch input
