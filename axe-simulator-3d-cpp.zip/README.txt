AXE SIMULATOR 3D  -  an Android game written in C++ (OpenGL ES 3.0 engine, no Godot; one tiny Java file for the ad banner)
===============================================================================================

THE GAME
  - An island with hills, a beach, a wooden fence along the shore, and the sea beyond it. You cannot walk into the water.
  - Chop 60 pine trees. Trees fall and grow back after a while.
  - SHOP (food stall), two pages:
      SELL     : sell 1 wood, or all your wood (5 coins each).
      UPGRADES : axe (more damage + 10% chance of double wood per level, up to 90%), stamina,
                 MAX WOOD (the most wood one tree can give: 7, 9, 11 ... costs 3,000 then 12,000 then 27,000 ...),
                 WOOD MULTIPLIER (x1.5, x2.0 ... costs 5,000 then 20,000 then 45,000 ...).
  - PORT (the gate): WORLD 2 (autumn woods, 60 trees) costs 100,000 coins. Every tree there gives 10x wood.
  - Progress and settings are saved automatically.

CONTROLS (landscape)
  Joystick  : touch anywhere on the left half. It is small, but the touch area is big and dynamic (the stick follows
              your finger). It only WALKS (forward, back, sideways). It never turns the camera.
  Camera    : drag anywhere else on the screen. You can move and look at the same time.
  CHOP, JUMP, SHOP/PORT : three small buttons on the right (SHOP / PORT appears when you stand near them).
  OPTIONS   : button under the wood / coin counters (top left).

OPTIONS
  Camera view (first / third person), graphics LOW / MEDIUM / HIGH, resolution scaler (30% to 125%, 100% = full
  resolution), shadows on/off, auto lower (lowers graphics by itself if the game is slow), restart world.

TEXT: everything you read in the game uses the Kurland font (tools/Kurland.ttf, baked into the app's assets/fonts).
  To change the font: python3 tools/bake_font.py tools/YourFont.ttf app/src/main/assets/fonts

ADS (AdMob banner)
  - A 320x50 banner sits at the bottom centre of the screen. It is hidden while the SHOP / PORT / OPTIONS menus are open
    (the menu's CLOSE button is in that spot) and comes back when the menu closes. Nothing is shown until an ad has loaded.
  - App ID    : app/src/main/AndroidManifest.xml          (ca-app-pub-7435099394804874~8729888247)
    Banner ID : app/src/main/java/com/example/axesimulator3d/MainActivity.java   (ca-app-pub-7435099394804874/6059099663)
  - In MainActivity.java the line  USE_TEST_ADS  chooses the ad:
        false = your real ad (earns money)       true = Google's test ad ("Test Ad" label, earns nothing, safe to tap)
  - NEVER tap your own real ads: AdMob can ban the account. Either set USE_TEST_ADS = true while you test on your own
    phone, or add the phone in AdMob (Settings > Test devices) so it only gets test ads.
  - Real ads need time: a new ad unit can take a few hours to start filling, and fill is low until the app is published
    and linked to its store page in AdMob.
  - To earn real money, publish the app on Google Play. Google Play does not accept package names that start with
    com.example, so change applicationId / namespace (and the Java package + manifest activity name) first.
  - Build notes: the ads SDK needs compileSdk 35 and AndroidX (already set in app/build.gradle and gradle.properties).

BUILD THE APP FROM YOUR PHONE (GitHub builds it for free)
  Upload this zip to your GitHub repository (same name replaces the old one) and the build starts.
  When the green check appears on the Actions tab, open Releases and tap AxeSimulator3D.apk.
  FIRST: uninstall the old Axe Simulator from your phone (older builds were signed with a different key).
  From now on every build uses the same key, so new versions install over the old one.

CODE MAP (all C++)  app/src/main/cpp/
  axe_sim.h        the game: hills, trees, axe, shop, port, worlds, options, menus, saving
  engine.cpp       engine core: math, scene, physics (also runs in a terminal)
  gpu_renderer.h   GPU renderer, shaders and the text drawing
  gltf_loader.h    .glb model loader
  touch_ui.h       joystick, buttons and the font reader
  android_main.cpp the Android app: window, GPU setup, touch input (also tells Java to hide the ad while a menu is open)
  MainActivity.java (app/src/main/java/...) the only Java: starts AdMob and shows the banner
