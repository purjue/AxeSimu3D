AXE SIMULATOR 3D  -  an Android game written in C++ (OpenGL ES 3.0 engine, no Godot, no Java)
===============================================================================================

THE GAME
  - Chop 60 pine trees on a hilly 256 m meadow. Trees fall and grow back after a while.
  - SHOP (food stall): sell wood (5 coins each), upgrade the axe and your stamina.
      Every axe level adds +10% CHANCE of double wood from a tree (up to 90%).
  - PORT (the gate): WORLD 2 (autumn woods, 60 trees) costs 100,000 coins. Every tree there gives 10x wood.
  - Progress and settings are saved automatically.

CONTROLS (landscape)
  Joystick  : touch anywhere on the left half. It is small, but the touch area is big and dynamic (the stick follows
              your finger). It only WALKS (forward, back, sideways). It never turns the camera.
  Camera    : drag anywhere else on the screen. You can move and look at the same time.
  CHOP, JUMP, SHOP/PORT : three small buttons on the right (SHOP / PORT appears when you stand near them).
  OPTIONS   : button under the wood / coin counters (top left).

OPTIONS
  Camera view (first / third person), graphics LOW / MEDIUM / HIGH, resolution scaler (30% to 125%, 100% = full
  resolution), shadows on/off, auto lower (lowers graphics by itself if the game is slow), restart world.

TEXT: everything you read in the game uses the Kurland font (tools/Kurland.ttf, baked into the app's assets/fonts).
  To change the font: python3 tools/bake_font.py tools/YourFont.ttf app/src/main/assets/fonts

BUILD THE APP FROM YOUR PHONE (GitHub builds it for free)
  Upload this zip to your GitHub repository (same name replaces the old one) and the build starts.
  When the green check appears on the Actions tab, open Releases and tap AxeSimulator3D.apk.
  FIRST: uninstall the old Axe Simulator from your phone (older builds were signed with a different key).
  From now on every build uses the same key, so new versions install over the old one.

CODE MAP (all C++)  app/src/main/cpp/
  axe_sim.h        the game: hills, trees, axe, shop, port, worlds, options, menus, saving
  engine.cpp       engine core: math, scene, physics (also runs in a terminal)
  gpu_renderer.h   GPU renderer, shaders and the text drawing
  gltf_loader.h    .glb model loader
  touch_ui.h       joystick, buttons and the font reader
  android_main.cpp the Android app: window, GPU setup, touch input
