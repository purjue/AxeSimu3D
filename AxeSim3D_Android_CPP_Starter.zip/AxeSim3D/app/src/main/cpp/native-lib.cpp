#include <jni.h>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <cmath>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>
#include <cstdint>
#include <limits>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"AxeSim3D",__VA_ARGS__)
struct V3 { float x,y,z; };
static V3 add(V3 a,V3 b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
static V3 sub(V3 a,V3 b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
static V3 mul(V3 a,float s){return {a.x*s,a.y*s,a.z*s};}
static float dot(V3 a,V3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
static V3 norm(V3 a){float l=sqrtf(dot(a,a));return l>0?mul(a,1.f/l):V3{0,0,0};}
static float identity(float *m){for(int i=0;i<16;i++)m[i]=(i%5==0)?1.f:0.f;return 1;}
static void mm(const float*a,const float*b,float*out){float t[16];for(int c=0;c<4;c++)for(int r=0;r<4;r++)t[c*4+r]=a[0*4+r]*b[c*4+0]+a[1*4+r]*b[c*4+1]+a[2*4+r]*b[c*4+2]+a[3*4+r]*b[c*4+3];for(int i=0;i<16;i++)out[i]=t[i];}
static void translate(float*m,float x,float y,float z){identity(m);m[12]=x;m[13]=y;m[14]=z;}
static void scaleM(float*m,float x,float y,float z){identity(m);m[0]=x;m[5]=y;m[10]=z;}
static void perspective(float*m,float fovy,float aspect,float n,float f){for(int i=0;i<16;i++)m[i]=0;float q=1.f/tanf(fovy*.5f);m[0]=q/aspect;m[5]=q;m[10]=(f+n)/(n-f);m[11]=-1;m[14]=(2*f*n)/(n-f);}
static void lookAt(float*m,V3 eye,V3 center,V3 up){V3 f=norm(sub(center,eye)),s=norm({f.y*up.z-f.z*up.y,f.z*up.x-f.x*up.z,f.x*up.y-f.y*up.x}),u={s.y*f.z-s.z*f.y,s.z*f.x-s.x*f.z,s.x*f.y-s.y*f.x};identity(m);m[0]=s.x;m[4]=s.y;m[8]=s.z;m[1]=u.x;m[5]=u.y;m[9]=u.z;m[2]=-f.x;m[6]=-f.y;m[10]=-f.z;m[12]=-dot(s,eye);m[13]=-dot(u,eye);m[14]=dot(f,eye);}
static const char* VS="attribute vec3 aPos; attribute vec3 aNorm; uniform mat4 uMVP; uniform vec4 uColor; varying vec4 vColor; void main(){float l=0.58+0.42*max(dot(normalize(aNorm),normalize(vec3(-0.4,0.9,0.3))),0.0);vColor=vec4(uColor.rgb*l,uColor.a);gl_Position=uMVP*vec4(aPos,1.0);}";
static const char* FS="precision mediump float; varying vec4 vColor; void main(){gl_FragColor=vColor;}";
static GLuint prog=0,vbo=0; static GLint aPos=-1,aNorm=-1,uMVP=-1,uColor=-1;
static std::vector<float> cubeVerts;
static void face(float a[3],float b[3],float c[3],float d[3],float nx,float ny,float nz){float p[18]={a[0],a[1],a[2],b[0],b[1],b[2],c[0],c[1],c[2],a[0],a[1],a[2],c[0],c[1],c[2],d[0],d[1],d[2]};for(int i=0;i<6;i++){cubeVerts.push_back(p[i*3]);cubeVerts.push_back(p[i*3+1]);cubeVerts.push_back(p[i*3+2]);cubeVerts.push_back(nx);cubeVerts.push_back(ny);cubeVerts.push_back(nz);}}
static void makeCube(){if(!cubeVerts.empty())return;float p[8][3]={{-.5f,-.5f,-.5f},{.5f,-.5f,-.5f},{.5f,.5f,-.5f},{-.5f,.5f,-.5f},{-.5f,-.5f,.5f},{.5f,-.5f,.5f},{.5f,.5f,.5f},{-.5f,.5f,.5f}};face(p[4],p[5],p[6],p[7],0,0,1);face(p[1],p[0],p[3],p[2],0,0,-1);face(p[0],p[4],p[7],p[3],-1,0,0);face(p[5],p[1],p[2],p[6],1,0,0);face(p[3],p[7],p[6],p[2],0,1,0);face(p[0],p[1],p[5],p[4],0,-1,0);}
static GLuint shader(GLenum type,const char*src){GLuint s=glCreateShader(type);glShaderSource(s,1,&src,nullptr);glCompileShader(s);GLint ok=0;glGetShaderiv(s,GL_COMPILE_STATUS,&ok);if(!ok){char b[1024];glGetShaderInfoLog(s,1024,nullptr,b);LOGE("shader: %s",b);}return s;}
static void initGL(){if(prog)return;makeCube();GLuint v=shader(GL_VERTEX_SHADER,VS),f=shader(GL_FRAGMENT_SHADER,FS);prog=glCreateProgram();glAttachShader(prog,v);glAttachShader(prog,f);glBindAttribLocation(prog,0,"aPos");glBindAttribLocation(prog,1,"aNorm");glLinkProgram(prog);aPos=0;aNorm=1;uMVP=glGetUniformLocation(prog,"uMVP");uColor=glGetUniformLocation(prog,"uColor");glGenBuffers(1,&vbo);glBindBuffer(GL_ARRAY_BUFFER,vbo);glBufferData(GL_ARRAY_BUFFER,cubeVerts.size()*sizeof(float),cubeVerts.data(),GL_STATIC_DRAW);}
static float px=0,pz=0,moveX=0,moveY=0;static int64_t wood=0;static int quality=1;static bool jumping=false,chopping=false;static float jumpT=0,chopT=0,angle=0;static int treeHits[18];
static const int64_t axeCosts[2][10]={{0,100,500,1500,5000,7500,15000,30000,500000,10000000},{600000000000LL,1200000000000LL,2500000000000LL,5000000000000LL,10000000000000LL,20000000000000LL,40000000000000LL,80000000000000LL,160000000000000LL,320000000000000LL}};
static const int64_t powerCosts[2][5]={{5000,10000,50000,400000,1600000},{20000000000000LL,40000000000000LL,80000000000000LL,160000000000000LL,320000000000000LL}};
static const int64_t boostCosts[2][5]={{10000,200000,500000,700000,1600000},{80000000000000LL,160000000000000LL,320000000000000LL,640000000000000LL,1280000000000000LL}};
static const int64_t axeMult[2][10]={{1,5,15,50,75,150,300,1000,20000,100000},{1000000,2000000,5000000,10000000,20000000,50000000,100000000,200000000,500000000,1000000000}};
static const int64_t powerMult[2][5]={{2,4,8,16,32},{64,128,256,512,1024}};
static const int64_t boostMult[2][5]={{2,4,8,16,32},{64,128,256,512,1024}};
static bool axeOwned[2][10]={{true,false,false,false,false,false,false,false,false,false},{false,false,false,false,false,false,false,false,false,false}};
static bool powerOwned[2][5]={{false,false,false,false,false},{false,false,false,false,false}};
static bool boostOwned[2][5]={{false,false,false,false,false},{false,false,false,false,false}};
static int equipAxeShop=0,equipAxeTier=0,equipPowerShop=0,equipPowerTier=-1,boostTier[2]={0,0};
static int64_t axeMultiplier=1,powerMultiplier=1,boostMultiplier=0;
static int64_t satMul(int64_t a,int64_t b){if(a<=0||b<=0)return 0;if(a>INT64_MAX/b)return INT64_MAX;return a*b;}
static int64_t satAdd(int64_t a,int64_t b){if(b<=0)return a;if(a>INT64_MAX-b)return INT64_MAX;return a+b;}
static void equipItemInternal(int shop,int cat,int tier){if(shop<0||shop>1)return;if(cat==0&&tier>=0&&tier<10&&axeOwned[shop][tier]){equipAxeShop=shop;equipAxeTier=tier;axeMultiplier=axeMult[shop][tier];}else if(cat==1&&tier>=0&&tier<5&&powerOwned[shop][tier]){equipPowerShop=shop;equipPowerTier=tier;powerMultiplier=powerMult[shop][tier];}}

static V3 trees[18];
static void initWorld(){for(int i=0;i<18;i++){float a=(float)i*2.39996323f;float r=5.0f+float(i%5)*1.6f;trees[i]={cosf(a)*r,0,sinf(a)*r};treeHits[i]=0;} }
static void drawCube(const float*P,const float*V,V3 pos,V3 sc,float r,float g,float b){float T[16],S[16],M[16],VM[16],MVP[16];translate(T,pos.x,pos.y,pos.z);scaleM(S,sc.x,sc.y,sc.z);mm(T,S,M);mm(V,M,VM);mm(P,VM,MVP);glUniformMatrix4fv(uMVP,1,GL_FALSE,MVP);glUniform4f(uColor,r,g,b,1);glDrawArrays(GL_TRIANGLES,0,(GLsizei)(cubeVerts.size()/6));}
static void drawTree(const float*P,const float*V,V3 t,int hit){if(hit>=3)return;drawCube(P,V,{t.x,.9f,t.z},{.32f,1.8f,.32f},.34f,.19f,.08f);drawCube(P,V,{t.x,2.0f,t.z},{1.45f,1.7f,1.45f},.09f,.35f,.12f);drawCube(P,V,{t.x,2.9f,t.z},{1.05f,1.2f,1.05f},.12f,.43f,.14f);}
static void drawScene(int w,int h){initGL();glViewport(0,0,w,h);if(quality==0)glClearColor(.48f,.68f,.82f,1);else glClearColor(.38f,.65f,.83f,1);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);glEnable(GL_DEPTH_TEST);glUseProgram(prog);glBindBuffer(GL_ARRAY_BUFFER,vbo);glEnableVertexAttribArray(aPos);glEnableVertexAttribArray(aNorm);glVertexAttribPointer(aPos,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)0);glVertexAttribPointer(aNorm,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)(3*sizeof(float)));
 float P[16],V[16];perspective(P,0.92f,(float)w/(float)std::max(1,h),.1f,100.f);V3 eye={px+7,5.5f,pz+8};lookAt(V,eye,{px,1.0f,pz},{0,1,0});
 drawCube(P,V,{0,-.35f,0},{42,.6f,42},.20f,.39f,.16f); // island floor
 // path to stall
 drawCube(P,V,{0,-.015f,-3.2f},{3.1f,.04f,5.0f},.42f,.35f,.24f);
 for(int i=0;i<18;i++)drawTree(P,V,trees[i],treeHits[i]);
 // shop stall, canopy, counter
 drawCube(P,V,{0,1.05f,-7.1f},{3.0f,2.1f,.28f},.40f,.22f,.10f);
 drawCube(P,V,{0,2.2f,-7.1f},{3.5f,.35f,1.25f},.68f,.13f,.08f);
 drawCube(P,V,{-1.25f,1.0f,-6.65f},{.18f,2.0f,.18f},.27f,.14f,.07f);drawCube(P,V,{1.25f,1.0f,-6.65f},{.18f,2.0f,.18f},.27f,.14f,.07f);
 float jumpY=0;if(jumping){jumpY=sinf(jumpT*3.14159f)*1.4f;}drawCube(P,V,{px,.95f+jumpY,pz},{.62f,1.25f,.38f},.18f,.34f,.70f);drawCube(P,V,{px,1.78f+jumpY,pz},{.42f,.42f,.42f},.83f,.65f,.45f);
 // arms and axe swing
 float swing=chopping?sinf(chopT*3.14159f)*.8f:0;drawCube(P,V,{px+.36f,1.2f+jumpY,pz-.12f},{.18f,.62f,.18f},.83f,.65f,.45f);drawCube(P,V,{px+.47f+swing,1.2f+jumpY,pz-.45f},{.12f,.65f,.12f},.35f,.22f,.10f);drawCube(P,V,{px+.49f+swing,1.48f+jumpY,pz-.53f},{.52f,.2f,.12f},.72f,.74f,.78f);
 // subtle island edge stones
 for(int i=0;i<24;i++){float a=i*6.2831853f/24;drawCube(P,V,{cosf(a)*19.5f,-.04f,sinf(a)*19.5f},{.65f,.28f,.65f},.32f,.33f,.31f);}
 glDisableVertexAttribArray(aPos);glDisableVertexAttribArray(aNorm);
}
static void tick(float dt){if(fabsf(moveX)+fabsf(moveY)>.08f){float spd=3.2f;px+=moveX*spd*dt;pz+=moveY*spd*dt;px=std::max(-18.f,std::min(18.f,px));pz=std::max(-18.f,std::min(18.f,pz));angle=atan2f(moveX,-moveY);}if(jumping){jumpT+=dt*1.7f;if(jumpT>=1){jumping=false;jumpT=0;}}if(chopping){chopT+=dt*2.8f;if(chopT>=1){chopping=false;chopT=0;float best=2.6f;int idx=-1;for(int i=0;i<18;i++){if(treeHits[i]>=3)continue;float dx=trees[i].x-px,dz=trees[i].z-pz;float d=sqrtf(dx*dx+dz*dz);if(d<best){best=d;idx=i;}}if(idx>=0){treeHits[idx]++;wood=satAdd(wood,satMul(axeMultiplier,satAdd(powerMultiplier,boostMultiplier)));}}}}
extern "C" JNIEXPORT void JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeInit(JNIEnv*,jclass){initWorld();}
extern "C" JNIEXPORT void JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeDraw(JNIEnv*,jclass,jint w,jint h,jfloat dt){tick(std::min(.05f,std::max(.001f,dt)));drawScene(w,h);}
extern "C" JNIEXPORT void JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeMove(JNIEnv*,jclass,jfloat x,jfloat y){moveX=std::max(-1.f,std::min(1.f,x));moveY=std::max(-1.f,std::min(1.f,y));}
extern "C" JNIEXPORT void JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeJump(JNIEnv*,jclass){if(!jumping){jumping=true;jumpT=0;}}
extern "C" JNIEXPORT void JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeChop(JNIEnv*,jclass){if(!chopping){chopping=true;chopT=0;}}
extern "C" JNIEXPORT jint JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeBuyItem(JNIEnv*,jclass,jint shop,jint cat,jint tier){if(shop<0||shop>1||tier<0)return 0;int64_t cost=0;if(cat==0){if(tier>=10||axeOwned[shop][tier])return 0;cost=axeCosts[shop][tier];}else if(cat==1){if(tier>=5||powerOwned[shop][tier])return 0;cost=powerCosts[shop][tier];}else if(cat==2){if(tier>=5||tier!=boostTier[shop]||boostOwned[shop][tier])return 0;cost=boostCosts[shop][tier];}else return 0;if(wood<cost)return 0;wood-=cost;if(cat==0){axeOwned[shop][tier]=true;equipItemInternal(shop,cat,tier);}else if(cat==1){powerOwned[shop][tier]=true;equipItemInternal(shop,cat,tier);}else{boostOwned[shop][tier]=true;boostTier[shop]++;boostMultiplier=boostMult[shop][tier];}return 1;}
extern "C" JNIEXPORT jint JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeEquipItem(JNIEnv*,jclass,jint shop,jint cat,jint tier){if(shop<0||shop>1||tier<0)return 0;if(cat==0&&tier<10&&axeOwned[shop][tier]){equipItemInternal(shop,cat,tier);return 1;}if(cat==1&&tier<5&&powerOwned[shop][tier]){equipItemInternal(shop,cat,tier);return 1;}return 0;}
extern "C" JNIEXPORT jint JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeGetItemState(JNIEnv*,jclass,jint shop,jint cat,jint tier){if(shop<0||shop>1||tier<0)return 0;if(cat==0&&tier<10){if(!axeOwned[shop][tier])return 0;return equipAxeShop==shop&&equipAxeTier==tier?2:1;}if(cat==1&&tier<5){if(!powerOwned[shop][tier])return 0;return equipPowerShop==shop&&equipPowerTier==tier?2:1;}if(cat==2&&tier<5){if(boostOwned[shop][tier])return 2;if(tier==boostTier[shop])return 0;return 3;}return 0;}
extern "C" JNIEXPORT jlong JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeGetItemCost(JNIEnv*,jclass,jint shop,jint cat,jint tier){if(shop<0||shop>1||tier<0)return 0;if(cat==0&&tier<10)return (jlong)axeCosts[shop][tier];if(cat==1&&tier<5)return (jlong)powerCosts[shop][tier];if(cat==2&&tier<5)return (jlong)boostCosts[shop][tier];return 0;}
extern "C" JNIEXPORT jlong JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeGetWood(JNIEnv*,jclass){return (jlong)wood;}
extern "C" JNIEXPORT jint JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeGetUpgrade(JNIEnv*,jclass){return equipAxeTier+1;}
extern "C" JNIEXPORT jint JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeGetQuality(JNIEnv*,jclass){return quality;}
extern "C" JNIEXPORT void JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeToggleQuality(JNIEnv*,jclass){quality=(quality+1)%3;}
extern "C" JNIEXPORT jstring JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeSave(JNIEnv* env,jclass){std::ostringstream s;s<<wood<<','<<px<<','<<pz<<','<<quality<<','<<equipAxeShop<<','<<equipAxeTier<<','<<equipPowerShop<<','<<equipPowerTier<<','<<boostTier[0]<<','<<boostTier[1];for(int sh=0;sh<2;sh++)for(int i=0;i<10;i++)s<<','<<(axeOwned[sh][i]?1:0);for(int sh=0;sh<2;sh++)for(int i=0;i<5;i++)s<<','<<(powerOwned[sh][i]?1:0);for(int sh=0;sh<2;sh++)for(int i=0;i<5;i++)s<<','<<(boostOwned[sh][i]?1:0);for(int i=0;i<18;i++)s<<','<<treeHits[i];std::string v=s.str();return env->NewStringUTF(v.c_str());}
extern "C" JNIEXPORT void JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeLoad(JNIEnv* env,jclass,jstring data){if(!data)return;const char*c=env->GetStringUTFChars(data,nullptr);std::stringstream ss(c?c:"");std::string part;std::vector<int64_t>a;while(std::getline(ss,part,',')){try{a.push_back(std::stoll(part));}catch(...){a.push_back(0);}}if(a.size()>=68){wood=std::max<int64_t>(0,a[0]);px=(float)a[1];pz=(float)a[2];quality=std::max(0,std::min(2,(int)a[3]));equipAxeShop=std::max(0,std::min(1,(int)a[4]));equipAxeTier=std::max(0,std::min(9,(int)a[5]));equipPowerShop=std::max(0,std::min(1,(int)a[6]));equipPowerTier=std::max(-1,std::min(4,(int)a[7]));boostTier[0]=std::max(0,std::min(5,(int)a[8]));boostTier[1]=std::max(0,std::min(5,(int)a[9]));int k=10;for(int sh=0;sh<2;sh++)for(int i=0;i<10;i++)axeOwned[sh][i]=a[k++]!=0;for(int sh=0;sh<2;sh++)for(int i=0;i<5;i++)powerOwned[sh][i]=a[k++]!=0;for(int sh=0;sh<2;sh++)for(int i=0;i<5;i++)boostOwned[sh][i]=a[k++]!=0;for(int i=0;i<18;i++)treeHits[i]=std::max(0,std::min(3,(int)a[k++]));axeMultiplier=axeMult[equipAxeShop][equipAxeTier];powerMultiplier=(equipPowerTier>=0&&powerOwned[equipPowerShop][equipPowerTier])?powerMult[equipPowerShop][equipPowerTier]:1;boostMultiplier=0;if(boostTier[0]>0)boostMultiplier=boostMult[0][boostTier[0]-1];if(boostTier[1]>0)boostMultiplier=boostMult[1][boostTier[1]-1];}if(c)env->ReleaseStringUTFChars(data,c);}
extern "C" JNIEXPORT jint JNICALL Java_com_pranjal_axesim3d_NativeBridge_nativeNearShop(JNIEnv*,jclass){float dx=px,dz=pz+7.1f;return (dx*dx+dz*dz<25.f)?1:0;}
