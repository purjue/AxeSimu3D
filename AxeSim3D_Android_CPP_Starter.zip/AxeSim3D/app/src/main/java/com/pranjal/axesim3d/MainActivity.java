package com.pranjal.axesim3d;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Toast;
import java.util.Locale;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    private GLSurfaceView glView;
    private TextView hud;
    private Button shopButton;
    private FrameLayout root;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private boolean shopOpen = false;
    private Runnable hudUpdater;

    private static int dp(Context c, float v) { return (int)(v*c.getResources().getDisplayMetrics().density+0.5f); }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        prefs = getSharedPreferences("axesim3d_save", MODE_PRIVATE);
        root = new FrameLayout(this);
        glView = new GLSurfaceView(this);
        glView.setEGLContextClientVersion(2);
        glView.setPreserveEGLContextOnPause(true);
        glView.setRenderer(new GLSurfaceView.Renderer() {
            long last=0;
            @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) { NativeBridge.nativeInit(); String save=prefs.getString("save_data", ""); if(!save.isEmpty()) NativeBridge.nativeLoad(save); }
            @Override public void onSurfaceChanged(GL10 gl, int width, int height) {}
            @Override public void onDrawFrame(GL10 gl) { long now=System.nanoTime(); float dt=last==0?0.016f:(now-last)/1_000_000_000f; last=now; NativeBridge.nativeDraw(glView.getWidth(),glView.getHeight(),dt); }
        });
        glView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(glView, new FrameLayout.LayoutParams(-1,-1));
        addHud(); addControls(); setContentView(root);
        hudUpdater = new Runnable(){@Override public void run(){ if(hud!=null){hud.setText(String.format(Locale.US,"AXESIM3D   |   Wood: %,d   |   Axe Lv. %d",NativeBridge.nativeGetWood(),NativeBridge.nativeGetUpgrade())); if(shopButton!=null) shopButton.setVisibility(NativeBridge.nativeNearShop()==1?View.VISIBLE:View.GONE);} handler.postDelayed(this,350);}};
        handler.post(hudUpdater);
    }
    private TextView label(String s) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(15); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setShadowLayer(3,1,1,Color.BLACK); return t; }
    private void addHud(){hud=label("AXESIM3D | Loading..."); hud.setPadding(dp(this,12),dp(this,8),dp(this,12),dp(this,8)); FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);p.setMargins(dp(this,8),dp(this,8),0,0);root.addView(hud,p);TextView credit=label("Made by Pranjal Nayak");credit.setTextSize(11);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT);cp.setMargins(0,dp(this,10),dp(this,12),0);root.addView(credit,cp);}
    private Button makeButton(String text){Button b=new Button(this);b.setText(text);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(46,65,55)));b.setMinWidth(dp(this,68));b.setMinHeight(dp(this,44));return b;}
    private void addControls(){
        Joystick joystick=new Joystick(this); FrameLayout.LayoutParams jp=new FrameLayout.LayoutParams(dp(this,148),dp(this,148),Gravity.BOTTOM|Gravity.LEFT);jp.setMargins(dp(this,18),0,0,dp(this,16));root.addView(joystick,jp);
        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setGravity(Gravity.CENTER);FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.BOTTOM);rp.setMargins(0,0,dp(this,14),dp(this,12));root.addView(right,rp);
        Button chop=makeButton("🪓 Chop");right.addView(chop);chop.setOnClickListener(v->glView.queueEvent(NativeBridge::nativeChop));
        Button jump=makeButton("⬆ Jump");right.addView(jump);jump.setOnClickListener(v->glView.queueEvent(NativeBridge::nativeJump));
        shopButton=makeButton("Shop");right.addView(shopButton);shopButton.setVisibility(View.GONE);shopButton.setOnClickListener(v->showShop());
        Button settings=makeButton("⚙ Settings");right.addView(settings);settings.setOnClickListener(v->showSettings());
        Button save=makeButton("Save");right.addView(save);save.setOnClickListener(v->{saveGame();Toast.makeText(this,"Game saved",Toast.LENGTH_SHORT).show();});
    }
    private void showShop(){
        if(shopOpen)return; shopOpen=true;
        final FrameLayout panel=new FrameLayout(this); panel.setBackgroundColor(Color.rgb(29,39,32));
        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(this,12),dp(this,8),dp(this,12),dp(this,8));
        TextView title=label("WOOD SHOP"); title.setTextSize(20); content.addView(title);
        LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL); content.addView(tabs);
        LinearLayout categories=new LinearLayout(this); categories.setOrientation(LinearLayout.HORIZONTAL); content.addView(categories);
        ScrollView scroll=new ScrollView(this); content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL); scroll.addView(rows);
        Button close=makeButton("Close shop"); content.addView(close); close.setOnClickListener(v->{root.removeView(panel);shopOpen=false;});
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(dp(this,480),dp(this,420),Gravity.CENTER);panel.addView(content,new FrameLayout.LayoutParams(-1,-1));root.addView(panel,p);
        final int[] selected={0,0};
        final Runnable[] renderRef=new Runnable[1]; renderRef[0]=new Runnable(){@Override public void run(){
            tabs.removeAllViews();categories.removeAllViews();rows.removeAllViews();
            for(int sh=0;sh<2;sh++){final int ss=sh;Button b=makeButton(sh==0?"Shop 1":"Shop 2");tabs.addView(b,new LinearLayout.LayoutParams(0,dp(MainActivity.this,42),1));b.setOnClickListener(v->{selected[0]=ss;renderRef[0].run();});}
            String[] cats={"Axes","Power","Boosts"};for(int c=0;c<3;c++){final int cc=c;Button b=makeButton(cats[c]);categories.addView(b,new LinearLayout.LayoutParams(0,dp(MainActivity.this,40),1));b.setOnClickListener(v->{selected[1]=cc;renderRef[0].run();});}
            int count=selected[1]==0?10:5;
            for(int i=0;i<count;i++){final int tier=i;int st=NativeBridge.nativeGetItemState(selected[0],selected[1],i);long cost=NativeBridge.nativeGetItemCost(selected[0],selected[1],i);
                LinearLayout row=new LinearLayout(MainActivity.this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(MainActivity.this,4),dp(MainActivity.this,3),dp(MainActivity.this,4),dp(MainActivity.this,3));
                TextView info=label((selected[1]==0?"Axe skill ":selected[1]==1?"Power ":"Boost ")+(i+1)+"  •  "+(st==3?"Unlock previous boost":"Cost: "+String.format(Locale.US,"%,d",cost)));info.setTextSize(13);row.addView(info,new LinearLayout.LayoutParams(0,dp(MainActivity.this,42),1));
                Button action=makeButton(st==0?"Buy":st==1?"Equip":st==2?(selected[1]==2?"Owned":"Equipped"):"Locked");action.setEnabled(st==0||st==1);row.addView(action);action.setOnClickListener(v->{int sh=selected[0],cat=selected[1],t=tier;glView.queueEvent(()->{int result=NativeBridge.nativeGetItemState(sh,cat,t)==1?NativeBridge.nativeEquipItem(sh,cat,t):NativeBridge.nativeBuyItem(sh,cat,t);String data=NativeBridge.nativeSave();prefs.edit().putString("save_data",data).apply();runOnUiThread(()->{if(result==1)Toast.makeText(MainActivity.this,"Shop updated",Toast.LENGTH_SHORT).show();else Toast.makeText(MainActivity.this,"Not enough wood or item locked",Toast.LENGTH_SHORT).show();renderRef[0].run();});});});
                rows.addView(row);View divider=new View(MainActivity.this);divider.setBackgroundColor(0x55777777);rows.addView(divider,new LinearLayout.LayoutParams(-1,dp(MainActivity.this,1)));
            }
        }};
        renderRef[0].run();
    }
    private void showSettings(){String[] opts={"Low graphics","Balanced graphics","High graphics","Load saved game","Save game","Close"};new AlertDialog.Builder(this).setTitle("AxeSim3D Settings").setItems(opts,(d,which)->{if(which<=2){glView.queueEvent(()->{int cur=NativeBridge.nativeGetQuality();while(cur!=which){NativeBridge.nativeToggleQuality();cur=(cur+1)%3;}});Toast.makeText(this,opts[which]+" selected",Toast.LENGTH_SHORT).show();}else if(which==3){String s=prefs.getString("save_data","");glView.queueEvent(()->NativeBridge.nativeLoad(s));Toast.makeText(this,"Save loaded",Toast.LENGTH_SHORT).show();}else if(which==4){saveGame();Toast.makeText(this,"Game saved",Toast.LENGTH_SHORT).show();}}).show();}
    private void saveGame(){glView.queueEvent(()->{String data=NativeBridge.nativeSave();prefs.edit().putString("save_data",data).apply();});}
    @Override protected void onPause(){handler.removeCallbacks(hudUpdater);glView.onPause();String data=NativeBridge.nativeSave();prefs.edit().putString("save_data",data).apply();super.onPause();}
    @Override protected void onResume(){super.onResume();glView.onResume();if(hudUpdater!=null)handler.post(hudUpdater);}

    private class Joystick extends View {
        private float cx,cy,dx,dy;private final android.graphics.Paint paint=new android.graphics.Paint(3);
        Joystick(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(android.graphics.Canvas c){super.onDraw(c);float r=Math.min(getWidth(),getHeight())*.45f;cx=getWidth()/2f;cy=getHeight()/2f;paint.setColor(0x66333333);c.drawCircle(cx,cy,r,paint);paint.setColor(0x99eeeeee);c.drawCircle(cx+dx,cy+dy,r*.36f,paint);}
        @Override public boolean onTouchEvent(MotionEvent e){float r=Math.min(getWidth(),getHeight())*.34f;if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){float x=e.getX()-getWidth()/2f,y=e.getY()-getHeight()/2f;float l=(float)Math.sqrt(x*x+y*y);if(l>r){x*=r/l;y*=r/l;}dx=x;dy=y;NativeBridge.nativeMove(x/r,-y/r);invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){dx=dy=0;NativeBridge.nativeMove(0,0);invalidate();return true;}return true;}
    }
}
