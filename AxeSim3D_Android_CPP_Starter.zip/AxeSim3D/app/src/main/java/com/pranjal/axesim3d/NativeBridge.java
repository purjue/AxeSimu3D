package com.pranjal.axesim3d;
public final class NativeBridge {
    static { System.loadLibrary("axesim3d"); }
    private NativeBridge() {}
    public static native void nativeInit();
    public static native void nativeDraw(int width, int height, float deltaSeconds);
    public static native void nativeMove(float x, float y);
    public static native void nativeJump();
    public static native void nativeChop();
    public static native int nativeBuyItem(int shop, int category, int tier);
    public static native int nativeEquipItem(int shop, int category, int tier);
    public static native int nativeGetItemState(int shop, int category, int tier);
    public static native long nativeGetItemCost(int shop, int category, int tier);
    public static native void nativeToggleQuality();
    public static native long nativeGetWood();
    public static native int nativeGetUpgrade();
    public static native int nativeGetQuality();
    public static native int nativeNearShop();
    public static native String nativeSave();
    public static native void nativeLoad(String saveData);
}
