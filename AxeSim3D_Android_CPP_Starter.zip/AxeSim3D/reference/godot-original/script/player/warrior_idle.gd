extends Node3D


@onready var ANIME = $AnimationPlayer

func _physics_process(_delta):
	if ANIME.current_animation != "mixamo_com":
		ANIME.play("mixamo_com")
