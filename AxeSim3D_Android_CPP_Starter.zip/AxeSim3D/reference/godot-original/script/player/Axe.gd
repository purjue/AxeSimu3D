extends Node3D

var time := 0.0
var start_pos: Vector3
var start_rot: Vector3

func _ready():
	start_pos = position
	start_rot = rotation

func _process(delta):
	var x := Input.get_axis("ui_left", "ui_right")
	var y := Input.get_axis("ui_up", "ui_down")

	var moving := Vector2(x, y).length() > 0.1

	if moving:
		time += delta * 7.0

		var wave := sin(time)
		var wave2 := cos(time * 2.0)

		var target_pos := start_pos
		var target_rot := start_rot

		# Forward
		if Input.is_action_pressed("ui_up"):
			target_pos += Vector3(
				wave * 0.015,
				abs(wave) * -0.025,
				0.04
			)

			target_rot += Vector3(
				wave * 0.05,
				0.015,
				wave * 0.025
			)

		# Backward
		elif Input.is_action_pressed("ui_down"):
			target_pos += Vector3(
				wave * 0.012,
				abs(wave) * -0.020,
				-0.06
			)

			target_rot += Vector3(
				-wave * 0.035,
				-wave2 * 0.02,
				-wave * 0.025
			)

		# Left
		elif Input.is_action_pressed("ui_left"):
			target_pos += Vector3(
				-abs(wave) * 0.025,
				wave * 0.018,
				0.0
			)

			target_rot += Vector3(
				wave * 0.025,
				-wave * 0.035,
				-wave * 0.06
			)

		# Right
		elif Input.is_action_pressed("ui_right"):
			target_pos += Vector3(
				abs(wave) * 0.025,
				wave * 0.018,
				0.0
			)

			target_rot += Vector3(
				wave * 0.025,
				wave * 0.035,
				wave * 0.06
			)

		position = position.lerp(target_pos, delta * 10.0)
		rotation = rotation.lerp(target_rot, delta * 10.0)

	else:
		position = position.lerp(start_pos, delta * 10.0)
		rotation = rotation.lerp(start_rot, delta * 10.0)
