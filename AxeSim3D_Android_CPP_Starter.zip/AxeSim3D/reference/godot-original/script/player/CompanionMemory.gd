extends RefCounted
# Offline "brain" for ONE companion.
#
# - Remembers the player's last message and the companion's last reply.
# - Uses them to MODIFY the next answer (repeat / same topic / topic change /
#   short follow-ups like "again", "why", "what?", "yes", "no").
# - Saves everything to user://companion_brain/<name>.json, so it survives
#   closing the game ("Welcome back! Last time we talked about trees.").
#
# Used from Companion*.gd:
#   memory.setup(name)            in _ready()
#   memory.hear(text)             when a player message arrives
#   memory.followup(text)         -> {} | {"reply": ..} | {"rerun": .., "prefix": ..}
#   memory.shape_reply(line, pre) to modify the answer about to be said
#   memory.record_reply(line)     after every line the companion says

const SAVE_DIR := "user://companion_brain"
const MAX_CHAT := 30

const TOPICS := {
	"greeting": ["hello", "hi", "hey", "hii", "hiya", "yo", "namaste", "hola", "good morning", "good evening", "good afternoon"],
	"farewell": ["bye", "goodbye", "cya", "see you", "good night"],
	"thanks": ["thanks", "thank you", "thx", "thankyou"],
	"trees": ["tree", "trees", "wood", "chop", "chopping", "axe", "forest", "timber"],
	"shop": ["shop", "buy", "sell", "price", "store", "coins", "upgrade"],
	"tired": ["tired", "sleepy", "rest", "exhausted", "sleep"],
	"joke": ["joke", "funny", "laugh", "riddle"],
	"feelings": ["how are you", "feeling", "mood", "happy", "sad"],
}
const SMALL_TOPICS := ["greeting", "farewell", "thanks"]
const TOPIC_LABEL := {
	"trees": "trees", "shop": "the shop", "tired": "being tired",
	"joke": "jokes", "feelings": "how we feel",
}

const SAME_TOPIC_PREFIX := {
	"greeting": ["Hello again! ", "Hi again! ", "Hey, hi again! "],
	"farewell": ["Bye again! ", "Okay, see you! "],
	"thanks": ["Again, no problem! ", "You're welcome again! "],
}
const GENERIC_SAME := ["Still on this topic? ", "Same topic again, huh? ", "Okay, continuing on that: ", "Let's keep going on that: "]
const GENERIC_REPEAT := ["You said that already. ", "Again? ", "Same message, huh? ", "I heard you the first time. "]
const KEEP_REPEATING := ["You keep saying the same thing! ", "That's the third time now! ", "Okay okay, I heard you! "]
const MORE_PREFIX := ["More on that: ", "Okay, going on: ", "Alright, more: "]

const REPEAT_WORDS := ["what", "huh", "pardon", "sorry", "what did you say", "say that again", "say again", "repeat", "repeat that", "come again"]
const MORE_WORDS := ["more", "again", "tell me more", "go on", "continue", "and", "and then", "keep going"]
const WHY_WORDS := ["why", "why is that", "how come", "why so"]
const REALLY_WORDS := ["really", "seriously", "are you sure", "for real"]
const YES_WORDS := ["yes", "yeah", "yep", "yup", "sure", "ok", "okay", "of course", "ya"]
const NO_WORDS := ["no", "nope", "nah", "not now", "maybe later"]

const WHY_BY_TOPIC := {
	"trees": ["Because trees are the whole reason I'm out here.", "Because chopping is what I do best."],
	"shop": ["Because the shop is where our wood turns into progress."],
	"tired": ["Because swinging an axe all day wears anyone out."],
}
const WHY_DEFAULT := ["Just my honest take.", "That's how it seems to me, anyway.", "Because that's how I really feel."]
const YES_LINES := ["Great, glad we agree!", "Good! Let's do it.", "Nice, I like that answer."]
const NO_LINES := ["Alright, no problem.", "Okay, maybe another time.", "Fair enough."]

var companion_name := ""
var data := {
	"last_player": "",
	"last_topic_text": "",
	"last_reply": "",
	"last_topic": "",
	"last_big_topic": "",
	"repeat_count": 0,
	"pending_question": false,
	"visits": 0,
	"player_name": "",
	"topics": {},
	"chat": [],
}
var ctx := {}                 # facts about the message being answered right now
var _session_first := true    # true until the first message of this session
var _welcome_pending := false
var _shaped := false          # only the first line of a reply gets modified


# ==================== Setup / save / load ====================

func setup(name_: String) -> void:
	companion_name = name_
	_load()
	data["visits"] = int(data.get("visits", 0)) + 1
	data["pending_question"] = false
	_welcome_pending = str(data.get("last_big_topic", "")) != "" and int(data["visits"]) > 1
	_session_first = true
	save()

func _slug(s: String) -> String:
	var out := ""
	for ch in s.to_lower():
		if (ch >= "a" and ch <= "z") or (ch >= "0" and ch <= "9"):
			out += ch
		else:
			out += "_"
	return out

func _path() -> String:
	return SAVE_DIR + "/" + _slug(companion_name) + ".json"

func _load() -> void:
	if not FileAccess.file_exists(_path()):
		return
	var f := FileAccess.open(_path(), FileAccess.READ)
	if f == null:
		return
	var parsed = JSON.parse_string(f.get_as_text())
	if parsed is Dictionary:
		for k in parsed.keys():
			data[k] = parsed[k]

func save() -> void:
	DirAccess.make_dir_recursive_absolute(SAVE_DIR)
	var f := FileAccess.open(_path(), FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(data))


# ==================== Text helpers ====================

func _words(text: String) -> PackedStringArray:
	var cleaned := ""
	for ch in text.to_lower():
		if (ch >= "a" and ch <= "z") or (ch >= "0" and ch <= "9") or ch == " " or ch == "'" or ch.unicode_at(0) > 127:
			cleaned += ch
		else:
			cleaned += " "
	var out := PackedStringArray()
	for w in cleaned.split(" ", false):
		out.append(w)
	return out

func _norm(text: String) -> String:
	return " ".join(_words(text))

func detect_topic(norm: String, words: PackedStringArray) -> String:
	for topic in TOPICS:
		for kw in TOPICS[topic]:
			if " " in kw:
				if norm.contains(kw):
					return topic
			elif words.has(kw):
				return topic
	return ""

func _pick_str(pool: Array) -> String:
	return str(pool[randi() % pool.size()])

func _push_chat(who: String, text: String) -> void:
	var chat: Array = data["chat"]
	chat.append({"who": who, "text": text})
	while chat.size() > MAX_CHAT:
		chat.pop_front()

func _followup_kind(norm: String) -> String:
	if norm.begins_with("my name is ") or norm.begins_with("call me "):
		return "name"
	if norm in REPEAT_WORDS:
		return "repeat"
	if norm in MORE_WORDS:
		return "more"
	if norm in WHY_WORDS:
		return "why"
	if norm in REALLY_WORDS:
		return "really"
	if bool(data.get("pending_question", false)):
		if norm in YES_WORDS:
			return "yes"
		if norm in NO_WORDS:
			return "no"
	return ""


# ==================== 1) Capture the player's message ====================

func hear(text: String) -> Dictionary:
	var words := _words(text)
	var norm := " ".join(words)
	var topic := detect_topic(norm, words)
	var is_follow := _followup_kind(norm) != ""
	var prev_norm := _norm(str(data.get("last_player", "")))
	var last_topic := str(data.get("last_topic", ""))

	var repeated := (not _session_first) and norm != "" and norm == prev_norm
	var same_topic := (not _session_first) and topic != "" and topic == last_topic
	var switched_from := ""
	if (not _session_first) and topic != "" and last_topic != "" and topic != last_topic:
		switched_from = last_topic

	if repeated:
		data["repeat_count"] = int(data.get("repeat_count", 0)) + 1
	else:
		data["repeat_count"] = 0

	var welcome := _welcome_pending and topic == "greeting"
	_welcome_pending = false

	ctx = {
		"topic": topic,
		"repeated": repeated,
		"same_topic": same_topic,
		"switched_from": switched_from,
		"welcome": welcome,
	}
	_shaped = false
	_session_first = false

	data["last_player"] = text
	if topic != "":
		data["last_topic"] = topic
		var counts: Dictionary = data["topics"]
		counts[topic] = int(counts.get(topic, 0)) + 1
		if not (topic in SMALL_TOPICS):
			data["last_big_topic"] = topic
		if not is_follow:
			data["last_topic_text"] = text
	_push_chat("player", text)
	return ctx


# ==================== 2) Short follow-ups that use the last reply ====================

func followup(text: String) -> Dictionary:
	var norm := _norm(text)
	var kind := _followup_kind(norm)
	if kind == "":
		return {}
	var last_reply := str(data.get("last_reply", ""))

	match kind:
		"name":
			var n := norm.replace("my name is ", "").replace("call me ", "").strip_edges()
			if n == "" or n.split(" ").size() > 2:
				return {}
			data["player_name"] = n.capitalize()
			save()
			return {"reply": "Nice to meet you, %s! I'll remember that." % n.capitalize()}
		"repeat":
			if last_reply == "":
				return {}
			return {"reply": "I said: %s" % _strip_lead(last_reply)}
		"more":
			var t := str(data.get("last_topic_text", ""))
			if t == "":
				return {}
			return {"rerun": t, "prefix": _pick_str(MORE_PREFIX)}
		"why":
			if last_reply == "":
				return {}
			var pool: Array = WHY_BY_TOPIC.get(str(data.get("last_topic", "")), WHY_DEFAULT)
			return {"reply": _pick_str(pool)}
		"really":
			if last_reply == "":
				return {}
			var extra := ""
			if last_reply.length() <= 90:
				extra = " " + _strip_lead(last_reply)
			return {"reply": "Yes, really." + extra}
		"yes":
			data["pending_question"] = false
			return {"reply": _pick_str(YES_LINES)}
		"no":
			data["pending_question"] = false
			return {"reply": _pick_str(NO_LINES)}
	return {}

func _strip_lead(line: String) -> String:
	for lead in ["I said: ", "Yes, really. "]:
		if line.begins_with(lead):
			return line.substr(lead.length())
	return line


# ==================== 3) Modify the new answer using the old one ====================

func shape_reply(line: String, forced_prefix: String = "") -> String:
	if _shaped:
		return line
	_shaped = true

	var out := line
	var topic := str(ctx.get("topic", ""))
	var last_reply := str(data.get("last_reply", ""))

	if forced_prefix != "":
		out = forced_prefix + out
	elif bool(ctx.get("repeated", false)) or bool(ctx.get("same_topic", false)):
		var pool: Array
		if SAME_TOPIC_PREFIX.has(topic):
			pool = SAME_TOPIC_PREFIX[topic]
		elif bool(ctx.get("repeated", false)):
			pool = KEEP_REPEATING if int(data.get("repeat_count", 0)) >= 2 else GENERIC_REPEAT
		else:
			pool = GENERIC_SAME
		out = _pick_str(pool) + out
	elif str(ctx.get("switched_from", "")) != "" and randf() < 0.5:
		var old_label := str(TOPIC_LABEL.get(str(ctx["switched_from"]), ""))
		if old_label != "":
			out = "Okay, moving on from %s. " % old_label + out

	# Never say exactly what was said last time.
	if out == last_reply:
		out = "Like I said: " + out

	# First hello of a new session: remember the last real conversation.
	if bool(ctx.get("welcome", false)):
		var label := str(TOPIC_LABEL.get(str(data.get("last_big_topic", "")), ""))
		if label != "":
			var who := str(data.get("player_name", ""))
			var comma := ""
			if who != "":
				comma = ", " + who
			out += " Welcome back%s! Last time we talked about %s." % [comma, label]
	return out


# ==================== 4) Capture the companion's reply ====================

func record_reply(line: String) -> void:
	data["last_reply"] = line
	data["pending_question"] = line.strip_edges().ends_with("?")
	_push_chat(companion_name, line)
	save()
