extends Node
## Companion-to-companion conversations with distinct speaking styles.

@export var interaction_distance: float = 4.5
@export var check_interval: float = 3.5
@export var talk_cooldown: float = 8.0

var timer: float = 1.5
var cooldowns: Dictionary = {}

var base_lines := [
	["How's the tree run going?", "Pretty good. Plenty of trees around."],
	["Need a hand?", "I'm good for now, thanks."],
	["The new terrain feels nice.", "Yeah, the paths are much better."],
	["You heading to the shop?", "Not yet. I have more wood to gather."],
	["Let's not pick the same tree.", "Agreed. I'll take the next one."],
	["You okay?", "Yep. Just taking a short break."],
]

func _process(delta: float) -> void:
	timer -= delta
	if timer > 0.0:
		return
	timer = check_interval

	for key in cooldowns.keys():
		cooldowns[key] -= check_interval
		if cooldowns[key] <= 0.0:
			cooldowns.erase(key)

	var me := get_parent()
	if me == null or not me.is_in_group("companion"):
		return

	var nearest: Node3D = null
	var nearest_distance := interaction_distance
	for other in get_tree().get_nodes_in_group("companion"):
		if other == me or not is_instance_valid(other) or not other is Node3D:
			continue
		var d = me.global_position.distance_to(other.global_position)
		if d < nearest_distance:
			nearest = other
			nearest_distance = d

	if nearest == null:
		return
	if bool(me.get("is_chopping")) or bool(nearest.get("is_chopping")):
		return

	var pair_key := _pair_key(me, nearest)
	if cooldowns.has(pair_key):
		return
	cooldowns[pair_key] = talk_cooldown

	var pair = base_lines[randi() % base_lines.size()]
	var a_line := _style_line(me, pair[0], true)
	var b_line := _style_line(nearest, pair[1], false)
	if me.has_method("say"):
		me.say(a_line)
	if nearest.has_method("say"):
		nearest.say(b_line)
	_face_each_other(me, nearest)

func _style_line(companion: Node, line: String, first_speaker: bool) -> String:
	var name := ""
	if companion.has_method("get_companion_name"):
		name = str(companion.get_companion_name())
	match name:
		"Pranjal Nayak":
			# Strongest-minded: analytical, deliberate and strategic.
			var pranjal := [
				"Let's think about that carefully: " + line,
				"I see the bigger picture. " + line,
				"Strategically, I'd say: " + line,
				"That checks out. " + line
			]
			return pranjal[randi() % pranjal.size()]
		"Aman":
			# Confident and energetic, with simpler wording.
			return ("Yeah! " if first_speaker else "Definitely! ") + line
		"Pakhi":
			# Friendly, curious and expressive.
			return ["Hmm, ", "Oh! ", "You know what? "][randi() % 3] + line
		"Aashutosh":
			# Most concise and practical.
			var short_line := line
			if short_line.length() > 38:
				short_line = short_line.substr(0, 38).strip_edges() + "..."
			return short_line.rstrip(".!?") + "."
	return line

func _pair_key(a: Node, b: Node) -> String:
	var aa := str(a.get_instance_id())
	var bb := str(b.get_instance_id())
	if aa < bb:
		return aa + ":" + bb
	return bb + ":" + aa

func _face_each_other(a: Node3D, b: Node3D) -> void:
	if a.has_method("_face_towards"):
		a._face_towards(b.global_position)
	if b.has_method("_face_towards"):
		b._face_towards(a.global_position)
