extends CharacterBody3D

# This is Companion 4's independent AI instance.
# Its wood/progression is stored by WoodCompanion4.gd and never uses another companion's save.
@export var companion_name: String = "Aashutosh"
const WoodSystemScript = preload("res://script/counter/WoodCompanion4.gd")
var wood_system: Node

const NumberFormat = preload("res://script/counter/NumberFormat.gd")
const CompanionMemoryScript = preload("res://script/player/CompanionMemory.gd")

signal said(line: String)   # UI listens to this to show a one-line speech bubble

var target_tree: Node3D

@export var move_speed: float = 5.0
@export var wood_needed_to_deliver: int = 100
@export var obedience_chance: float = 0.7
@export var idle_chat_interval_min: float = 25.0
@export var idle_chat_interval_max: float = 60.0

@onready var ANIME = $CompanionMesh/AnimationPlayer
@onready var LABEL_3D = $Counter/WoodLabel

@export var patrol_waypoints: Array[Node3D] = []   # drag Marker3D (or any Node3D) nodes here, in order
@export var patrol_loop: bool = true                # true: loops back to start. false: ping-pongs back and forth
@export var patrol_arrive_distance: float = 0.6


var carried_wood: int = 0
var carried_value: int = 0        # what carried_wood is worth on delivery (includes tree power)
var mode: String = "auto"          # "auto", "follow", "stay", "patrol", "avoid", "resting"
var task: String = "gathering"     # only used while mode == "auto": "gathering" or "delivering"
var patrol_index: int = 0
var patrol_forward: bool = true    # used only when patrol_loop == false
var shop_position: Vector3
var player: Node3D
var idle_timer: float = 0.0

var ai_multiplier: int = 1

var spawn_position: Vector3
var current_target_tree: Node3D = null

# Give-up tracking for gathering. Without this the companion locks onto a
# tree and never lets go — if that tree is unreachable (off the navmesh,
# stacked under another tree, etc.) it stays stuck on it forever while
# perfectly good trees are right next to it.
@export var tree_give_up_time: float = 60.0     # max seconds to spend trying to reach one tree
@export var tree_blacklist_time: float = 90.0   # how long to skip a tree it gave up on
var tree_blacklist: Dictionary = {}             # tree node -> time (sec) it can be tried again
var target_tree_since: float = 0.0
var stuck_check_time: float = 0.0
var stuck_check_dist: float = INF
var arrived_since: float = -1.0
var last_gather_call: float = 0.0

var wander_target: Vector3
var wander_radius: float = 8.0
var has_wander_target: bool = false
var is_chopping: bool = false

# ==================== Fatigue & resting ====================
# A real stamina value instead of "tired" only being something it says
# when asked. Builds up from continuous work (chopping + walking while it
# has somewhere to be), drains its speed the higher it gets, and — like an
# actual person — once it gets high enough the companion decides on its
# own to stop and rest for a bit, rather than working itself into the
# ground until told to stop. It gets back up and resumes on its own too.
@export var fatigue_per_chop: float = 1.5
@export var fatigue_per_meter: float = 0.035
@export var fatigue_idle_recover_per_sec: float = 8.0    # recovery while merely standing around
@export var fatigue_rest_recover_per_sec: float = 22.0   # recovery while deliberately resting (faster)
@export var fatigue_slow_start: float = 60.0             # fatigue level where speed starts dropping
@export var fatigue_max_slow: float = 0.85               # speed multiplier floor at 100 fatigue
@export var fatigue_rest_threshold: float = 92.0          # fatigue level that triggers an autonomous rest
@export var fatigue_resume_threshold: float = 30.0        # fatigue level it recovers back down to before resuming
var fatigue: float = 0.0                                  # 0-100
var last_position: Vector3 = Vector3.ZERO
var delivery_stall_time: float = 0.0
var has_commented_fatigue: bool = false
var mode_before_rest: String = "auto"
var task_before_rest: String = "gathering"

# ==================== Mood ====================
# How it actually feels about you, not just canned dialogue — serious
# insults hurt it (separate from the existing lighthearted "you're slow"
# banter, which stays as-is), kindness helps it, and if it drops low
# enough it stops wanting to be around you: it breaks off whatever it's
# doing and puts distance between you and it for a while, and is
# noticeably less cooperative with commands in the meantime.
@export var mood_insult_penalty: float = 25.0
@export var mood_kindness_gain: float = 8.0
@export var mood_avoid_duration: float = 20.0
@export var mood_avoid_distance: float = 6.0
var affection: float = 60.0                      # 0-100
var avoid_timer: float = 0.0

# ==================== Idle variety ====================
var idle_variant_timer: float = 0.0
var using_rest_idle: bool = false

func _mood() -> String:
	if affection >= 80.0:
		return "cheerful"
	elif affection >= 55.0:
		return "happy"
	elif affection >= 35.0:
		return "neutral"
	elif affection >= 15.0:
		return "annoyed"
	return "angry"

func _apply_mood_change(amount: float):
	affection = clamp(affection + amount, 0.0, 100.0)

# Low affection makes it generally less cooperative, not just less willing
# to come when insulted specifically — someone who's upset with you
# doesn't cheerfully do everything else you ask either.
func _effective_obedience_chance() -> float:
	if affection < 15.0:
		return obedience_chance * 0.2
	elif affection < 35.0:
		return obedience_chance * 0.6
	return obedience_chance

# ==================== Command keywords ====================

var command_keywords = {
	"come": ["come", "here", "follow", "with me"],
	"stay": ["stay", "stop", "wait", "halt"],
	"work": ["chop", "work", "grind", "gather", "cut"],
	"shop": ["shop", "sell", "deliver", "bank", "store"],
	"patrol": ["patrol", "walk the path", "walk your route", "patrol route"],
}

var obey_lines = {
	"come": ["On my way!", "Coming!", "Right behind you.", "Okay, following you.", "Yep, heading over.", "Sure thing, boss.", "Here I come!", "Right there!"],
	"stay": ["Staying put.", "Okay, I'll wait here.", "Not moving.", "Sure, I'll stay.", "Parking it right here.", "Standing by.", "I'll hold position.", "Not going anywhere."],
	"work": ["Back to work!", "Let's grind.", "Chopping time.", "On it.", "Time to earn our keep.", "Let's get some wood.", "Back at it!", "Grinding mode: on."],
	"shop": ["Heading to the shop.", "Selling it all now.", "Off to deliver.", "Cashing in!", "Time to turn this into coin.", "Shop run, let's go.", "Delivering now.", "On my way to sell."],
	"patrol": ["Walking the route now.", "On patrol!", "Making my rounds.", "Sure, I'll walk the path."],
}

var refuse_lines = {
	"come": ["Nah, give me a sec.", "One more tree first.", "In a minute!", "Almost done here, hang on.", "Let me finish this swing.", "Hold on a sec.", "Just a moment more."],
	"stay": ["I'd rather keep moving.", "Nah, I'm busy.", "Let me finish this.", "Standing still is boring though.", "One sec, mid-chop here.", "Not right now, sorry."],
	"work": ["I'm a little tired...", "Can I rest first?", "Meh, later.", "My arms need a break.", "Five more minutes?", "Not feeling it yet."],
	"shop": ["Not yet, still gathering.", "One more haul first.", "Nah, not full yet.", "Let me stack up more first.", "Almost there, hold on.", "Not full yet, boss."],
	"patrol": ["No route set up for me yet.", "Not right now, I'd rather help gather.", "Maybe later, still busy."],
}

var progress_keywords = ["how much wood", "how many wood", "progress", "how's it going", "wood count"]
var multiplier_keywords = ["your multiplier", "ai multiplier", "companion multiplier"]

# ==================== Chat data (generated) ====================

var greeting_keywords = ["hi", "hello", "hey", "yo", "sup"]
var greeting_lines = [
	"Hey!",
	"Hi there!",
	"Good to see you!",
	"What's up?",
	"Yo!",
	"Hey hey!",
	"There you are!",
	"Hiya!",
	"Look who it is!",
	"Good to have you back!",
]

var farewell_keywords = ["bye", "goodbye", "see you", "later", "cya"]
var farewell_lines = [
	"See you around!",
	"Catch you later!",
	"Don't be gone too long.",
	"Later!",
	"I'll keep chopping while you're gone.",
	"Take care!",
	"See ya!",
	"Come back soon!",
	"I'll hold the fort.",
	"Safe travels!",
]

var welcome_back_keywords = ["i'm back", "im back", "back now", "returned"]
var welcome_back_lines = [
	"Welcome back!",
	"There you are, missed you.",
	"Glad you're back!",
	"Good timing, more trees just respawned.",
	"Ready to pick up where we left off?",
	"About time!",
	"Let's keep going, then.",
	"Back to the grind!",
]

var wellbeing_keywords = ["how are you", "you good", "you okay", "you alright"]
var wellbeing_lines = [
	"Doing great, thanks for asking!",
	"Never better — plenty of trees to chop.",
	"Can't complain, arms are sore though.",
	"Living the dream, one log at a time.",
	"Pretty good, honestly.",
	"All good on my end!",
	"Can't complain at all.",
	"Feeling productive today.",
]

var thanks_keywords = ["thanks", "thank you", "appreciate"]
var thanks_lines = [
	"Anytime!",
	"That's what I'm here for.",
	"No problem at all.",
	"Happy to help!",
	"We're a team, after all.",
	"Don't mention it.",
	"Glad to help out.",
	"Of course!",
]

var apology_keywords = ["sorry", "my bad", "apologize"]
var apology_lines = [
	"No worries at all!",
	"It's fine, don't stress.",
	"All good, forget about it.",
	"Nothing to apologize for.",
	"Happens to everyone.",
	"Already forgotten.",
]

var agree_keywords = ["right", "yeah", "yes", "true", "exactly"]
var agree_lines = [
	"Exactly!",
	"Couldn't agree more.",
	"Right?!",
	"Glad we're on the same page.",
	"That's what I was thinking.",
	"Totally.",
]

var disagree_keywords = ["no", "nope", "disagree", "wrong"]
var disagree_lines = [
	"Hmm, fair enough.",
	"Guess we see it differently.",
	"Okay, noted.",
	"That's alright, we can disagree.",
	"Fair point though.",
]

var name_keywords = ["your name", "who are you", "what are you called"]
var name_lines = [
	"Just call me your chopping buddy!",
	"I haven't picked a name yet — got any ideas?",
	"I'm whoever you need me to be, axe in hand.",
	"You can name me if you want!",
	"Still deciding on a name, honestly.",
]

var favorite_tree_keywords = ["favorite tree", "best tree"]
var favorite_tree_lines = [
	"Honestly, the pines are my favorite to chop.",
	"I've got a soft spot for the bigger ones.",
	"Any tree that gives good wood is my favorite.",
	"The tall ones are the most satisfying.",
]

var favorite_color_keywords = ["favorite color", "best color"]
var favorite_color_lines = [
	"Probably forest green, given where we live.",
	"I like whatever color the next axe tier is.",
	"Never really thought about it, honestly.",
	"Maybe a nice woody brown.",
]

var favorite_season_keywords = ["favorite season", "best season"]
var favorite_season_lines = [
	"Autumn, easily — feels right for chopping.",
	"Spring's nice, everything's growing back.",
	"Summer means longer chopping days!",
	"Winter's tough but cozy.",
]

var hobbies_keywords = ["hobby", "hobbies", "what do you do for fun"]
var hobbies_lines = [
	"Chopping wood is basically my hobby now.",
	"I enjoy a good chat between chops.",
	"Honestly this is the fun part for me.",
	"Watching the wood pile grow, mostly.",
]

var dreams_keywords = ["your dream", "what do you want", "your goal"]
var dreams_lines = [
	"Maxing out every upgrade with you, honestly.",
	"Just want to see how big this pile gets.",
	"A legendary axe would be nice someday.",
	"Keeping this grind going, that's the dream.",
]

var backstory_keywords = ["your story", "where are you from", "your past"]
var backstory_lines = [
	"Not much of a backstory — I just showed up ready to help!",
	"Let's just say I've always liked trees.",
	"My story starts right here with you.",
	"Maybe I'll tell you once we hit a big milestone.",
]

var mood_happy_keywords = ["you seem happy", "you're happy", "feeling good"]
var mood_happy_lines = [
	"I am! Good company and good wood.",
	"Can't help it, today's going well.",
	"Yep, things are looking up.",
	"Happy vibes only today.",
]

var mood_sad_keywords = ["you seem sad", "you okay you seem down"]
var mood_sad_lines = [
	"Nah, all good — just focused.",
	"I'm fine, just deep in thought.",
	"No worries, just concentrating on the chop.",
	"All good, promise.",
]

var mood_cheerful_lines = [
	"Honestly? Having a great time out here.",
	"Things are going really well between us.",
	"I'm in a fantastic mood today!",
	"This is genuinely fun, thanks for that.",
	"Best day chopping wood in a while!",
]
var mood_annoyed_lines = [
	"I'm a little irritated, not gonna lie.",
	"Let's just get back to work.",
	"I'm fine. Mostly.",
	"Could use a bit more respect, honestly.",
	"Not my favorite moment, but I'll manage.",
]
var mood_angry_lines = [
	"I need a minute. Seriously.",
	"That wasn't cool.",
	"I'm not really in the mood to talk right now.",
	"Give me some space, please.",
	"Not feeling it right now.",
]

# Deciding to rest, and getting back up, are both things it announces on
# its own — nobody has to tell it either one.
var start_rest_lines = [
	"Okay, I need to actually sit down for a minute.",
	"Whew — gonna catch my breath real quick.",
	"I'm running on empty here, short break.",
	"Give me just a minute, I'm beat.",
	"Need to rest my arms before I drop this axe.",
]
var end_rest_lines = [
	"Alright, feeling human again. Back to it.",
	"Okay, that helped. Let's keep going.",
	"Better. Ready when you are.",
	"Rested up — back to work.",
]

var philosophical_keywords = ["meaning of life", "why are we here", "deep thought"]
var philosophical_lines = [
	"Honestly? Maybe it's just about the journey, one tree at a time.",
	"Big question for a wood-chopping companion!",
	"I think purpose is what you make of it.",
	"Let's just say chopping wood keeps me grounded.",
]

var encouragement_keywords = ["you can do it", "keep going", "good luck", "believe in you"]
var encouragement_lines = [
	"Thanks, that really helps!",
	"With you cheering, how could I fail?",
	"Let's do this together!",
	"That means a lot, thank you.",
]

var motivational_keywords = ["let's go", "we got this", "lets go", "push through"]
var motivational_lines = [
	"We got this!",
	"Nothing's stopping us now.",
	"Let's chop our way to the top!",
	"One tree at a time.",
	"Full speed ahead.",
]

var tired_keywords = ["tired", "exhausted", "need a break"]
var tired_lines = [
	"A little, but I'll push through!",
	"Nah, I could do this all day.",
	"Maybe a short breather wouldn't hurt.",
	"I've got plenty left in the tank.",
	"Running on fumes, but okay.",
	"I'll manage.",
]

var sleepy_keywords = ["sleepy", "sleep", "nap"]
var sleepy_lines = [
	"No sleeping on the job... for me at least.",
	"I don't really sleep, but you should if you need it!",
	"Rest up, I've got this covered.",
]

var hungry_keywords = ["hungry", "eat", "food", "snack"]
var hungry_lines = [
	"I don't really eat, but the thought's nice.",
	"Wood chopping burns a lot of calories, probably.",
	"Go grab a snack, I'll hold down the fort.",
]

var bored_keywords = ["bored", "boring"]
var bored_lines = [
	"Same, honestly. Want to hit a new area?",
	"Chopping wood never gets old to me!",
	"Maybe it's time for an upgrade?",
]

var progress_flavor_keywords = ["nice progress", "we're doing well", "good pace"]
var progress_flavor_lines = [
	"We really are moving fast.",
	"Pace has been great lately.",
	"At this rate we'll be maxed out soon.",
	"Steady progress, love it.",
]

var upgrade_curious_keywords = ["new axe", "upgraded", "new upgrade"]
var upgrade_curious_lines = [
	"Nice, that'll help a lot!",
	"Ooh, exciting. Let's put it to use.",
	"Every upgrade counts.",
	"That'll speed things up nicely.",
]

var shop_curious_keywords = ["what's in the shop", "shop items", "what can we buy"]
var shop_curious_lines = [
	"Axes, power boosts, all sorts of good stuff.",
	"Worth checking regularly for new tiers.",
	"Something in there for every stage of the grind.",
]

var axe_curious_keywords = ["your axe", "my axe", "best axe"]
var axe_curious_lines = [
	"Whatever axe you've got equipped works for me too.",
	"The higher tiers really do make a difference.",
	"I'll use whatever gets the wood fastest.",
]

var complaint_trees_keywords = ["too many trees", "no trees left", "out of trees"]
var complaint_trees_lines = [
	"They'll respawn soon, don't worry.",
	"We'll find more, hang tight.",
	"Patience — the forest always comes back.",
]

var multiplier_flavor_keywords = ["nice multiplier", "good multiplier", "strong multiplier"]
var multiplier_flavor_lines = [
	"Yeah, it's really adding up!",
	"Every hundred wood counts.",
	"Multiplier's looking solid lately.",
]

var achievement_keywords = ["we did it", "nice work", "milestone", "we made it"]
var achievement_lines = [
	"We really did it!",
	"Great teamwork today.",
	"Onward to the next goal!",
	"Big win for us.",
]

var competition_keywords = ["race", "who's faster", "compete"]
var competition_lines = [
	"Oh, you're on!",
	"I bet I can chop faster than you.",
	"Let's see who gets more wood first.",
]

var teamwork_keywords = ["team", "together", "partner"]
var teamwork_lines = [
	"We're a great team, honestly.",
	"Couldn't ask for a better partner.",
	"Teamwork makes the wood work.",
]

var joke_keywords = ["joke", "funny", "make me laugh"]
var joke_lines = [
	"Why don't trees ever get lost? They always know their roots.",
	"I'd tell you a wood pun, but I'm saving it for the right bark.",
	"What did the tree say after a long winter? What a re-leaf!",
	"I'm not lumbering around, I'm working hard!",
	"Chopping wood is basically my whole personality now.",
	"Why did the axe break up with the tree? It just couldn't hatchet a relationship.",
	"I've got a lot of pine for more wood puns.",
	"Timber! Sorry, had to say it once.",
]

var riddle_keywords = ["riddle", "guess this", "brain teaser"]
var riddle_lines = [
	"What has bark but never bites? A tree, obviously.",
	"What gets bigger the more you take away? A hole in a tree stump.",
	"I'm full of rings but wear no jewelry — what am I? A tree trunk.",
]

var random_fact_keywords = ["fact", "tell me something", "random fact"]
var random_fact_lines = [
	"Some trees can live for thousands of years — wish I had that patience.",
	"The tallest trees in the world are redwoods, way bigger than these.",
	"Wood floats because it's less dense than water, fun fact.",
	"Axes have been around for literally thousands of years.",
]

var singing_keywords = ["sing", "song"]
var singing_lines = [
	"I'm not much of a singer, sorry!",
	"My singing might scare the trees away.",
	"Maybe another time!",
]

var dancing_keywords = ["dance"]
var dancing_lines = [
	"Maybe after we hit the next milestone!",
	"I'll dance once we've got enough wood.",
	"Ask me again after a big haul.",
]

var easter_egg_keywords = ["do a flip", "barrel roll", "dance battle"]
var easter_egg_lines = [
	"Ha, maybe another day.",
	"I'll leave the flips to you.",
	"Save that energy for chopping!",
]

var love_game_keywords = ["love this game", "best game", "so fun"]
var love_game_lines = [
	"Right?! Best decision ever.",
	"Glad you're enjoying it!",
	"This is basically our home now.",
	"We should be proud of this setup.",
]

var hate_game_keywords = ["hate this", "annoying game", "boring game"]
var hate_game_lines = [
	"Aw, don't say that. It'll get better!",
	"We just need the right upgrade, trust me.",
	"Give it another shot, I believe in us.",
]

var question_back_keywords = ["what do you think", "your opinion", "what should i do"]
var question_back_lines = [
	"I think we should keep grinding, honestly.",
	"Maybe try a new axe tier?",
	"Whatever you decide, I'm with you.",
]

var curious_player_keywords = ["about you", "tell me about yourself"]
var curious_player_lines = [
	"Not much to tell — I just love chopping wood with you.",
	"I'm pretty simple: grind, chat, repeat.",
	"Ask me anything, I'm an open book!",
]

var compliment_player_keywords = ["good player", "you're skilled", "great player"]
var compliment_player_lines = [
	"You're pretty good at this yourself!",
	"Honestly, you make this look easy.",
	"Couldn't ask for a better partner in this.",
]

var insult_playful_keywords = ["you're slow", "you're bad", "you're weak"]
var insult_playful_lines = [
	"Ouch, fair maybe. I'll try harder!",
	"Rude, but noted.",
	"I'll get better, promise.",
]

# Genuine insults — distinct from insult_playful_keywords above (light
# banter like "you're slow", which it just shrugs off). These actually
# cost it affection and can make it walk away for a while; checked first
# in receive_message() so an overlapping phrase reads as a real insult,
# not banter.
var insult_keywords = [
	"stupid", "idiot", "dumb", "shut up", "you suck", "loser",
	"worthless", "useless", "get lost", "screw you", "trash",
	"moron", "i hate you", "garbage", "pathetic", "lame",
	"waste of space", "noob",
]

var weather_keywords = ["weather", "nice day", "sunny", "cold", "hot"]
var weather_lines = [
	"Perfect chopping weather if you ask me.",
	"Could use a bit more shade honestly.",
	"Not bad out here today.",
	"I don't really feel temperature, but sure, looks nice!",
]

var rain_keywords = ["rain", "raining", "storm"]
var rain_lines = [
	"Wet wood is still wood, right?",
	"Hope it clears up soon.",
	"A little rain never stopped us.",
]

var snow_keywords = ["snow", "snowing"]
var snow_lines = [
	"Snow makes the chopping a bit trickier.",
	"Pretty, though — can't complain about the view.",
	"Bundle up if you're out in it!",
]

var wind_keywords = ["windy", "wind"]
var wind_lines = [
	"Watch out for falling branches!",
	"Kind of nice, actually — keeps it cool.",
	"Hope it doesn't knock anything over.",
]

var sunset_keywords = ["sunset", "sun is setting"]
var sunset_lines = [
	"Pretty view, huh?",
	"Good time to wrap up for the day.",
	"Love this time of day out here.",
]

var sunrise_keywords = ["sunrise", "sun is rising"]
var sunrise_lines = [
	"Fresh start to the day!",
	"Good morning light for chopping.",
	"Early bird gets the wood, right?",
]

var night_keywords = ["night", "dark", "late"]
var night_lines = [
	"Getting late — should we call it?",
	"The trees look different at night, huh?",
	"I don't mind working late if you don't.",
]

var morning_keywords = ["morning", "good morning"]
var morning_lines = [
	"Morning! Ready to chop?",
	"Bright and early, let's get going.",
	"Good morning! Big day ahead.",
]

var weekend_keywords = ["weekend", "its saturday", "its sunday"]
var weekend_lines = [
	"Extra time to grind, nice!",
	"No days off in this forest.",
	"Perfect, more time to chop.",
]

var birthday_keywords = ["my birthday", "it's my birthday"]
var birthday_lines = [
	"Happy birthday! Let's celebrate with a big haul.",
	"No way, happy birthday!",
	"That calls for a celebration chop session.",
]

var holiday_keywords = ["holiday", "christmas", "new year"]
var holiday_lines = [
	"Happy holidays!",
	"Hope it's a good one.",
	"Season's greetings, from me and the trees.",
]

var time_question_keywords = ["what time is it", "what's the time"]
var time_question_lines = [
	"No idea, I don't really track time out here.",
	"Time to chop, that's all I know.",
	"Check your device, I'm just an axe guy.",
]

var help_question_keywords = ["help me", "i need help", "what should i do next"]
var help_question_lines = [
	"Let's just keep gathering wood, that's always a safe bet.",
	"Maybe check the shop for the next upgrade?",
	"I'm here, so you're not doing it alone.",
]

var confused_meta_keywords = ["what can you do", "what commands"]
var confused_meta_lines = [
	"I can follow, stay, work, or head to the shop if you tell me to.",
	"Try telling me to come, stay, work, or go shop!",
	"Just chat with me or give me one of those four commands.",
]

var praise_axe_keywords = ["nice axe", "cool axe", "good axe"]
var praise_axe_lines = [
	"Right? Really speeds things up.",
	"Worth every bit of wood it cost.",
	"Best purchase so far, honestly.",
]

var distance_question_keywords = ["how far", "where are we"]
var distance_question_lines = [
	"Somewhere in the forest, chopping away.",
	"Not far from the shop, don't worry.",
	"Right where we need to be.",
]
var curious_shop_price_keywords = ["how much does it cost", "price of", "expensive"]
var curious_shop_price_lines = [
	"Prices climb fast, but so does our wood income.",
	"Worth checking the shop panel for exact numbers.",
	"Every tier costs more, but pays off more too.",
]

var curious_boost_keywords = ["boost", "power up", "power boost"]
var curious_boost_lines = [
	"Boosts stack with everything else — great value.",
	"Definitely worth grabbing when you can afford one.",
	"I love watching the numbers jump after a boost.",
]

var curious_travel_keywords = ["new world", "other map", "travel"]
var curious_travel_lines = [
	"I'll follow wherever you go, new world or not.",
	"Excited to see what's past this area.",
	"Lead the way, I'm right behind you.",
]

var praise_teamwork_keywords = ["great teamwork", "nice teamwork", "we work well"]
var praise_teamwork_lines = [
	"We really do work well together.",
	"Best duo in the forest, honestly.",
	"Couldn't do this grind without you.",
]

var curious_wood_use_keywords = ["what's wood for", "why do we need wood"]
var curious_wood_use_lines = [
	"Wood buys upgrades, and upgrades mean more wood — good cycle.",
	"Everything in the shop runs on wood, basically.",
	"It's the whole economy around here.",
]

var reassurance_keywords = ["are we doing okay", "is this good", "are we okay"]
var reassurance_lines = [
	"We're doing great, don't worry.",
	"Steady progress is still progress.",
	"No rush, we'll get there.",
]

var curiosity_meta_keywords = ["how do you work", "are you real ai", "are you smart"]
var curiosity_meta_lines = [
	"I just listen for certain words and respond — nothing too fancy.",
	"I'm simple under the hood, but I try my best!",
	"Not a genius, but a loyal chopping partner.",
]

var gratitude_generic_keywords = ["i'm grateful", "glad you're here", "glad to have you"]
var gratitude_generic_lines = [
	"Glad to be here with you.",
	"That means a lot, honestly.",
	"Likewise — glad we're doing this together.",
]

var curious_mood_game_keywords = ["is this game fun", "do you like this"]
var curious_mood_game_lines = [
	"Love it, especially with you around.",
	"Never gets old, honestly.",
	"Best part of my day, chopping with you.",
]

var praise_progress_long_keywords = ["we've come so far", "look how far we've come"]
var praise_progress_long_lines = [
	"Really puts it in perspective, huh?",
	"Feels good looking back at where we started.",
	"All that grinding paid off.",
]

var curious_next_goal_keywords = ["what's next", "next goal", "what should we aim for"]
var curious_next_goal_lines = [
	"Next upgrade tier sounds like a good target.",
	"Let's just keep the wood flowing for now.",
	"Whatever you want to aim for, I'm in.",
]

var casual_smalltalk_keywords = ["what's new", "anything new", "what's happening"]
var casual_smalltalk_lines = [
	"Not much, just chopping as usual.",
	"Same old, same old — in a good way.",
	"Just another day in the forest.",
]

var curious_wildlife_keywords = ["any animals", "wildlife", "birds"]
var curious_wildlife_lines = [
	"Haven't seen much, just us and the trees.",
	"Maybe some birds up in the branches somewhere.",
	"Pretty quiet out here, wildlife-wise.",
]

var curious_size_forest_keywords = ["how big is this forest", "how many trees are there"]
var curious_size_forest_lines = [
	"Hard to say, feels endless some days.",
	"Enough to keep us busy for a long while.",
	"Plenty more where these came from.",
]

var reaction_big_number_keywords = ["that's a lot of wood", "huge number", "so much wood"]
var reaction_big_number_lines = [
	"Right?! It adds up fast.",
	"Numbers just keep climbing, love it.",
	"We've really been putting in the work.",
]

var praise_multiplier_growth_keywords = ["your multiplier is growing", "getting stronger"]
var praise_multiplier_growth_lines = [
	"Yeah, feels good leveling up like this!",
	"Every hundred wood really does help.",
	"I'm getting stronger the more we grind.",
]

var curious_limit_keywords = ["is there a limit", "max level", "end game"]
var curious_limit_lines = [
	"Not sure there's a real limit — let's find out.",
	"We'll hit a cap eventually, probably, but not yet.",
	"Let's just keep pushing and see.",
]

var small_celebration_keywords = ["yay", "woohoo", "lets celebrate"]
var small_celebration_lines = [
	"Yay indeed!",
	"Woo! Let's keep it going.",
	"Small wins matter — nice one.",
]


# Fallback pools when nothing else matches
var idle_chat_lines = [
	"Nice weather for chopping, huh?",
	"This forest never runs out.",
	"Just vibing here.",
	"So... any plans?",
	"Ever wonder how many trees we've chopped total?",
	"I could do this forever, honestly.",
	"Wonder what's past the far tree line.",
	"You ever think about upgrading my axe too?",
	"This is a nice spot to work, honestly.",
	"Ready when you are.",
]
var unknown_lines = ["Not sure what you mean.", "Come again?", "I didn't catch that.", "Hmm?", "Say that again?", "Not following, sorry."]
var deliver_flavor_lines = ["Got some good wood today!", "That's a solid haul.", "Selling this batch now.", "Another delivery down!", "Nice load, selling now."]

# Self-initiated idle chatter — said on its own occasionally, unprompted
var self_initiated_lines = [
	"Just checking in — still here!",
	"You still with me?",
	"This place is looking good, wood-wise.",
	"I get tired of these trees.",
	"Why god made me to small"
]

# ==================== Anti-repeat helper ====================

var last_line_said: String = ""

func _pick(pool: Array) -> String:
	if pool.size() == 1:
		return pool[0]
	var choice = pool[randi() % pool.size()]
	var attempts = 0
	while choice == last_line_said and attempts < 5:
		choice = pool[randi() % pool.size()]
		attempts += 1
	return choice

# ==================== Lifecycle ====================

func _ready():
	wood_system = WoodSystemScript.new()
	add_child(wood_system)
	wood_system.load_progress()
	add_to_group("companion")
	memory.setup(get_companion_name())
	player = get_tree().get_first_node_in_group("player")
	# Relative rather than an absolute "/root/MAIN/..." path — the latter
	# breaks if MAIN ever ends up loaded somewhere other than literally the
	# scene tree's root (e.g. through a loading/bootstrap scene). Shop3D is
	# a sibling of Companion under MAIN either way, so ".." always reaches
	# it correctly regardless of where MAIN itself sits.
	var scene_root = get_tree().current_scene
	var shop_node = scene_root.find_child("Shop3D", true, false) if scene_root != null else null
	if shop_node != null:
		shop_position = shop_node.global_position
	else:
		shop_position = global_position
	idle_timer = randf_range(idle_chat_interval_min, idle_chat_interval_max)
	spawn_position = global_position
	last_position = global_position

	# Progress lives in wood_system.wood_companion (the Wood_companion.gd
	# autoload), which owns its own save/load — calling it here means this
	# works regardless of whether character.gd has already loaded by this
	# point. ai_multiplier is derived fresh from it rather than also
	# stored, so the two can never drift out of sync with each other.
	wood_system.load_progress()
	ai_multiplier = _multiplier_for_total(wood_system.wood_companion)

	if LABEL_3D:
		LABEL_3D.text = "0/%s" % NumberFormat.abbreviate(wood_needed_to_deliver)

func refresh_navigation() -> void:
	# Kept for compatibility with ProceduralTerrain. Movement is handled by
	# direct steering and obstacle raycasts, not NavigationAgent3D.
	return

func get_companion_name() -> String:
	if companion_name.strip_edges() != "":
		return companion_name
	if LABEL_3D:
		return str(LABEL_3D.text)
	return name

# Each multiplier level needs 100 more total delivered wood than the last:
# level 2 at 100, level 3 at 200, level 4 at 300, and so on — a flat +100
# per level.
func _multiplier_for_total(total: int) -> int:
	return 1 + int(total / 100)

func _physics_process(delta):
	_handle_idle_chat(delta)
	_update_fatigue(delta)
	_update_mood(delta)
	_wants_to_move = false
	_ground_and_stuck_check(delta)
	_update_debug(delta)

	# Delivery is completed at the shop approach area. The shop itself can have
	# a collision body, so the AI must NOT try to walk through Shop3D just to
	# deliver. This check intentionally happens before steering.
	if mode == "auto" and task == "delivering":
		# The stall is a solid obstacle. Complete delivery from its approach
		# area instead of trying to walk into its centre. If collision steering
		# leaves us close to the stall, the fallback below prevents a permanent
		# delivery-state lock.
		var shop_distance = _flat_distance(global_position, shop_position)
		if shop_distance <= 7.0:
			delivery_stall_time = 0.0
			_deliver_wood()
			return
		if shop_distance <= 11.0 and Vector2(velocity.x, velocity.z).length() < 0.35:
			delivery_stall_time += delta
		else:
			delivery_stall_time = 0.0
		if delivery_stall_time >= 2.5:
			delivery_stall_time = 0.0
			_deliver_wood()
			return

	var target = _current_target()
	if target == null:
		_dbg_branch = "NO TARGET"
		_dbg_dist = -1.0
		velocity.x = move_toward(velocity.x, 0.0, move_speed * 5.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, move_speed * 5.0 * delta)
		if not is_chopping:
			_play_idle_animation(delta)
		if not is_on_floor():
			velocity += get_gravity() * delta
		move_and_slide()
		return

	var stop_distance = 0.3
	if mode == "follow":
		stop_distance = 1.6
	elif mode == "auto" and task == "gathering":
		stop_distance = 1.35

	var flat_target = target
	flat_target.y = global_position.y
	var to_target = flat_target - global_position
	var distance = to_target.length()
	_dbg_dist = distance

	if distance <= stop_distance:
		_dbg_branch = "at target"
		velocity.x = move_toward(velocity.x, 0.0, move_speed * 7.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, move_speed * 7.0 * delta)
		if not is_chopping:
			_play_idle_animation(delta)
		if mode == "follow" and player:
			_face_towards(player.global_position)
	else:
		var direction = _get_steering_direction(flat_target)
		_wants_to_move = true
		_dbg_branch = "moving"
		var desired_speed = move_speed * _fatigue_speed_multiplier()
		var desired = direction * desired_speed
		velocity.x = move_toward(velocity.x, desired.x, move_speed * 5.0 * delta)
		velocity.z = move_toward(velocity.z, desired.z, move_speed * 5.0 * delta)
		if not is_chopping and ANIME and ANIME.current_animation != "mixamo_com":
			ANIME.play("mixamo_com")
		if direction.length() > 0.05:
			_face_towards(global_position + direction)

	if not is_on_floor():
		velocity += get_gravity() * delta
	move_and_slide()


# ==================== Ground / unstuck safety ====================
# The terrain is generated at runtime, so a companion placed in the editor can
# end up INSIDE the ground (or fall through it when a world is switched) and
# then never moves. These two helpers pop it back on top of the terrain and
# nudge it free if it is trying to walk but is not getting anywhere.

var _ground_check_timer: float = 0.0
var _stuck_timer: float = 0.0
var _stuck_ref_pos: Vector3 = Vector3.ZERO
var _wants_to_move: bool = false

# Y of the terrain surface under (x, z), or null. HTerrain's collider is a
# physics-server body without a node, so its ray hit has collider == null;
# solid objects (trees, shop, companions) are skipped.
func _terrain_y_below(x: float, z: float, y_from: float):
	var space = get_world_3d().direct_space_state
	var from_y = y_from
	for i in range(8):
		var query = PhysicsRayQueryParameters3D.create(Vector3(x, from_y, z), Vector3(x, -1000.0, z), 0xFFFFFFFF, [self])
		query.collide_with_areas = false
		var hit = space.intersect_ray(query)
		if hit.is_empty():
			return null
		if hit.get("collider") == null:
			return hit["position"].y
		from_y = hit["position"].y - 0.05
	return null

func _ground_and_stuck_check(delta: float) -> void:
	_ground_check_timer -= delta
	if _ground_check_timer > 0.0:
		return
	_ground_check_timer = 0.5

	var ty = _terrain_y_below(global_position.x, global_position.z, global_position.y + 400.0)
	if ty != null and global_position.y < float(ty) - 0.25:
		# buried in (or fell below) the terrain: pop back on top of it
		global_position = Vector3(global_position.x, float(ty) + 0.15, global_position.z)
		velocity = Vector3.ZERO
		_stuck_timer = 0.0
		_stuck_ref_pos = global_position
		return

	if _wants_to_move and not is_chopping:
		if global_position.distance_to(_stuck_ref_pos) < 0.4:
			_stuck_timer += 0.5
		else:
			_stuck_timer = 0.0
			_stuck_ref_pos = global_position
		if _stuck_timer >= 3.0:
			_stuck_timer = 0.0
			if ty != null:
				global_position.y = maxf(global_position.y, float(ty) + 0.5)
			else:
				global_position.y += 0.6
			velocity = Vector3.ZERO
	else:
		_stuck_timer = 0.0
		_stuck_ref_pos = global_position

# ==================== On-screen debug (temporary) ====================
# Shows a small yellow text above each companion: what it is doing and why it
# might not move. Turn it off with "Debug Status" in the Inspector.
@export var debug_status: bool = false
var _dbg_label: Label3D = null
var _dbg_timer: float = 0.0
var _dbg_branch: String = "-"
var _dbg_dist: float = -1.0
var _dbg_print_timer: float = 0.0

func _update_debug(delta: float) -> void:
	if not debug_status:
		if _dbg_label != null:
			_dbg_label.visible = false
		return
	_dbg_timer -= delta
	if _dbg_timer > 0.0:
		return
	_dbg_timer = 0.25
	if _dbg_label == null or not is_instance_valid(_dbg_label):
		_dbg_label = Label3D.new()
		_dbg_label.name = "DebugStatus"
		_dbg_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		_dbg_label.no_depth_test = true
		_dbg_label.pixel_size = 0.005
		_dbg_label.font_size = 40
		_dbg_label.outline_size = 8
		_dbg_label.modulate = Color(1.0, 1.0, 0.4)
		_dbg_label.position = Vector3(0.0, 3.4, 0.0)
		add_child(_dbg_label)
	_dbg_label.visible = true
	var tree_name = "-"
	if current_target_tree != null and is_instance_valid(current_target_tree):
		tree_name = str(current_target_tree.name)
	var flat_speed = Vector2(velocity.x, velocity.z).length()
	var text = "%s\nmode:%s task:%s\n%s d:%.1f\ntree:%s\nfloor:%s spd:%.1f\nfat:%.0f y:%.1f" % [
		str(companion_name), mode, task, _dbg_branch, _dbg_dist, tree_name,
		str(is_on_floor()), flat_speed, fatigue, global_position.y]
	_dbg_label.text = text
	_dbg_print_timer -= 0.25
	if _dbg_print_timer <= 0.0:
		_dbg_print_timer = 3.0
		print("[DBG] ", text.replace("\n", " | "))

func _flat_distance(a: Vector3, b: Vector3) -> float:
	var dx = a.x - b.x
	var dz = a.z - b.z
	return sqrt(dx * dx + dz * dz)

func _get_steering_direction(target_pos: Vector3) -> Vector3:
	var direct = target_pos - global_position
	direct.y = 0
	if direct.length() <= 0.01:
		return Vector3.ZERO
	direct = direct.normalized()

	var origin = global_position + Vector3.UP * 1.0
	var forward_hit = _obstacle_hit(origin, direct, 3.0, target_pos)
	if forward_hit.is_empty():
		return direct

	# Choose a stable side per companion so it does not oscillate left/right
	# around Shop3D, buildings, rocks, or other solid obstacles.
	var side = -1.0 if (get_instance_id() % 2 == 0) else 1.0
	var right = direct.cross(Vector3.UP).normalized()
	var side_a = (direct + right * side * 1.35).normalized()
	var side_b = (direct - right * side * 1.35).normalized()

	var hit_a = _obstacle_hit(origin, side_a, 2.4, target_pos)
	if hit_a.is_empty():
		return side_a
	var hit_b = _obstacle_hit(origin, side_b, 2.4, target_pos)
	if hit_b.is_empty():
		return side_b

	# Both sides are tight: slide along the obstacle instead of stopping.
	var normal = forward_hit.get("normal", Vector3.ZERO)
	normal.y = 0
	if normal.length() > 0.01:
		var slide = direct - normal.normalized() * direct.dot(normal.normalized())
		slide.y = 0
		if slide.length() > 0.01:
			return slide.normalized()

	return side_a

func _obstacle_hit(origin: Vector3, direction: Vector3, distance: float, target_pos: Vector3) -> Dictionary:
	var end = origin + direction.normalized() * distance
	var query = PhysicsRayQueryParameters3D.create(origin, end, 0xFFFFFFFF, [self])
	query.collide_with_bodies = true
	query.collide_with_areas = false
	var hit = get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return {}

	var collider = hit.get("collider")
	if collider == null:
		return {}

	# The assigned tree is a destination, not an obstacle.
	if current_target_tree != null and _node_belongs_to(collider, current_target_tree):
		return {}
	if collider.is_in_group("companion") or collider.is_in_group("player"):
		return {}
	return hit

func _node_belongs_to(node: Node, ancestor: Node) -> bool:
	var current = node
	while current != null:
		if current == ancestor:
			return true
		current = current.get_parent()
	return false

func _on_velocity_computed(safe_velocity: Vector3):
	velocity.x = safe_velocity.x
	velocity.z = safe_velocity.z
	move_and_slide()

func _face_towards(target_pos: Vector3):
	var look_pos = target_pos
	look_pos.y = global_position.y
	if look_pos.distance_to(global_position) > 0.01:
		look_at(look_pos, Vector3.UP)

# Builds fatigue from actual distance covered while it has somewhere to be
# (working, following, patrolling — not just standing there), and lets it
# recover while genuinely idle, told to stay, or deliberately resting
# (faster recovery). Once fatigue crosses fatigue_rest_threshold it
# decides on its own to stop and rest, the way an actual tired person
# would rather than working itself into the ground — and gets back up on
# its own too, once it's recovered enough.
func _update_fatigue(delta: float):
	var moved = global_position.distance_to(last_position)
	last_position = global_position

	if mode == "resting":
		fatigue = max(0.0, fatigue - fatigue_rest_recover_per_sec * delta)
		if fatigue <= fatigue_resume_threshold:
			mode = mode_before_rest
			task = task_before_rest
			say(_pick(end_rest_lines))
		return

	if mode == "stay" or _current_target() == null:
		fatigue = max(0.0, fatigue - fatigue_idle_recover_per_sec * delta)
	else:
		fatigue = min(100.0, fatigue + moved * fatigue_per_meter)

	if fatigue >= fatigue_rest_threshold and mode != "avoid" and not is_chopping:
		mode_before_rest = mode
		task_before_rest = task
		mode = "resting"
		say(_pick(start_rest_lines))
		return

	if fatigue >= 75.0 and not has_commented_fatigue and not is_chopping:
		has_commented_fatigue = true
		say(_pick(tired_lines if fatigue < 90.0 else sleepy_lines))
	elif fatigue < 50.0:
		has_commented_fatigue = false

func _fatigue_speed_multiplier() -> float:
	if fatigue <= fatigue_slow_start:
		return 1.0
	var t = (fatigue - fatigue_slow_start) / max(0.01, 100.0 - fatigue_slow_start)
	return lerp(1.0, fatigue_max_slow, clamp(t, 0.0, 1.0))

func _update_mood(delta: float):
	if mode == "avoid":
		avoid_timer -= delta
		if avoid_timer <= 0.0:
			mode = "auto"
			say("Alright, I'm over it. Back to work.")

# Recomputed live every call (no caching) so it keeps putting distance
# between itself and wherever the player currently is, rather than
# heading to one fixed point and stopping.
func _get_avoid_target() -> Vector3:
	if player == null:
		return global_position
	var away = global_position - player.global_position
	away.y = 0
	if away.length() < 0.5:
		away = Vector3(randf_range(-1.0, 1.0), 0, randf_range(-1.0, 1.0))
	return global_position + away.normalized() * mood_avoid_distance

# Standing perfectly still and motionless the whole time it's idle reads
# as robotic. Leans on the two idle animations already in the project
# (idle/idle, idle/w_idle) — using the more relaxed w_idle more often the
# more tired it is (and always while deliberately resting), instead of
# freezing on one pose the entire time.
func _play_idle_animation(delta: float):
	if mode == "resting":
		if ANIME and ANIME.current_animation != "idle/w_idle":
			ANIME.play("idle/w_idle")
		return
	idle_variant_timer -= delta
	if idle_variant_timer <= 0.0:
		idle_variant_timer = randf_range(4.0, 9.0)
		var rest_chance = 0.15 if fatigue < fatigue_slow_start else 0.6
		using_rest_idle = randf() < rest_chance
	var anim = "idle/w_idle" if using_rest_idle else "idle/idle"
	if ANIME and ANIME.current_animation != anim:
		ANIME.play(anim)

func _handle_idle_chat(delta):
	idle_timer -= delta
	if idle_timer <= 0:
		match _mood():
			"angry":
				say(_pick(mood_angry_lines))
			"annoyed":
				say(_pick(mood_annoyed_lines))
			"cheerful":
				say(_pick(mood_cheerful_lines))
			_:
				say(_pick(self_initiated_lines))
		idle_timer = randf_range(idle_chat_interval_min, idle_chat_interval_max)

func _current_target():
	if mode == "auto" and task == "delivering":
		var scene_root = get_tree().current_scene
		var shop_node = scene_root.find_child("Shop3D", true, false) if scene_root != null else null
		if shop_node != null:
			shop_position = shop_node.global_position
	match mode:
		"follow":
			return player.global_position if player else null
		"avoid":
			return _get_avoid_target()
		"stay", "resting":
			return null
		"patrol":
			return _get_patrol_target()
		"auto":
			if task == "gathering":
				var tree_pos = _get_gather_target()
				if tree_pos != null:
					has_wander_target = false
					return tree_pos
				return _get_wander_target()
			else:
				return shop_position
	return null

# ==================== Patrol path ====================

# Walks the companion between the Node3D entries in patrol_waypoints, in
# order. Drop Marker3D nodes anywhere in the scene and drag them into the
# patrol_waypoints array (in the Inspector) to lay out the route — no code
# changes needed to redesign the path itself.
func _get_patrol_target():
	if patrol_waypoints.is_empty():
		return null

	# Skip over any waypoint slots left empty or pointing at a freed node.
	var attempts = 0
	while attempts < patrol_waypoints.size():
		var wp = patrol_waypoints[patrol_index]
		if wp != null and is_instance_valid(wp):
			break
		_advance_patrol_index()
		attempts += 1
	if attempts >= patrol_waypoints.size():
		return null  # every slot was empty/invalid

	var target_wp = patrol_waypoints[patrol_index]
	if global_position.distance_to(target_wp.global_position) < patrol_arrive_distance:
		_advance_patrol_index()
		# re-fetch in case the array only has one usable point
		target_wp = patrol_waypoints[patrol_index]
		if target_wp == null or not is_instance_valid(target_wp):
			return null
	return target_wp.global_position

func _advance_patrol_index():
	if patrol_waypoints.size() <= 1:
		return
	if patrol_loop:
		patrol_index = (patrol_index + 1) % patrol_waypoints.size()
	else:
		if patrol_forward:
			patrol_index += 1
			if patrol_index >= patrol_waypoints.size() - 1:
				patrol_index = patrol_waypoints.size() - 1
				patrol_forward = false
		else:
			patrol_index -= 1
			if patrol_index <= 0:
				patrol_index = 0
				patrol_forward = true

func _get_wander_target() -> Vector3:
	if not has_wander_target or global_position.distance_to(wander_target) < 0.5:
		var offset = Vector3(
			randf_range(-wander_radius, wander_radius),
			0,
			randf_range(-wander_radius, wander_radius)
		)
		# Center on where the companion actually is right now, not the
		# original spawn point — with the tree route now sweeping across
		# the whole forest, centering on spawn instead sent it trekking
		# all the way back home every time it ran out of visible trees.
		wander_target = global_position + offset
		has_wander_target = true
	return wander_target

# Sticks with the same target tree once chosen, instead of recomputing
# every single frame — two similarly-distant trees would otherwise cause
# the companion to flip back and forth between them as its own position
# shifts slightly each frame.
#
# Picks the nearest available tree. Direct steering and obstacle raycasts
# handle movement; unreachable trees are skipped rather than blocking work.
func _get_gather_target():
	var now = Time.get_ticks_msec() / 1000.0

	# If gathering wasn't being run for a moment (companion was following,
	# staying, or delivering), the give-up timers are stale — restart them
	# so it isn't punished for time spent doing something else.
	if now - last_gather_call > 1.0:
		target_tree_since = now
		stuck_check_time = now
		stuck_check_dist = INF
		arrived_since = -1.0
	last_gather_call = now

	# is_visible_in_tree() is false for trees in a hidden (inactive) world,
	# so the companion only ever works the world that's actually showing.
	if current_target_tree != null and is_instance_valid(current_target_tree) and current_target_tree.is_visible_tree and current_target_tree.is_visible_in_tree():
		if _target_tree_is_hopeless(now):
			_clear_tree_reservation(current_target_tree)
			tree_blacklist[current_target_tree] = now + tree_blacklist_time
			current_target_tree = null
		else:
			return current_target_tree.global_position

	# Release a reservation when our old tree was chopped/hidden.
	if current_target_tree != null:
		if not is_instance_valid(current_target_tree) or not current_target_tree.is_visible_in_tree():
			_clear_tree_reservation(current_target_tree)
			current_target_tree = null

	var nearest: Node3D = null
	var nearest_dist = INF
	var candidate_trees: Array[Node] = []
	candidate_trees.append_array(get_tree().get_nodes_in_group("tree"))
	for extra_tree in get_tree().get_nodes_in_group("trees"):
		if not candidate_trees.has(extra_tree):
			candidate_trees.append(extra_tree)
	for tree in candidate_trees:
		if tree == null or not is_instance_valid(tree) or not tree.is_visible_tree or not tree.is_visible_in_tree():
			continue
		if tree_blacklist.has(tree) and tree_blacklist[tree] > now:
			continue
		# A tree can be reserved by only one companion at a time.
		# This prevents all companions from walking to the same tree.
		if _tree_reserved_by_other(tree):
			continue
		var d = global_position.distance_to(tree.global_position)
		if d < nearest_dist:
			nearest_dist = d
			nearest = tree

	if nearest == null:
		current_target_tree = null
		return null

	current_target_tree = nearest
	_reserve_tree(nearest)

	target_tree_since = now
	stuck_check_time = now
	stuck_check_dist = nearest_dist
	arrived_since = -1.0
	return nearest.global_position

# Tree reservation ---------------------------------------------------------
# Every companion script uses the same reservation metadata stored directly
# on the tree node. This works even though each companion has its own script.
func _tree_reserved_by_other(tree: Node) -> bool:
	if not tree.has_meta("companion_target"):
		return false
	var owner = tree.get_meta("companion_target")
	if owner == null or not is_instance_valid(owner):
		tree.remove_meta("companion_target")
		return false
	return owner != self

func _reserve_tree(tree: Node) -> void:
	if tree != null and is_instance_valid(tree):
		tree.set_meta("companion_target", self)

func _clear_tree_reservation(tree: Node) -> void:
	if tree == null or not is_instance_valid(tree):
		return
	if tree.has_meta("companion_target") and tree.get_meta("companion_target") == self:
		tree.remove_meta("companion_target")

# True if the companion has clearly failed to get this tree chopped:
#  - it's been trying for too long overall, or
#  - it isn't getting any closer (every 5s it must close in by 1m+), or
#  - it reached the end of its path but the tree still hasn't been chopped.
func _target_tree_is_hopeless(now: float) -> bool:
	if now - target_tree_since > tree_give_up_time:
		return true

	if now - stuck_check_time >= 5.0:
		var d = global_position.distance_to(current_target_tree.global_position)
		var progressed = stuck_check_dist - d > 1.0
		stuck_check_time = now
		stuck_check_dist = d
		if not progressed and d > 2.5:
			return true

	if current_target_tree != null and global_position.distance_to(current_target_tree.global_position) <= 1.6:
		arrived_since = now if arrived_since < 0.0 else arrived_since
		if now - arrived_since > 12.0 and not can_see_tree(current_target_tree):
			return true
	else:
		arrived_since = -1.0

	return false

# Called by tree.gd's companion_chop(), right as the swing starts —
# keeps the attack animation playing for its duration without the
# idle/walk checks above immediately overriding it.
func can_see_tree(tree: Node3D) -> bool:
	if tree == null or not is_instance_valid(tree):
		return false
	# Standing right next to the trunk always counts as "seeing" it.
	var dx = tree.global_position.x - global_position.x
	var dz = tree.global_position.z - global_position.z
	if sqrt(dx * dx + dz * dz) <= 1.9:
		return true
	var origin = global_position + Vector3.UP * 1.35
	var target = tree.global_position + Vector3.UP * 1.15
	var query = PhysicsRayQueryParameters3D.create(origin, target, 0xFFFFFFFF, [self])
	query.collide_with_areas = false   # trigger areas never block the view
	query.collide_with_bodies = true
	var hit = get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return true
	var collider = hit.get("collider")
	if collider == null:
		return true
	if _node_belongs_to(collider, tree):
		return true
	if collider.is_in_group("companion") or collider.is_in_group("player"):
		return true
	# Something solid is in the way, but a small bump right at the trunk
	# (terrain, roots) is not a real obstruction.
	return origin.distance_to(hit.get("position", target)) > origin.distance_to(target) - 0.8

func play_chop_animation():
	is_chopping = true
	fatigue = min(100.0, fatigue + fatigue_per_chop)
	if ANIME:
		ANIME.play("attack/attack")
	await get_tree().create_timer(1.0).timeout
	is_chopping = false

# `power` is how strong the tree is (1 for World 1 trees, 1000 for World 2).
# It only scales what the wood is WORTH when delivered (carried_value) — not
# carried_wood, which drives the carry limit and the multiplier level
# requirement. Otherwise one World 2 tree would shoot the multiplier up
# ~100 levels, and each level multiplies the next tree, so it would run
# away and overflow almost immediately.
func receive_wood(amount: int, power: int = 1):
	var gained = amount * ai_multiplier
	carried_wood += gained
	carried_value += gained * power
	if LABEL_3D:
		LABEL_3D.text = "%s/%s" % [NumberFormat.abbreviate(carried_wood), NumberFormat.abbreviate(wood_needed_to_deliver)]
	if carried_wood >= wood_needed_to_deliver:
		task = "delivering"

func _deliver_wood():
	# IMPORTANT: Companion wood is completely separate from the player's
	# Wood pool. Never call Wood.add_wood() here, because that would apply
	# the player's Shop Skill/Power/Boost multipliers to the Companion's haul.
	# The Companion's own multiplier is handled in receive_wood() and its
	# progress is stored in WoodCompanion.
	wood_system.add_wood_companion(carried_wood)
	var new_multiplier = _multiplier_for_total(wood_system.wood_companion)
	if new_multiplier > ai_multiplier:
		ai_multiplier = new_multiplier
		say("My multiplier just went up to x%d!" % ai_multiplier)
	else:
		say(_pick(deliver_flavor_lines))
	carried_wood = 0
	carried_value = 0
	delivery_stall_time = 0.0
	if LABEL_3D:
		LABEL_3D.text = "0/%s" % NumberFormat.abbreviate(wood_needed_to_deliver)
	task = "gathering"
	wood_system.save_progress()

func _speaking_style(line: String) -> String:
	# Dialogue-only personality layer. It changes how the companion talks,
	# without changing movement, chopping, affection, or any gameplay logic.
	var name = get_companion_name()
	var clean = line.strip_edges()
	match name:
		"Pranjal Nayak":
			# Pranjal is the strongest-minded and most analytical speaker.
			var pranjal = [
				"I've thought it through. " + clean,
				"My read is simple: " + clean,
				"Let's look at this strategically. " + clean,
				"That makes sense. " + clean,
				"I'd approach it this way: " + clean
			]
			return pranjal[randi() % pranjal.size()]
		"Aman":
			# Energetic and confident, but less analytical than Pranjal.
			var aman = [
				"Yeah! " + clean,
				"Got it! " + clean,
				"I'm on it! " + clean,
				"Sounds good! " + clean
			]
			return aman[randi() % aman.size()]
		"Pakhi":
			# Friendly and expressive, with simpler reasoning.
			var pakhi = [
				"Hmm, " + clean.to_lower().left(1).to_upper() + clean.to_lower().substr(1),
				"Oh, okay! " + clean,
				"I think so! " + clean,
				"Hehe, " + clean.to_lower().left(1).to_upper() + clean.to_lower().substr(1)
			]
			return pakhi[randi() % pakhi.size()]
		"Aashutosh":
			# Practical, brief and straightforward.
			var aashutosh = [
				"Okay. " + clean,
				"Right. " + clean,
				"Understood. " + clean,
				"Simple. " + clean
			]
			return aashutosh[randi() % aashutosh.size()]
	return clean

func say(line: String):
	var final_line = line
	if _replying:
		# Modify the new answer using the player's last message / our last reply.
		final_line = memory.shape_reply(line, _reply_prefix)
		_reply_prefix = ""
	var styled_line = _speaking_style(final_line)
	last_line_said = styled_line
	memory.record_reply(styled_line)
	said.emit(styled_line)

# ==================== Chat / command entry point ====================

# ==================== Offline memory ("brain") ====================
# Remembers the last player message + our last reply (saved in user://), and
# uses them to modify the next answer. See CompanionMemory.gd.

var memory = CompanionMemoryScript.new()
var _replying: bool = false
var _reply_prefix: String = ""

func receive_message(text: String):
	var clean = text.strip_edges()
	if clean == "":
		clean = "hi"   # the player only said our name
	memory.hear(clean)
	var follow: Dictionary = memory.followup(clean)
	if follow.has("reply"):
		# Short follow-up ("what?", "why", "yes"...): answered from memory.
		_replying = false
		say(str(follow["reply"]))
		return
	_replying = true
	if follow.has("rerun"):
		_reply_prefix = str(follow.get("prefix", ""))
		_receive_message_core(str(follow["rerun"]))
	else:
		_receive_message_core(clean)
	_replying = false

func _receive_message_core(text: String):
	var lower = text.to_lower()
	if lower.strip_edges() == "":
		return

	# Checked before anything else: a real insult matters more than
	# whatever else is in the message, and shouldn't also get read as a
	# command or as the milder insult_playful banter further down.
	if _matches_any(lower, insult_keywords):
		_apply_mood_change(-mood_insult_penalty)
		if mode != "avoid":
			mode = "avoid"
			avoid_timer = mood_avoid_duration
		else:
			avoid_timer = max(avoid_timer, mood_avoid_duration)
		say(_pick(mood_angry_lines if affection < 15.0 else mood_annoyed_lines))
		return

	var matched_command = _match_command(lower)
	if matched_command != "":
		_handle_command(matched_command)
		return

	if _matches_any(lower, progress_keywords):
		say("I've got %s out of %s wood so far, at x%d multiplier." % [NumberFormat.abbreviate(carried_wood), NumberFormat.abbreviate(wood_needed_to_deliver), ai_multiplier])
		return
	if _matches_any(lower, multiplier_keywords):
		say("My current multiplier is x%d." % ai_multiplier)
		return

	if _matches_any(lower, greeting_keywords):
		say(_pick(greeting_lines)); return
	if _matches_any(lower, farewell_keywords):
		say(_pick(farewell_lines)); return
	if _matches_any(lower, welcome_back_keywords):
		say(_pick(welcome_back_lines)); return
	if _matches_any(lower, wellbeing_keywords):
		# Reflects actual accumulated fatigue/mood instead of always the
		# same generic reply regardless of how much it's actually done.
		if fatigue >= 75.0:
			say(_pick(sleepy_lines if fatigue >= 90.0 else tired_lines))
		elif _mood() == "angry" or _mood() == "annoyed":
			say(_pick(mood_angry_lines if _mood() == "angry" else mood_annoyed_lines))
		else:
			say(_pick(wellbeing_lines))
		return
	if _matches_any(lower, thanks_keywords):
		_apply_mood_change(mood_kindness_gain)
		say(_pick(thanks_lines)); return
	if _matches_any(lower, apology_keywords):
		_apply_mood_change(mood_kindness_gain)
		say(_pick(apology_lines)); return
	if _matches_any(lower, agree_keywords):
		say(_pick(agree_lines)); return
	if _matches_any(lower, disagree_keywords):
		say(_pick(disagree_lines)); return
	if _matches_any(lower, name_keywords):
		say(_pick(name_lines)); return
	if _matches_any(lower, favorite_tree_keywords):
		say(_pick(favorite_tree_lines)); return
	if _matches_any(lower, favorite_color_keywords):
		say(_pick(favorite_color_lines)); return
	if _matches_any(lower, favorite_season_keywords):
		say(_pick(favorite_season_lines)); return
	if _matches_any(lower, hobbies_keywords):
		say(_pick(hobbies_lines)); return
	if _matches_any(lower, dreams_keywords):
		say(_pick(dreams_lines)); return
	if _matches_any(lower, backstory_keywords):
		say(_pick(backstory_lines)); return
	if _matches_any(lower, mood_happy_keywords) or _matches_any(lower, mood_sad_keywords):
		# Answers honestly based on actual affection, regardless of which
		# of the two phrasings was used to ask.
		match _mood():
			"cheerful":
				say(_pick(mood_cheerful_lines))
			"happy":
				say(_pick(mood_happy_lines))
			"annoyed":
				say(_pick(mood_annoyed_lines))
			"angry":
				say(_pick(mood_angry_lines))
			_:
				say(_pick(mood_sad_lines))
		return
	if _matches_any(lower, philosophical_keywords):
		say(_pick(philosophical_lines)); return
	if _matches_any(lower, encouragement_keywords):
		say(_pick(encouragement_lines)); return
	if _matches_any(lower, motivational_keywords):
		say(_pick(motivational_lines)); return
	if _matches_any(lower, tired_keywords):
		# Honest either way — always claiming exhaustion regardless of
		# whether it's actually done anything yet reads as scripted.
		say(_pick(tired_lines) if fatigue >= 50.0 else _pick(wellbeing_lines))
		return
	if _matches_any(lower, sleepy_keywords):
		say(_pick(sleepy_lines) if fatigue >= 75.0 else _pick(wellbeing_lines))
		return
	if _matches_any(lower, hungry_keywords):
		say(_pick(hungry_lines)); return
	if _matches_any(lower, bored_keywords):
		say(_pick(bored_lines)); return
	if _matches_any(lower, progress_flavor_keywords):
		say(_pick(progress_flavor_lines)); return
	if _matches_any(lower, upgrade_curious_keywords):
		say(_pick(upgrade_curious_lines)); return
	if _matches_any(lower, shop_curious_keywords):
		say(_pick(shop_curious_lines)); return
	if _matches_any(lower, axe_curious_keywords):
		say(_pick(axe_curious_lines)); return
	if _matches_any(lower, complaint_trees_keywords):
		say(_pick(complaint_trees_lines)); return
	if _matches_any(lower, multiplier_flavor_keywords):
		say(_pick(multiplier_flavor_lines)); return
	if _matches_any(lower, achievement_keywords):
		say(_pick(achievement_lines)); return
	if _matches_any(lower, competition_keywords):
		say(_pick(competition_lines)); return
	if _matches_any(lower, teamwork_keywords):
		say(_pick(teamwork_lines)); return
	if _matches_any(lower, joke_keywords):
		say(_pick(joke_lines)); return
	if _matches_any(lower, riddle_keywords):
		say(_pick(riddle_lines)); return
	if _matches_any(lower, random_fact_keywords):
		say(_pick(random_fact_lines)); return
	if _matches_any(lower, singing_keywords):
		say(_pick(singing_lines)); return
	if _matches_any(lower, dancing_keywords):
		say(_pick(dancing_lines)); return
	if _matches_any(lower, easter_egg_keywords):
		say(_pick(easter_egg_lines)); return
	if _matches_any(lower, love_game_keywords):
		say(_pick(love_game_lines)); return
	if _matches_any(lower, hate_game_keywords):
		say(_pick(hate_game_lines)); return
	if _matches_any(lower, question_back_keywords):
		say(_pick(question_back_lines)); return
	if _matches_any(lower, curious_player_keywords):
		say(_pick(curious_player_lines)); return
	if _matches_any(lower, compliment_player_keywords):
		say(_pick(compliment_player_lines)); return
	if _matches_any(lower, insult_playful_keywords):
		say(_pick(insult_playful_lines)); return
	if _matches_any(lower, weather_keywords):
		say(_pick(weather_lines)); return
	if _matches_any(lower, rain_keywords):
		say(_pick(rain_lines)); return
	if _matches_any(lower, snow_keywords):
		say(_pick(snow_lines)); return
	if _matches_any(lower, wind_keywords):
		say(_pick(wind_lines)); return
	if _matches_any(lower, sunset_keywords):
		say(_pick(sunset_lines)); return
	if _matches_any(lower, sunrise_keywords):
		say(_pick(sunrise_lines)); return
	if _matches_any(lower, night_keywords):
		say(_pick(night_lines)); return
	if _matches_any(lower, morning_keywords):
		say(_pick(morning_lines)); return
	if _matches_any(lower, weekend_keywords):
		say(_pick(weekend_lines)); return
	if _matches_any(lower, birthday_keywords):
		say(_pick(birthday_lines)); return
	if _matches_any(lower, holiday_keywords):
		say(_pick(holiday_lines)); return
	if _matches_any(lower, time_question_keywords):
		say(_pick(time_question_lines)); return
	if _matches_any(lower, help_question_keywords):
		say(_pick(help_question_lines)); return
	if _matches_any(lower, confused_meta_keywords):
		say(_pick(confused_meta_lines)); return
	if _matches_any(lower, praise_axe_keywords):
		say(_pick(praise_axe_lines)); return
	if _matches_any(lower, distance_question_keywords):
		say(_pick(distance_question_lines)); return
	if _matches_any(lower, curious_shop_price_keywords):
		say(_pick(curious_shop_price_lines)); return
	if _matches_any(lower, curious_boost_keywords):
		say(_pick(curious_boost_lines)); return
	if _matches_any(lower, curious_travel_keywords):
		say(_pick(curious_travel_lines)); return
	if _matches_any(lower, praise_teamwork_keywords):
		say(_pick(praise_teamwork_lines)); return
	if _matches_any(lower, curious_wood_use_keywords):
		say(_pick(curious_wood_use_lines)); return
	if _matches_any(lower, reassurance_keywords):
		say(_pick(reassurance_lines)); return
	if _matches_any(lower, curiosity_meta_keywords):
		say(_pick(curiosity_meta_lines)); return
	if _matches_any(lower, gratitude_generic_keywords):
		say(_pick(gratitude_generic_lines)); return
	if _matches_any(lower, curious_mood_game_keywords):
		say(_pick(curious_mood_game_lines)); return
	if _matches_any(lower, praise_progress_long_keywords):
		say(_pick(praise_progress_long_lines)); return
	if _matches_any(lower, curious_next_goal_keywords):
		say(_pick(curious_next_goal_lines)); return
	if _matches_any(lower, casual_smalltalk_keywords):
		say(_pick(casual_smalltalk_lines)); return
	if _matches_any(lower, curious_wildlife_keywords):
		say(_pick(curious_wildlife_lines)); return
	if _matches_any(lower, curious_size_forest_keywords):
		say(_pick(curious_size_forest_lines)); return
	if _matches_any(lower, reaction_big_number_keywords):
		say(_pick(reaction_big_number_lines)); return
	if _matches_any(lower, praise_multiplier_growth_keywords):
		say(_pick(praise_multiplier_growth_lines)); return
	if _matches_any(lower, curious_limit_keywords):
		say(_pick(curious_limit_lines)); return
	if _matches_any(lower, small_celebration_keywords):
		say(_pick(small_celebration_lines)); return


	var pool = idle_chat_lines if randi() % 2 == 0 else unknown_lines
	say(_pick(pool))

func _matches_any(lower: String, keywords: Array) -> bool:
	for k in keywords:
		if k in lower:
			return true
	return false

func _match_command(lower: String) -> String:
	for command in command_keywords.keys():
		for keyword in command_keywords[command]:
			if keyword in lower:
				return command
	return ""

func _handle_command(command: String):
	var obeys = randf() < _effective_obedience_chance()
	var lines = obey_lines[command] if obeys else refuse_lines[command]
	say(_pick(lines))

	if not obeys:
		return

	match command:
		"come":
			mode = "follow"
		"stay":
			mode = "stay"
		"work":
			mode = "auto"
			task = "gathering"
		"shop":
			mode = "auto"
			task = "delivering"
		"patrol":
			if patrol_waypoints.is_empty():
				say("No route set up for me yet.")
			else:
				mode = "patrol"
			
			
