extends CharacterBody3D


const SPEED = 5.0
const JUMP_VELOCITY = 4.5
const sensitivity = 0.2

@onready var ANIME = $CharacterBody/AnimationPlayer
@onready var _spring_arm = $CharacterBody/Skeleton3D/BoneAttachment3D2/Head/HP
@onready var _spring_arm2 = $Head/HP

@onready var GAME_CAM = $Head/HP/Camera3D
@onready var REAL_CAM = $CharacterBody/Skeleton3D/BoneAttachment3D2/Head/HP/Camera3D

@onready var JUMP = $Ui/Jump
@onready var CHOP = $Ui/Chop

@onready var JUMP_AUDIO = $Audio/Jumping
@onready var RUN_AUDIO = $Audio/Running
@onready var CHOP_AUDIO = $Audio/Chopping

# Relative rather than absolute "/root/MAIN/..." paths — those break if
# MAIN ever ends up loaded somewhere other than literally the scene
# tree's root. MainUi and Nav are siblings of Character under MAIN either
# way, so ".." always reaches them correctly regardless of where MAIN
# itself sits.
@onready var SAVE_BTN = get_node("../MainUi/Panel/OptionsPanel/Options/SaveBtn")
@onready var LOAD_BTN = get_node("../MainUi/Panel/OptionsPanel/Options/LoadBtn")
@onready var SHOP_UI = get_tree().current_scene.find_child("ShopUi", true, false)

var axe_ray: RayCast3D
var chop_dot: ColorRect
var tree_target_label: Label
var looked_target_label: Label
var looked_tree: Node3D = null
var looked_shop: Node = null
var looked_travel: Node = null


func _ready():
	REAL_CAM.current = true
	GAME_CAM.current = false
	add_to_group("player")
	_setup_axe_ray()
	_setup_chop_dot()
	load_game()

func _setup_axe_ray() -> void:
	axe_ray = RayCast3D.new()
	axe_ray.name = "AxeRayCast3D"
	axe_ray.target_position = Vector3(0, 0, -7.0)
	axe_ray.collision_mask = 0xFFFFFFFF
	axe_ray.collide_with_areas = true
	axe_ray.collide_with_bodies = true
	axe_ray.add_exception(self)   # never "hit" the player itself
	REAL_CAM.add_child(axe_ray)
	axe_ray.enabled = true

func _setup_chop_dot() -> void:
	chop_dot = ColorRect.new()
	chop_dot.name = "ChopAimDot"
	chop_dot.color = Color.WHITE
	chop_dot.size = Vector2(6, 6)
	chop_dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	$Ui.add_child(chop_dot)

	tree_target_label = Label.new()
	tree_target_label.name = "TreeTargetLabel"
	tree_target_label.text = ""
	tree_target_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tree_target_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	tree_target_label.add_theme_font_size_override("font_size", 11)
	tree_target_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tree_target_label.visible = false
	$Ui.add_child(tree_target_label)
	looked_target_label = tree_target_label

	get_viewport().size_changed.connect(_position_chop_dot)
	_position_chop_dot()

func _position_chop_dot() -> void:
	if chop_dot == null:
		return
	var size := get_viewport().get_visible_rect().size
	chop_dot.position = size * 0.5 - chop_dot.size * 0.5
	if tree_target_label:
		tree_target_label.position = Vector2(chop_dot.position.x - 32.0, chop_dot.position.y + 6.0)
		tree_target_label.size = Vector2(64.0, 18.0)

func _find_group_ancestor(node: Node, group_name: String) -> Node:
	var current := node
	while current != null:
		if current.is_in_group(group_name):
			return current
		current = current.get_parent()
	return null

func _update_look_target() -> void:
	looked_tree = null
	looked_shop = null
	looked_travel = null

	if axe_ray == null:
		return

	axe_ray.force_raycast_update()
	var collider := axe_ray.get_collider()
	if collider != null:
		looked_tree = _find_group_ancestor(collider, "tree")
		looked_shop = _find_group_ancestor(collider, "shop_stall")
		looked_travel = _find_group_ancestor(collider, "travel_port")
		# Never target anything that belongs to the hidden (other) world.
		if looked_tree != null and not looked_tree.is_visible_in_tree():
			looked_tree = null
		if looked_shop != null and looked_shop is Node3D and not looked_shop.is_visible_in_tree():
			looked_shop = null
		if looked_travel != null and looked_travel is Node3D and not looked_travel.is_visible_in_tree():
			looked_travel = null

	if chop_dot:
		# The aiming dot is always visible. Only the target text changes.
		chop_dot.visible = true
	if tree_target_label:
		var target_text := ""
		if looked_tree != null:
			target_text = "TREE"
		elif looked_shop != null:
			target_text = "SHOP"
		elif looked_travel != null:
			target_text = "TRAVEL"
		tree_target_label.text = target_text
		tree_target_label.visible = target_text != ""

	for stall in get_tree().get_nodes_in_group("shop_stall"):
		if stall.has_method("set_looked_at"):
			stall.set_looked_at(stall == looked_shop)

	for port in get_tree().get_nodes_in_group("travel_port"):
		if port.has_method("set_looked_at"):
			port.set_looked_at(port == looked_travel)

func _chop_looked_tree() -> void:
	if looked_tree == null or not is_instance_valid(looked_tree):
		return
	if looked_tree.has_method("chop_from_player"):
		looked_tree.chop_from_player(self)
	elif looked_tree.has_method("chop"):
		looked_tree.chop()


func _notification(what):
	match what:
		NOTIFICATION_WM_CLOSE_REQUEST:      # desktop: window closed
			save_game()
		NOTIFICATION_APPLICATION_PAUSED:    # mobile: app backgrounded (home/switch away)
			save_game()
		NOTIFICATION_APPLICATION_FOCUS_OUT: # extra safety net, fires earlier than PAUSED
			save_game()
	
func save_game():
	SaveGame.save_game(WoodCompanion.wood_companion, Wood.wood, Wood.multiplier, Wood.multiplier2, Wood.multiplier_add, Wood.axe_tier, Wood.power_tier, Wood.boost_tier)

func load_game():
	var data = SaveGame.load_game()
	if data:
		
		Wood.wood = data["wood"]
		Wood.multiplier = data["multiplier"]
		Wood.multiplier2 = data["multiplier2"]
		Wood.multiplier_add = data["multiplier_add"]
		Wood.axe_tier = max(1, int(data.get("axe_tier", 1)))
		Wood.power_tier = int(data.get("power_tier", 0))
		Wood.boost_tier = int(data.get("boost_tier", 0))

		# Correct the old Shop 2 multiplier bug for a starting player.
		if Wood.axe_tier == 1 and Wood.power_tier == 0:
			Wood.multiplier = 1
			Wood.multiplier2 = 1
		if Wood.boost_tier == 0:
			Wood.multiplier_add = 0

		Wood.wood_changed.emit(Wood.wood)
		# The companion's own save/load lives in Wood_companion.gd now —
		# this used to read wood_companion back manually here and never
		# did (it was saved but not restored), which is why the multiplier
		# requirement looked like it wasn't tracking correctly.
		WoodCompanion.load_progress()
		if SHOP_UI:
			SHOP_UI.call_deferred("apply_purchase_state")
		print("Game loaded! Wood: ", Wood.wood)

func _unhandled_input(event):
	if event is InputEventScreenDrag:
		rotate_y(deg_to_rad(-event.relative.x * sensitivity))
		_spring_arm.rotate_x(deg_to_rad(-event.relative.y * sensitivity))
		
		_spring_arm.rotation.x = clamp(_spring_arm.rotation.x, deg_to_rad(-50), deg_to_rad(45))
		
	if event is InputEventScreenDrag:
		rotate_y(deg_to_rad(-event.relative.x * sensitivity))
		_spring_arm2.rotate_x(deg_to_rad(-event.relative.y * sensitivity))
		
		_spring_arm2.rotation.x = clamp(_spring_arm2.rotation.x, deg_to_rad(-50), deg_to_rad(45))


func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if JUMP.is_pressed() and is_on_floor():
		velocity.y = JUMP_VELOCITY
		await get_tree().create_timer(0.5).timeout
		JUMP_AUDIO.play()
	
	_update_look_target()

	if CHOP.is_pressed():
		# The swing animation always plays when attack is pressed.
		if ANIME.current_animation != "attack/attack":
			ANIME.play("attack/attack")
		# Wood is still only chopped when the ray is on a tree.
		_chop_looked_tree()
			
	if SAVE_BTN.is_pressed():
		save_game()
		
	if LOAD_BTN.is_pressed():
		load_game()

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var input_dir := Input.get_vector("move_left","move_right","move_forward","move_back")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if direction:
		GAME_CAM.fov = 120
		REAL_CAM.fov = 120
		RUN_AUDIO.play()
		if ANIME.current_animation == "attack/attack":
			return
		else:
			ANIME.play("mixamo_com")
		velocity.x = direction.x * SPEED
		velocity.z = direction.z * SPEED
	else:
		GAME_CAM.fov = 110
		REAL_CAM.fov = 110
		RUN_AUDIO.stop()
		if ANIME.current_animation == "attack/attack":
			return
		else:
			ANIME.play("idle/idle")
		velocity.x = move_toward(velocity.x, 0, SPEED)
		velocity.z = move_toward(velocity.z, 0, SPEED)

	move_and_slide()
