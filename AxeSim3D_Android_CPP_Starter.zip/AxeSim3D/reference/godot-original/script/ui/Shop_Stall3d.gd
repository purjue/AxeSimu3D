extends Node3D




# Relative rather than absolute "/root/MAIN/..." — see travel_port.gd for
# why. Shop3D sits 3 levels under MAIN (Shop3D -> Level-1 or Level-2 -> Nav
# -> MAIN) in both worlds, so "../../../" reaches MAIN from either.
@onready var PLAYER_UI = get_node("../../../Character/Ui")

@onready var SHOPUI = $ShopUi
@onready var SHOP_BTN = $Shopbtns/ShopBtn
@onready var SHOP_CLOSE = $Shopbtns/ShopClose

@onready var area = $Area3D

var looked_at := false

func _ready():
	add_to_group("shop_stall")
	area.body_entered.connect(_on_body_entered)
	area.body_exited.connect(_on_body_exited)
	SHOP_BTN.visible = false

func set_looked_at(value: bool) -> void:
	looked_at = value
	if SHOPUI.visible:
		SHOP_BTN.visible = false
	else:
		SHOP_BTN.visible = value

func _on_body_entered(_body):
	# The shop button is now controlled by the player's aim ray, not proximity.
	pass
		
func _on_body_exited(_body):
	PLAYER_UI.visible = true
	SHOP_CLOSE.visible = false
	SHOP_BTN.visible = false
	SHOPUI.visible = false
	
func _physics_process(_delta):
	if SHOP_BTN.is_pressed():
		PLAYER_UI.visible = false
		SHOP_BTN.visible = false
		SHOP_CLOSE.visible = true
		SHOPUI.visible = true
		
	if SHOP_CLOSE.is_pressed():
		PLAYER_UI.visible = true
		SHOP_CLOSE.visible = false
		SHOP_BTN.visible = looked_at
		SHOPUI.visible = false
	
	
