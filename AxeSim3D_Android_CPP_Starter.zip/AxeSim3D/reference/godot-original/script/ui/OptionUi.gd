extends CanvasLayer


@onready var OPTION_BTN = $OptionBtn
@onready var OPTIONS = $Panel
@onready var OPTION_CLOSE = $OptionClose

@onready var SAVE = $Panel/OptionsPanel/Options/SaveBtn
@onready var LOAD = $Panel/OptionsPanel/Options/LoadBtn

@onready var CAM_SH_BTN = $Panel/OptionsPanel/Options/RealCam
@onready var CAM_SH_OFF_BTN = $Panel/OptionsPanel/Options/GameCam

@onready var CREDIT = $Panel/OptionsPanel/Options/Credit

# Relative rather than absolute "/root/MAIN/..." — see travel_port.gd for
# why. This script sits on MainUi itself, 1 level under MAIN, so "../"
# reaches MAIN.
@onready var REAL_CAM = get_node("../Character/CharacterBody/Skeleton3D/BoneAttachment3D2/Head/HP/Camera3D")
@onready var GAME_CAM = get_node("../Character/Head/HP/Camera3D")

@onready var GRAPHIC_MENU = $Graphic

	
func _physics_process(_delta):
	if OPTION_BTN.is_pressed():
		OPTIONS.visible = true
		OPTION_BTN.visible = false
		OPTION_CLOSE.visible = true
		CREDIT.visible = true
		GRAPHIC_MENU.visible = true
		
	if OPTION_CLOSE.is_pressed():
		OPTIONS.visible = false
		OPTION_BTN.visible = true
		OPTION_CLOSE.visible = false
		CREDIT.visible = false
		GRAPHIC_MENU.visible = false
		
	if SAVE.is_pressed():
		OPTIONS.visible = false
		OPTION_CLOSE.visible = false
		OPTION_BTN.visible = true
		
	if LOAD.is_pressed():
		OPTIONS.visible = false
		OPTION_CLOSE.visible = false
		OPTION_BTN.visible = true
		
	if CAM_SH_BTN.is_pressed():
		REAL_CAM.current = false
		GAME_CAM.current = true
		CAM_SH_BTN.visible = false
		CAM_SH_OFF_BTN.visible = true
		
	if CAM_SH_OFF_BTN.is_pressed():
		REAL_CAM.current = true
		GAME_CAM.current = false
		CAM_SH_BTN.visible = true
		CAM_SH_OFF_BTN.visible = false
		
