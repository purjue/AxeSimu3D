extends CanvasLayer

# ============================================================
# SHOP 2 / SAVE-SAFE PROGRESSION
# These values belong ONLY to ShopUi2.
# They deliberately use separate SaveGame keys from ShopUi.
# ============================================================

@export var AXE_COST: int = 600_000_000_000
@export var AXE_COST2: int = 1_200_000_000_000
@export var AXE_COST3: int = 2_500_000_000_000
@export var AXE_COST4: int = 5_000_000_000_000
@export var AXE_COST5: int = 10_000_000_000_000
@export var AXE_COST6: int = 20_000_000_000_000
@export var AXE_COST7: int = 40_000_000_000_000
@export var AXE_COST8: int = 80_000_000_000_000
@export var AXE_COST9: int = 160_000_000_000_000
@export var AXE_COST10: int = 320_000_000_000_000

@export var POWER_COST: int = 20_000_000_000_000
@export var POWER_COST2: int = 40_000_000_000_000
@export var POWER_COST3: int = 80_000_000_000_000
@export var POWER_COST4: int = 160_000_000_000_000
@export var POWER_COST5: int = 320_000_000_000_000

@export var BOOST_COST: int = 80_000_000_000_000
@export var BOOST_COST2: int = 160_000_000_000_000
@export var BOOST_COST3: int = 320_000_000_000_000
@export var BOOST_COST4: int = 640_000_000_000_000
@export var BOOST_COST5: int = 1_280_000_000_000_000

@onready var BUY_AXE = $Panel/MainRow/Row1/Row/ItemGrid/BuyBtn
@onready var BUY_AXE2 = $Panel/MainRow/Row1/Row/ItemGrid2/BuyBtn
@onready var BUY_AXE3 = $Panel/MainRow/Row1/Row/ItemGrid3/BuyBtn
@onready var BUY_AXE4 = $Panel/MainRow/Row1/Row/ItemGrid4/BuyBtn
@onready var BUY_AXE5 = $Panel/MainRow/Row1/Row/ItemGrid5/BuyBtn
@onready var BUY_AXE6 = $Panel/MainRow/Row2/Row/ItemGrid/BuyBtn
@onready var BUY_AXE7 = $Panel/MainRow/Row2/Row/ItemGrid2/BuyBtn
@onready var BUY_AXE8 = $Panel/MainRow/Row2/Row/ItemGrid3/BuyBtn
@onready var BUY_AXE9 = $Panel/MainRow/Row2/Row/ItemGrid4/BuyBtn
@onready var BUY_AXE10 = $Panel/MainRow/Row2/Row/ItemGrid5/BuyBtn

@onready var BUY_POWER = $Panel/MainRow/Row3/Row/ItemGrid/BuyBtn
@onready var BUY_POWER2 = $Panel/MainRow/Row3/Row/ItemGrid2/BuyBtn
@onready var BUY_POWER3 = $Panel/MainRow/Row3/Row/ItemGrid3/BuyBtn
@onready var BUY_POWER4 = $Panel/MainRow/Row3/Row/ItemGrid4/BuyBtn
@onready var BUY_POWER5 = $Panel/MainRow/Row3/Row/ItemGrid5/BuyBtn

@onready var ITEM_GRID = $Panel/MainRow/Row4/ItemRow/ItemGrid
@onready var ITEM_GRID2 = $Panel/MainRow/Row4/ItemRow/ItemGrid2
@onready var ITEM_GRID3 = $Panel/MainRow/Row4/ItemRow/ItemGrid3
@onready var ITEM_GRID4 = $Panel/MainRow/Row4/ItemRow/ItemGrid4
@onready var ITEM_GRID5 = $Panel/MainRow/Row4/ItemRow/ItemGrid5

@onready var BUY_BOOST = $Panel/MainRow/Row4/ItemRow/ItemGrid/Buy
@onready var BUY_BOOST2 = $Panel/MainRow/Row4/ItemRow/ItemGrid2/Buy
@onready var BUY_BOOST3 = $Panel/MainRow/Row4/ItemRow/ItemGrid3/Buy
@onready var BUY_BOOST4 = $Panel/MainRow/Row4/ItemRow/ItemGrid4/Buy
@onready var BUY_BOOST5 = $Panel/MainRow/Row4/ItemRow/ItemGrid5/Buy

@onready var EQUIP_AXE = $Panel/MainRow/Row1/Row/ItemGrid/EquipBtn
@onready var EQUIP_AXE2 = $Panel/MainRow/Row1/Row/ItemGrid2/EquipBtn
@onready var EQUIP_AXE3 = $Panel/MainRow/Row1/Row/ItemGrid3/EquipBtn
@onready var EQUIP_AXE4 = $Panel/MainRow/Row1/Row/ItemGrid4/EquipBtn
@onready var EQUIP_AXE5 = $Panel/MainRow/Row1/Row/ItemGrid5/EquipBtn
@onready var EQUIP_AXE6 = $Panel/MainRow/Row2/Row/ItemGrid/EquipBtn
@onready var EQUIP_AXE7 = $Panel/MainRow/Row2/Row/ItemGrid2/EquipBtn
@onready var EQUIP_AXE8 = $Panel/MainRow/Row2/Row/ItemGrid3/EquipBtn
@onready var EQUIP_AXE9 = $Panel/MainRow/Row2/Row/ItemGrid4/EquipBtn
@onready var EQUIP_AXE10 = $Panel/MainRow/Row2/Row/ItemGrid5/EquipBtn

@onready var EQUIP_POWER = $Panel/MainRow/Row3/Row/ItemGrid/EquipBtn
@onready var EQUIP_POWER2 = $Panel/MainRow/Row3/Row/ItemGrid2/EquipBtn
@onready var EQUIP_POWER3 = $Panel/MainRow/Row3/Row/ItemGrid3/EquipBtn
@onready var EQUIP_POWER4 = $Panel/MainRow/Row3/Row/ItemGrid4/EquipBtn
@onready var EQUIP_POWER5 = $Panel/MainRow/Row3/Row/ItemGrid5/EquipBtn

var axe_buy_btns: Array[Button]
var axe_equip_btns: Array[Button]
var axe_costs: Array[int]
var axe_multipliers: Array[int]

var power_buy_btns: Array[Button]
var power_equip_btns: Array[Button]
var power_costs: Array[int]
var power_multipliers: Array[int]

var boost_buy_btns: Array[Button]
var boost_item_grids: Array[Control]
var boost_costs: Array[int]
var boost_multipliers: Array[int]

# Shop 2 has its own progression IDs.
var shop2_axe_owned_tier: int = 0
var shop2_axe_equipped_tier: int = 0
var shop2_power_owned_tier: int = 0
var shop2_power_equipped_tier: int = 0
var shop2_boost_owned_tier: int = 0
var shop2_boost_equipped_tier: int = 0

# Each item has its own ownership flag. Equipping one item never removes
# ownership from any other purchased item.
var shop2_axe_owned: Array[bool] = []
var shop2_power_owned: Array[bool] = []
var shop2_boost_owned: Array[bool] = []

func _ready() -> void:
	axe_buy_btns = [
		BUY_AXE, BUY_AXE2, BUY_AXE3, BUY_AXE4, BUY_AXE5,
		BUY_AXE6, BUY_AXE7, BUY_AXE8, BUY_AXE9, BUY_AXE10
	]
	axe_equip_btns = [
		EQUIP_AXE, EQUIP_AXE2, EQUIP_AXE3, EQUIP_AXE4, EQUIP_AXE5,
		EQUIP_AXE6, EQUIP_AXE7, EQUIP_AXE8, EQUIP_AXE9, EQUIP_AXE10
	]
	axe_costs = [
		AXE_COST, AXE_COST2, AXE_COST3, AXE_COST4, AXE_COST5,
		AXE_COST6, AXE_COST7, AXE_COST8, AXE_COST9, AXE_COST10
	]

	# These are the wood amounts shown in the Skill descriptions.
	# The first skill therefore gives 1,000,000 wood per base chop.
	axe_multipliers = [
		1_000_000, 2_000_000, 5_000_000, 10_000_000, 20_000_000,
		50_000_000, 100_000_000, 200_000_000, 500_000_000, 1_000_000_000
	]

	power_buy_btns = [BUY_POWER, BUY_POWER2, BUY_POWER3, BUY_POWER4, BUY_POWER5]
	power_equip_btns = [EQUIP_POWER, EQUIP_POWER2, EQUIP_POWER3, EQUIP_POWER4, EQUIP_POWER5]
	power_costs = [POWER_COST, POWER_COST2, POWER_COST3, POWER_COST4, POWER_COST5]
	power_multipliers = [64, 128, 256, 512, 1024]

	boost_buy_btns = [BUY_BOOST, BUY_BOOST2, BUY_BOOST3, BUY_BOOST4, BUY_BOOST5]
	boost_item_grids = [ITEM_GRID, ITEM_GRID2, ITEM_GRID3, ITEM_GRID4, ITEM_GRID5]
	boost_costs = [BOOST_COST, BOOST_COST2, BOOST_COST3, BOOST_COST4, BOOST_COST5]
	boost_multipliers = [64, 128, 256, 512, 1024]

	load_shop2_progress()
	apply_purchase_state()


func load_shop2_progress() -> void:
	SaveGame.load_game()
	var data = SaveGame.game_data
	shop2_axe_owned.resize(axe_buy_btns.size())
	shop2_power_owned.resize(power_buy_btns.size())
	shop2_boost_owned.resize(boost_buy_btns.size())

	# Migrate old tier-based Shop 2 saves: old tier N meant the first N items were owned.
	var old_axe := clampi(int(data.get("shop2_axe_owned_tier", 0)), 0, shop2_axe_owned.size())
	var old_power := clampi(int(data.get("shop2_power_owned_tier", 0)), 0, shop2_power_owned.size())
	var old_boost := clampi(int(data.get("shop2_boost_owned_tier", 0)), 0, shop2_boost_owned.size())
	var saved_axe = data.get("shop2_axe_owned", [])
	var saved_power = data.get("shop2_power_owned", [])
	var saved_boost = data.get("shop2_boost_owned", [])
	for i in shop2_axe_owned.size():
		shop2_axe_owned[i] = i < old_axe
		if saved_axe is Array and i < saved_axe.size():
			shop2_axe_owned[i] = bool(saved_axe[i])
	for i in shop2_power_owned.size():
		shop2_power_owned[i] = i < old_power
		if saved_power is Array and i < saved_power.size():
			shop2_power_owned[i] = bool(saved_power[i])
	for i in shop2_boost_owned.size():
		shop2_boost_owned[i] = i < old_boost
		if saved_boost is Array and i < saved_boost.size():
			shop2_boost_owned[i] = bool(saved_boost[i])

	shop2_axe_owned_tier = _last_owned_tier(shop2_axe_owned)
	shop2_power_owned_tier = _last_owned_tier(shop2_power_owned)
	shop2_boost_owned_tier = _last_owned_tier(shop2_boost_owned)
	shop2_axe_equipped_tier = clampi(int(data.get("shop2_axe_equipped_tier", 0)), 0, shop2_axe_owned.size())
	shop2_power_equipped_tier = clampi(int(data.get("shop2_power_equipped_tier", 0)), 0, shop2_power_owned.size())
	shop2_boost_equipped_tier = clampi(int(data.get("shop2_boost_equipped_tier", 0)), 0, shop2_boost_owned.size())
	if shop2_axe_equipped_tier > 0 and not shop2_axe_owned[shop2_axe_equipped_tier - 1]:
		shop2_axe_equipped_tier = 0
	if shop2_power_equipped_tier > 0 and not shop2_power_owned[shop2_power_equipped_tier - 1]:
		shop2_power_equipped_tier = 0
	if shop2_boost_equipped_tier > 0 and not shop2_boost_owned[shop2_boost_equipped_tier - 1]:
		shop2_boost_equipped_tier = 0

func _last_owned_tier(items: Array[bool]) -> int:
	for i in range(items.size() - 1, -1, -1):
		if items[i]:
			return i + 1
	return 0

func save_shop2_progress() -> void:
	shop2_axe_owned_tier = _last_owned_tier(shop2_axe_owned)
	shop2_power_owned_tier = _last_owned_tier(shop2_power_owned)
	shop2_boost_owned_tier = _last_owned_tier(shop2_boost_owned)
	SaveGame.save_shop2_progress(
		shop2_axe_owned_tier, shop2_axe_equipped_tier,
		shop2_power_owned_tier, shop2_power_equipped_tier,
		shop2_boost_owned_tier, shop2_boost_equipped_tier,
		shop2_axe_owned, shop2_power_owned, shop2_boost_owned
	)

func apply_purchase_state() -> void:
	# Every unpurchased item shows Buy. Every purchased item keeps Equip.
	for i in axe_buy_btns.size():
		axe_buy_btns[i].visible = not shop2_axe_owned[i]
		axe_equip_btns[i].visible = shop2_axe_owned[i]
		if shop2_axe_owned[i]:
			axe_equip_btns[i].text = "Equipped" if i + 1 == shop2_axe_equipped_tier else "Equip"
			axe_equip_btns[i].disabled = i + 1 == shop2_axe_equipped_tier

	for i in power_buy_btns.size():
		power_buy_btns[i].visible = not shop2_power_owned[i]
		power_equip_btns[i].visible = shop2_power_owned[i]
		if shop2_power_owned[i]:
			power_equip_btns[i].text = "Equipped" if i + 1 == shop2_power_equipped_tier else "Equip"
			power_equip_btns[i].disabled = i + 1 == shop2_power_equipped_tier

	# Shop 2 boosts use the same one-at-a-time progression as Shop 1.
	# First boost is visible initially; after buying it, only the next boost
	# appears. Already-purchased boosts remain owned in the save.
	var next_boost_tier := _last_owned_tier(shop2_boost_owned)
	for i in boost_item_grids.size():
		boost_item_grids[i].visible = (i == next_boost_tier)
		boost_buy_btns[i].visible = (i == next_boost_tier and not shop2_boost_owned[i])

	if shop2_axe_equipped_tier > 0:
		Wood.multiplier = axe_multipliers[shop2_axe_equipped_tier - 1]
	if shop2_power_equipped_tier > 0:
		Wood.multiplier2 = power_multipliers[shop2_power_equipped_tier - 1]
	if shop2_boost_equipped_tier > 0:
		Wood.multiplier_add = boost_multipliers[shop2_boost_equipped_tier - 1]

func _physics_process(_delta: float) -> void:
	for i in axe_buy_btns.size():
		if axe_buy_btns[i].visible and axe_buy_btns[i].is_pressed():
			if Wood.spend_wood(axe_costs[i]):
				shop2_axe_owned[i] = true
				shop2_axe_equipped_tier = i + 1
				apply_purchase_state()
				save_shop2_progress()
		elif axe_equip_btns[i].visible and axe_equip_btns[i].is_pressed() and shop2_axe_owned[i]:
			shop2_axe_equipped_tier = i + 1
			apply_purchase_state()
			save_shop2_progress()

	for i in power_buy_btns.size():
		if power_buy_btns[i].visible and power_buy_btns[i].is_pressed():
			if Wood.spend_wood(power_costs[i]):
				shop2_power_owned[i] = true
				shop2_power_equipped_tier = i + 1
				apply_purchase_state()
				save_shop2_progress()
		elif power_equip_btns[i].visible and power_equip_btns[i].is_pressed() and shop2_power_owned[i]:
			shop2_power_equipped_tier = i + 1
			apply_purchase_state()
			save_shop2_progress()

	for i in boost_buy_btns.size():
		if boost_buy_btns[i].visible and boost_buy_btns[i].is_pressed():
			if Wood.spend_wood(boost_costs[i]):
				shop2_boost_owned[i] = true
				shop2_boost_equipped_tier = i + 1
				apply_purchase_state()
				save_shop2_progress()
