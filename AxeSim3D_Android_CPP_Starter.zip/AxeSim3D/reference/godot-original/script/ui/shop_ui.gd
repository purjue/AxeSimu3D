extends CanvasLayer

@export var AXE_COST : int = 0
@export var AXE_COST2 : int = 100
@export var AXE_COST3 : int = 500
@export var AXE_COST4 : int = 1_500
@export var AXE_COST5 : int = 5_000
@export var AXE_COST6 : int = 7_500
@export var AXE_COST7 : int = 15_000
@export var AXE_COST8 : int = 30_000
@export var AXE_COST9 : int = 500_000
@export var AXE_COST10 : int = 10_000_000
@export var POWER_COST : int = 5000
@export var POWER_COST2 : int = 10_000
@export var POWER_COST3 : int = 50_000
@export var POWER_COST4 : int = 400_000
@export var POWER_COST5 : int = 1_600_000
@export var BOOST_COST : int = 10_000
@export var BOOST_COST2 : int = 200_000
@export var BOOST_COST3 : int = 500_000
@export var BOOST_COST4 : int = 700_000
@export var BOOST_COST5 : int = 1_600_000

@onready var BUY_AXE = $Panel/MainRow/Row1/Row/ItemGrid/BuyBtn
@onready var BUY_AXE2 = $Panel/MainRow/Row1/Row/ItemGrid2/BuyBtn
@onready var BUY_AXE3 = $Panel/MainRow/Row1/Row/ItemGrid3/BuyBtn
@onready var BUY_AXE4 = $Panel/MainRow/Row1/Row/ItemGrid4/BuyBtn
@onready var BUY_AXE5 = $Panel/MainRow/Row1/Row/ItemGrid5/BuyBtn
@onready var BUY_AXE6 = $Panel/MainRow/Row2/Row/ItemGrid/BuyBtn
@onready var BUY_AXE7 = $Panel/MainRow/Row2/Row/ItemGrid2/BuyBtn
@onready var BUY_AXE8 = $Panel/MainRow/Row2/Row/ItemGrid3/BuyBtn
@onready var BUY_AXE9 = $Panel/MainRow/Row2/Row/ItemGrid4/BuyBtn
@onready var BUY_AXE10 = $Panel/MainRow/Row2/Row/ItemGrid5/BuyBtn
@onready var BUY_POWER = $Panel/MainRow/Row3/Row/ItemGrid/BuyBtn
@onready var BUY_POWER2 = $Panel/MainRow/Row3/Row/ItemGrid2/BuyBtn
@onready var BUY_POWER3 = $Panel/MainRow/Row3/Row/ItemGrid3/BuyBtn
@onready var BUY_POWER4 = $Panel/MainRow/Row3/Row/ItemGrid4/BuyBtn
@onready var BUY_POWER5 = $Panel/MainRow/Row3/Row/ItemGrid5/BuyBtn
@onready var ITEM_GRID = $Panel/MainRow/Row4/ItemRow/ItemGrid
@onready var ITEM_GRID2 = $Panel/MainRow/Row4/ItemRow/ItemGrid2
@onready var ITEM_GRID3 = $Panel/MainRow/Row4/ItemRow/ItemGrid3
@onready var ITEM_GRID4 = $Panel/MainRow/Row4/ItemRow/ItemGrid4
@onready var ITEM_GRID5 = $Panel/MainRow/Row4/ItemRow/ItemGrid5
@onready var BUY_BOOST = $Panel/MainRow/Row4/ItemRow/ItemGrid/Buy
@onready var BUY_BOOST2 = $Panel/MainRow/Row4/ItemRow/ItemGrid2/Buy
@onready var BUY_BOOST3 = $Panel/MainRow/Row4/ItemRow/ItemGrid3/Buy
@onready var BUY_BOOST4 = $Panel/MainRow/Row4/ItemRow/ItemGrid4/Buy
@onready var BUY_BOOST5 = $Panel/MainRow/Row4/ItemRow/ItemGrid5/Buy
@onready var EQUIP_AXE = $Panel/MainRow/Row1/Row/ItemGrid/EquipBtn
@onready var EQUIP_AXE2 = $Panel/MainRow/Row1/Row/ItemGrid2/EquipBtn
@onready var EQUIP_AXE3 = $Panel/MainRow/Row1/Row/ItemGrid3/EquipBtn
@onready var EQUIP_AXE4 = $Panel/MainRow/Row1/Row/ItemGrid4/EquipBtn
@onready var EQUIP_AXE5 = $Panel/MainRow/Row1/Row/ItemGrid5/EquipBtn
@onready var EQUIP_AXE6 = $Panel/MainRow/Row2/Row/ItemGrid/EquipBtn
@onready var EQUIP_AXE7 = $Panel/MainRow/Row2/Row/ItemGrid2/EquipBtn
@onready var EQUIP_AXE8 = $Panel/MainRow/Row2/Row/ItemGrid3/EquipBtn
@onready var EQUIP_AXE9 = $Panel/MainRow/Row2/Row/ItemGrid4/EquipBtn
@onready var EQUIP_AXE10 = $Panel/MainRow/Row2/Row/ItemGrid5/EquipBtn
@onready var EQUIP_POWER = $Panel/MainRow/Row3/Row/ItemGrid/EquipBtn
@onready var EQUIP_POWER2 = $Panel/MainRow/Row3/Row/ItemGrid2/EquipBtn
@onready var EQUIP_POWER3 = $Panel/MainRow/Row3/Row/ItemGrid3/EquipBtn
@onready var EQUIP_POWER4 = $Panel/MainRow/Row3/Row/ItemGrid4/EquipBtn
@onready var EQUIP_POWER5 = $Panel/MainRow/Row3/Row/ItemGrid5/EquipBtn

var axe_buy_btns: Array
var axe_equip_btns: Array
var axe_costs: Array
var axe_multipliers: Array
var power_buy_btns: Array
var power_equip_btns: Array
var power_costs: Array
var power_multipliers: Array
var boost_buy_btns: Array
var boost_item_grids: Array
var boost_costs: Array
var boost_multipliers: Array

# Ownership is separate from the currently equipped item.
var axe_owned: Array[bool] = []
var power_owned: Array[bool] = []

func _ready():
	axe_buy_btns = [BUY_AXE, BUY_AXE2, BUY_AXE3, BUY_AXE4, BUY_AXE5, BUY_AXE6, BUY_AXE7, BUY_AXE8, BUY_AXE9, BUY_AXE10]
	axe_equip_btns = [EQUIP_AXE, EQUIP_AXE2, EQUIP_AXE3, EQUIP_AXE4, EQUIP_AXE5, EQUIP_AXE6, EQUIP_AXE7, EQUIP_AXE8, EQUIP_AXE9, EQUIP_AXE10]
	axe_costs = [AXE_COST, AXE_COST2, AXE_COST3, AXE_COST4, AXE_COST5, AXE_COST6, AXE_COST7, AXE_COST8, AXE_COST9, AXE_COST10]
	axe_multipliers = [1, 5, 15, 50, 75, 150, 300, 1000, 20000, 100000]
	power_buy_btns = [BUY_POWER, BUY_POWER2, BUY_POWER3, BUY_POWER4, BUY_POWER5]
	power_equip_btns = [EQUIP_POWER, EQUIP_POWER2, EQUIP_POWER3, EQUIP_POWER4, EQUIP_POWER5]
	power_costs = [POWER_COST, POWER_COST2, POWER_COST3, POWER_COST4, POWER_COST5]
	power_multipliers = [2, 4, 8, 16, 32]
	boost_buy_btns = [BUY_BOOST, BUY_BOOST2, BUY_BOOST3, BUY_BOOST4, BUY_BOOST5]
	boost_item_grids = [ITEM_GRID, ITEM_GRID2, ITEM_GRID3, ITEM_GRID4, ITEM_GRID5]
	boost_costs = [BOOST_COST, BOOST_COST2, BOOST_COST3, BOOST_COST4, BOOST_COST5]
	boost_multipliers = [2, 4, 8, 16, 32]

	axe_owned.resize(axe_buy_btns.size())
	power_owned.resize(power_buy_btns.size())
	SaveGame.load_game()
	var data = SaveGame.game_data
	var old_axe = clampi(int(SaveGame.game_data.get("axe_owned_tier", SaveGame.game_data.get("axe_tier", 1))), 1, axe_owned.size())
	var old_power = clampi(int(SaveGame.game_data.get("power_owned_tier", SaveGame.game_data.get("power_tier", 0))), 0, power_owned.size())
	var saved_axe = SaveGame.game_data.get("shop1_axe_owned", [])
	var saved_power = SaveGame.game_data.get("shop1_power_owned", [])
	for i in axe_owned.size():
		axe_owned[i] = (i < old_axe)
		if saved_axe is Array and i < saved_axe.size():
			axe_owned[i] = bool(saved_axe[i])
	axe_owned[0] = true
	for i in power_owned.size():
		power_owned[i] = (i < old_power)
		if saved_power is Array and i < saved_power.size():
			power_owned[i] = bool(saved_power[i])
	apply_purchase_state()

func apply_purchase_state():
	# Every unpurchased Shop 1 item shows Buy. Every purchased item keeps Equip.
	# Equipping an older item never makes newer purchased items unpurchased.
	if Wood.axe_tier < 1:
		Wood.axe_tier = 1
	if not axe_owned[0]:
		axe_owned[0] = true
	for i in axe_buy_btns.size():
		axe_buy_btns[i].visible = not axe_owned[i]
		axe_equip_btns[i].visible = axe_owned[i]
		if axe_owned[i]:
			axe_equip_btns[i].text = "Equipped" if i + 1 == Wood.axe_tier else "Equip"
			axe_equip_btns[i].disabled = (i + 1 == Wood.axe_tier)
	if Wood.axe_tier >= 1:
		Wood.multiplier = axe_multipliers[Wood.axe_tier - 1]

	for i in power_buy_btns.size():
		power_buy_btns[i].visible = not power_owned[i]
		power_equip_btns[i].visible = power_owned[i]
		if power_owned[i]:
			power_equip_btns[i].text = "Equipped" if i + 1 == Wood.power_tier else "Equip"
			power_equip_btns[i].disabled = (i + 1 == Wood.power_tier)
	if Wood.power_tier >= 1:
		Wood.multiplier2 = power_multipliers[Wood.power_tier - 1]

	# Shop 1 boosts keep their original one-at-a-time progression.
	for i in boost_item_grids.size():
		boost_item_grids[i].visible = (i == Wood.boost_tier)
	if Wood.boost_tier >= 1:
		Wood.multiplier_add = boost_multipliers[Wood.boost_tier - 1]

func _save_shop1_state():
	SaveGame.game_data["shop1_axe_owned"] = axe_owned.duplicate()
	SaveGame.game_data["shop1_power_owned"] = power_owned.duplicate()
	SaveGame.game_data["axe_owned_tier"] = axe_owned.rfind(true) + 1
	SaveGame.game_data["power_owned_tier"] = power_owned.rfind(true) + 1
	SaveGame.game_data["axe_tier"] = Wood.axe_tier
	SaveGame.game_data["power_tier"] = Wood.power_tier
	SaveGame._write_to_disk()

func _physics_process(_delta):
	for i in axe_buy_btns.size():
		if axe_buy_btns[i].visible and axe_buy_btns[i].is_pressed():
			if Wood.spend_wood(axe_costs[i]):
				axe_owned[i] = true
				Wood.axe_tier = i + 1
				Wood.multiplier = axe_multipliers[i]
				apply_purchase_state()
				_save_shop1_state()
		elif axe_equip_btns[i].visible and axe_equip_btns[i].is_pressed() and axe_owned[i]:
			Wood.axe_tier = i + 1
			Wood.multiplier = axe_multipliers[i]
			apply_purchase_state()
			_save_shop1_state()

	for i in power_buy_btns.size():
		if power_buy_btns[i].visible and power_buy_btns[i].is_pressed():
			if Wood.spend_wood(power_costs[i]):
				power_owned[i] = true
				Wood.power_tier = i + 1
				Wood.multiplier2 = power_multipliers[i]
				apply_purchase_state()
				_save_shop1_state()
		elif power_equip_btns[i].visible and power_equip_btns[i].is_pressed() and power_owned[i]:
			Wood.power_tier = i + 1
			Wood.multiplier2 = power_multipliers[i]
			apply_purchase_state()
			_save_shop1_state()

	for i in boost_buy_btns.size():
		if boost_buy_btns[i].visible and boost_buy_btns[i].is_pressed():
			if Wood.spend_wood(boost_costs[i]):
				boost_buy_btns[i].visible = false
				boost_item_grids[i].visible = false
				if i + 1 < boost_item_grids.size():
					boost_item_grids[i + 1].visible = true
				Wood.multiplier_add = boost_multipliers[i]
				Wood.boost_tier = i + 1
