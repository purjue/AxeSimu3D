extends Panel  # or wherever your OptionsPanel script already lives

# Relative rather than absolute "/root/MAIN/..." — see travel_port.gd for
# why. This script sits on Graphic, 2 levels under MAIN (Graphic -> MainUi
# -> MAIN), so "../../" reaches MAIN.
@onready var world_env: WorldEnvironment = get_node("../../WorldEnvironment")
@onready var env: Environment = world_env.environment
@onready var sun: DirectionalLight3D = get_node("../../DirectionalLight3D")

@onready var LOW_BTN = $GraphicsMode/LowBtn
@onready var HIGH_BTN = $GraphicsMode/HighBtn
@onready var SHADOW_BTN = $GraphicsMode/ShadowBtn

func _ready():
	LOW_BTN.pressed.connect(set_low_graphics)
	HIGH_BTN.pressed.connect(set_high_graphics)
	SHADOW_BTN.pressed.connect(_shadow_on_off)

func set_low_graphics():
	env.glow_enabled = false
	env.fog_enabled = false
	env.volumetric_fog_enabled = false
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_split_1 = 0.2
	sun.directional_shadow_blend_splits = false
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	env.tonemap_exposure = 1.0


func set_high_graphics():
	# Glow
	env.glow_enabled = true
	env.glow_intensity = 0.5
	env.glow_bloom = 0.25


	env.tonemap_mode = Environment.TONE_MAPPER_AGX
	env.tonemap_exposure = 2.0

	# Fog
	env.fog_enabled = false
	env.fog_mode = Environment.FOG_MODE_DEPTH
	env.fog_density = 0.1
	env.fog_sun_scatter = 0.1
	
	#Shadow
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_blend_splits = true
	sun.directional_shadow_split_1 = 0.04
	sun.directional_shadow_split_2 = 0.11
	sun.directional_shadow_split_3 = 0.33
	
func _shadow_on_off():
	sun.shadow_enabled = !sun.shadow_enabled
