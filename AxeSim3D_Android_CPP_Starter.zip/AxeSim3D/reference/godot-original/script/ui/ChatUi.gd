extends CanvasLayer

@onready var INPUT: LineEdit = $Panel/HBox/Input
@onready var SEND_BTN: Button = $Panel/HBox/SendBtn
@onready var REPLY_LABEL: Label = $Panel/ReplyLabel
@onready var PANEL: Panel = $Panel
@onready var CHAT_BTN: Button = $ChatBtn
@onready var CLOSE_BTN: Button = $CloseBtn

const MAX_HISTORY := 200         # old messages you can scroll back through
const SCROLLBAR_WIDTH := 16.0
var chat_scroll: ScrollContainer
var chat_messages: Array[String] = []
var companions: Array[Node] = []

func _ready():
	SEND_BTN.pressed.connect(_on_send)
	INPUT.text_submitted.connect(func(_t): _on_send())
	CHAT_BTN.pressed.connect(_open_chat)
	CLOSE_BTN.pressed.connect(_close_chat)
	call_deferred("_setup_companions")
	_build_scroll()
	_update_chat()

func _setup_companions():
	companions.clear()
	for node in get_tree().get_nodes_in_group("companion"):
		if node != null and is_instance_valid(node):
			companions.append(node)
			if node.has_signal("said"):
				node.said.connect(_on_companion_said.bind(node))

func _open_chat():
	CHAT_BTN.visible = false
	CLOSE_BTN.visible = true
	PANEL.visible = true
	INPUT.grab_focus()
	_scroll_to_bottom()

func _close_chat():
	CHAT_BTN.visible = true
	CLOSE_BTN.visible = false
	PANEL.visible = false

func _on_send():
	var text := INPUT.text.strip_edges()
	if text == "":
		return
	INPUT.text = ""

	_add_message("Me", text)

	if companions.is_empty():
		_setup_companions()
	_route_to_companion(text)

# Say a companion's name (or first name) to talk to only that companion:
#   "pro hi"            -> only Pro Nayak answers
#   "array hi"          -> only Array Nayak answers
#   "pro array follow"  -> both answer
#   "all hi"            -> everybody answers
# A greeting with no name ("hi", "hello") makes ALL companions greet.
const ALL_WORDS := ["all", "everyone", "everybody", "team", "guys"]
const GREETING_ONE := ["hi", "hii", "hiii", "hello", "hey", "heyy", "hiya", "yo", "namaste", "hola", "sup"]
const GREETING_TWO := ["good morning", "good evening", "good afternoon", "good night"]
const SEPARATORS := [" ", ",", ":", ";", "!", "?", ".", "-"]
const GREET_STAGGER := 1.4   # seconds between each companion's greeting

func _route_to_companion(text: String):
	var remaining := text.strip_edges()
	var targets: Array[Node] = []
	var everyone := false

	# 1) Names at the START of the message (several allowed).
	for _i in range(companions.size() + 1):
		var found := _match_leading(remaining)
		if found.is_empty():
			break
		if found["all"]:
			everyone = true
		else:
			for c in found["targets"]:
				if not targets.has(c):
					targets.append(c)
		remaining = found["rest"]

	# 2) A single name at the END: "hi pro".
	if targets.is_empty() and not everyone:
		var tail := _match_trailing(remaining)
		if not tail.is_empty():
			targets.assign(tail["targets"])
			remaining = tail["rest"]

	if everyone:
		targets.assign(companions)

	# 3) No name at all.
	if targets.is_empty():
		if companions.is_empty():
			return
		if _is_greeting(remaining):
			targets.assign(companions)         # "hi" -> everyone greets
		else:
			targets.append(companions[0])      # old behavior for other messages

	var message := remaining if remaining != "" else "hi"
	for i in range(targets.size()):
		var companion: Node = targets[i]
		if i == 0:
			companion.receive_message(message)
		else:
			get_tree().create_timer(GREET_STAGGER * i).timeout.connect(_deliver.bind(companion, message))

func _deliver(companion: Node, message: String) -> void:
	if is_instance_valid(companion):
		companion.receive_message(message)

func _aliases(companion: Node) -> Array[String]:
	var out: Array[String] = []
	var full := _companion_name(companion).to_lower().strip_edges()
	if full != "":
		out.append(full)
		var first: String = full.split(" ")[0]   # "pro nayak" -> "pro"
		if first != "" and not out.has(first):
			out.append(first)
	var node_name := str(companion.name).to_lower()
	if node_name != "" and not out.has(node_name):
		out.append(node_name)
	return out

func _starts_with_word(lower: String, word: String) -> bool:
	if not lower.begins_with(word):
		return false
	if lower.length() == word.length():
		return true
	return SEPARATORS.has(lower.substr(word.length(), 1))

func _strip_leading_separators(s: String) -> String:
	var i := 0
	while i < s.length() and SEPARATORS.has(s.substr(i, 1)):
		i += 1
	return s.substr(i).strip_edges()

func _match_leading(text: String) -> Dictionary:
	var lower := text.to_lower()
	var best_len := 0
	var best_all := false
	var best_targets: Array[Node] = []
	for w in ALL_WORDS:
		if _starts_with_word(lower, w) and w.length() > best_len:
			best_len = w.length()
			best_all = true
	for companion in companions:
		for alias in _aliases(companion):
			if _starts_with_word(lower, alias):
				if alias.length() > best_len:
					best_len = alias.length()
					best_all = false
					best_targets = [companion]
				elif alias.length() == best_len and not best_all and not best_targets.has(companion):
					best_targets.append(companion)
	if best_len == 0:
		return {}
	return {"all": best_all, "targets": best_targets, "rest": _strip_leading_separators(text.substr(best_len))}

func _match_trailing(text: String) -> Dictionary:
	var trimmed := text.strip_edges()
	while trimmed != "" and SEPARATORS.has(trimmed.substr(trimmed.length() - 1, 1)):
		trimmed = trimmed.substr(0, trimmed.length() - 1)
	var lower := trimmed.to_lower()
	var best_len := 0
	var best_targets: Array[Node] = []
	for companion in companions:
		for alias in _aliases(companion):
			if lower.ends_with(" " + alias):
				if alias.length() > best_len:
					best_len = alias.length()
					best_targets = [companion]
				elif alias.length() == best_len and not best_targets.has(companion):
					best_targets.append(companion)
	if best_len == 0:
		return {}
	var rest := trimmed.substr(0, trimmed.length() - best_len).strip_edges()
	return {"targets": best_targets, "rest": rest}

func _is_greeting(text: String) -> bool:
	var cleaned := ""
	for ch in text.to_lower():
		cleaned += ch if (ch >= "a" and ch <= "z") else " "
	var words := cleaned.split(" ", false)
	if words.is_empty():
		return false
	if GREETING_ONE.has(words[0]):
		return true
	return words.size() >= 2 and GREETING_TWO.has(words[0] + " " + words[1])

func _companion_name(companion: Node) -> String:
	if companion.has_method("get_companion_name"):
		return str(companion.get_companion_name())
	var label := companion.get_node_or_null("Name")
	if label is Label3D:
		return str(label.text)
	return str(companion.name)

func _on_companion_said(line: String, companion: Node):
	_add_message(_companion_name(companion), line)

func _add_message(sender: String, message: String):
	var clean_sender := sender.strip_edges()
	var clean_message := message.strip_edges()
	if clean_sender == "" or clean_message == "":
		return

	# Like Roblox chat: new messages scroll into view, but if you scrolled up
	# to read old messages the view stays where you left it. Your own messages
	# always jump to the bottom.
	var stick_to_bottom := _is_at_bottom() or clean_sender == "Me"

	chat_messages.append("%s: %s" % [clean_sender, clean_message])
	while chat_messages.size() > MAX_HISTORY:
		chat_messages.pop_front()
	_update_chat()
	if stick_to_bottom:
		_scroll_to_bottom()

func _update_chat():
	REPLY_LABEL.text = "\n".join(PackedStringArray(chat_messages))

# Puts the message label inside a ScrollContainer (with a visible scroll bar)
# that fills the panel above the input row. Drag with a finger or use the
# mouse wheel / scroll bar to read older messages.
func _build_scroll() -> void:
	var w: float = PANEL.size.x
	if w <= 1.0:
		w = PANEL.offset_right - PANEL.offset_left
	var input_row := PANEL.get_node_or_null("HBox")
	var bottom: float = 196.0
	if input_row != null:
		bottom = float(input_row.offset_top) - 4.0

	chat_scroll = ScrollContainer.new()
	chat_scroll.name = "ChatScroll"
	PANEL.add_child(chat_scroll)
	PANEL.move_child(chat_scroll, 0)
	chat_scroll.offset_left = 4.0
	chat_scroll.offset_top = 4.0
	chat_scroll.offset_right = w - 4.0
	chat_scroll.offset_bottom = maxf(bottom, 60.0)
	chat_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	chat_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_ALWAYS
	chat_scroll.get_v_scroll_bar().custom_minimum_size = Vector2(SCROLLBAR_WIDTH, 0.0)

	REPLY_LABEL.reparent(chat_scroll, false)
	REPLY_LABEL.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	REPLY_LABEL.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	REPLY_LABEL.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	REPLY_LABEL.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	REPLY_LABEL.custom_minimum_size = Vector2(maxf(w - 8.0 - SCROLLBAR_WIDTH - 6.0, 50.0), 0.0)
	REPLY_LABEL.clip_text = false
	REPLY_LABEL.visible = true

func _is_at_bottom() -> bool:
	if chat_scroll == null:
		return true
	var bar := chat_scroll.get_v_scroll_bar()
	return bar.value >= bar.max_value - bar.page - 6.0

func _scroll_to_bottom() -> void:
	if chat_scroll == null:
		return
	# wait for the label to re-layout before jumping to the end
	await get_tree().process_frame
	await get_tree().process_frame
	if chat_scroll != null:
		chat_scroll.scroll_vertical = int(chat_scroll.get_v_scroll_bar().max_value)
