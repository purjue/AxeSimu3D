extends CanvasLayer

@onready var fps_label: Label = $Label  # Make sure this matches your Label node's name

func _process(_delta: float) -> void:
	# Get the current frames per second from Performance engine stats
	var current_fps: int = Performance.get_monitor(Performance.TIME_FPS)
	
	# Update the label text
	fps_label.text = "FPS: %d" % current_fps
