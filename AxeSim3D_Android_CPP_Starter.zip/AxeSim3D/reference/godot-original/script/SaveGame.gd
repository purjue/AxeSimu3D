extends Node

const SAVE_PATH = "user://axe_save.json"

var game_data = {
	"wood_companion": 0,
	"wood": 0,
	"multiplier": 1,
	"multiplier2": 1,
	"multiplier_add": 0,
	"axe_tier": 1,
	"axe_owned_tier": 1,
	"power_tier": 0,
	"power_owned_tier": 0,
	"boost_tier": 0,
	"shop1_axe_owned": [true, false, false, false, false, false, false, false, false, false],
	"shop1_power_owned": [false, false, false, false, false],
	# Shop 2 has completely separate progression IDs so it cannot overwrite Shop 1.
	"shop2_axe_owned_tier": 0,
	"shop2_axe_owned": [],
	"shop2_axe_equipped_tier": 0,
	"shop2_power_owned_tier": 0,
	"shop2_power_owned": [],
	"shop2_power_equipped_tier": 0,
	"shop2_boost_owned_tier": 0,
	"shop2_boost_owned": [],
	"shop2_boost_equipped_tier": 0,
}

# wood_companion carries the AI companion's total delivered wood (see
# WoodCompanion / Wood_companion.gd) — it's included here so it saves as
# part of the same file as the player's own progress, on the same
# triggers (window close, pause, focus-out), rather than needing its own
# separate save call.
func save_game(wood_companion: int, wood: int, mult: int, mult2: int, mult_add: int, axe_tier: int, power_tier: int, boost_tier: int):
	game_data["wood_companion"] = wood_companion
	game_data["wood"] = wood
	game_data["multiplier"] = mult
	game_data["multiplier2"] = mult2
	game_data["multiplier_add"] = mult_add
	game_data["axe_tier"] = axe_tier
	game_data["axe_owned_tier"] = max(int(game_data.get("axe_owned_tier", 1)), axe_tier)
	game_data["power_tier"] = power_tier
	game_data["power_owned_tier"] = max(int(game_data.get("power_owned_tier", 0)), power_tier)
	game_data["boost_tier"] = boost_tier
	_write_to_disk()
	print("Game Saved! Wood: ", wood)


# Shop 2 persistence. This updates ONLY Shop 2 keys and deliberately does not
# touch Shop 1's axe_tier/power_tier/boost_tier values.
func save_shop2_progress(axe_owned_tier: int, axe_equipped_tier: int, power_owned_tier: int, power_equipped_tier: int, boost_owned_tier: int, boost_equipped_tier: int, axe_owned: Array = [], power_owned: Array = [], boost_owned: Array = []):
	game_data["shop2_axe_owned_tier"] = axe_owned_tier
	game_data["shop2_axe_owned"] = axe_owned.duplicate()
	game_data["shop2_axe_equipped_tier"] = axe_equipped_tier
	game_data["shop2_power_owned_tier"] = power_owned_tier
	game_data["shop2_power_owned"] = power_owned.duplicate()
	game_data["shop2_power_equipped_tier"] = power_equipped_tier
	game_data["shop2_boost_owned_tier"] = boost_owned_tier
	game_data["shop2_boost_owned"] = boost_owned.duplicate()
	game_data["shop2_boost_equipped_tier"] = boost_equipped_tier
	_write_to_disk()
	print("Shop 2 progress saved. Skill: ", axe_owned_tier, " Power: ", power_owned_tier, " Boost: ", boost_owned_tier)

# Lets another autoload (like WoodCompanion) persist one of its own
# fields without duplicating the read/write logic here.
func save_field(key: String, value):
	game_data[key] = value
	_write_to_disk()

func _write_to_disk():
	var json_string = JSON.stringify(game_data)
	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	file.store_string(json_string)
	file.close()

func load_game():
	if FileAccess.file_exists(SAVE_PATH):
		var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
		var json_string = file.get_as_text()
		file.close()
		var json = JSON.new()
		if json.parse(json_string) == OK:
			game_data = json.data

			# Migration for older save files that were created before Shop 2.
			# Missing Shop 2 fields are added without changing existing progress.
			var defaults = {
				"shop2_axe_owned_tier": 0,
				"shop2_axe_owned": [],
				"shop2_axe_equipped_tier": 0,
				"shop2_power_owned_tier": 0,
				"shop2_power_owned": [],
				"shop2_power_equipped_tier": 0,
				"shop2_boost_owned_tier": 0,
				"shop2_boost_owned": [],
				"shop2_boost_equipped_tier": 0,
			"axe_owned_tier": 1,
			"power_owned_tier": 0,
			}
			for key in defaults:
				if not game_data.has(key):
					game_data[key] = defaults[key]

			# Shop 1 Noob Skill is always the free starting skill.
			# Older saves that contain 0 are migrated to tier 1.
			game_data["axe_tier"] = clampi(int(game_data.get("axe_tier", 1)), 1, 10)

			# Shop 1 ownership is separate from the currently equipped tier.
			# Old saves used axe_tier/power_tier as both; migrate them as owned.
			game_data["axe_owned_tier"] = clampi(int(game_data.get("axe_owned_tier", game_data.get("axe_tier", 1))), 1, 10)
			game_data["power_owned_tier"] = clampi(int(game_data.get("power_owned_tier", game_data.get("power_tier", 0))), 0, 5)

			# Repair saves created by the earlier Shop 2 bug. If the player has
			# only the free Noob Skill and no Shop 1 power/boost, the correct
			# starting multipliers are exactly 1, 1, and 0.
			if int(game_data.get("axe_tier", 1)) == 1 and int(game_data.get("power_tier", 0)) == 0:
				game_data["multiplier"] = 1
				game_data["multiplier2"] = 1
			if int(game_data.get("boost_tier", 0)) == 0:
				game_data["multiplier_add"] = 0

			print("Game Loaded! Wood: ", game_data.get("wood", 0))
			return game_data
		else:
			print("Save file corrupted, ignoring.")
			return null
	else:
		print("No save file found!")
		return null
