extends Control

var is_loading_Ads = false

@onready var admob : Admob = $Admob
@onready var label : Label = $initialisation



func _on_admob_initialization_completed(status_data: InitializationStatus) -> void:
	label.text = "online"
