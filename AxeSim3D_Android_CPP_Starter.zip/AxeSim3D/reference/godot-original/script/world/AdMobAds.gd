extends Control
## AdMob controller for the "Admob" node that sits inside this scene
## (plugin: "Godot Admob Plugin" - enable it under Project > Project Settings > Plugins).
##
## Put your app ID / ad unit IDs on the Admob node in the Inspector
## (tick "Is Real" for real ads; keep it off while testing).
## Ads only run on a phone: on PC, or if the plugin is missing, the status
## label just says Offline and nothing breaks.

@export var show_banner: bool = true
@export var show_interstitial: bool = true
@export var interstitial_interval_seconds: float = 300.0   # time between full-screen ads (min 30)

var admob: Node = null
var status_label: Label
var elapsed := 0.0
var _initialized := false
var _interstitial_loading := false

func _ready() -> void:
	status_label = get_node_or_null("Status")
	admob = get_node_or_null("Admob")
	if admob == null:
		_set_status("Offline (no Admob node)")
		return
	if not admob.has_method("initialize"):
		_set_status("Offline (Admob plugin not enabled)")
		return
	var os_name := OS.get_name()
	if os_name != "Android" and os_name != "iOS":
		_set_status("Offline (ads run on a phone)")
		return

	_connect_signal("initialization_completed", _on_initialization_completed)
	_connect_signal("banner_ad_loaded", _on_banner_loaded)
	_connect_signal("banner_ad_failed_to_load", _on_banner_failed)
	_connect_signal("interstitial_ad_loaded", _on_interstitial_loaded)
	_connect_signal("interstitial_ad_failed_to_load", _on_interstitial_failed)

	_set_status("Initialising...")
	admob.call("initialize")

func _process(delta: float) -> void:
	if not _initialized or not show_interstitial or _interstitial_loading:
		return
	elapsed += delta
	if elapsed >= maxf(30.0, interstitial_interval_seconds):
		elapsed = 0.0
		_load_interstitial()

# ---------- plugin events ----------

func _on_initialization_completed(_status_data = null) -> void:
	_initialized = true
	_set_status("Online")
	if show_banner:
		_load_banner()
	if show_interstitial:
		_load_interstitial()

func _on_banner_loaded(ad_info = null, _extra = null) -> void:
	var ad_id = _ad_id_of(ad_info)
	if ad_id != "" and admob.has_method("show_banner_ad"):
		admob.call("show_banner_ad", ad_id)

func _on_banner_failed(_ad_info = null, _error = null) -> void:
	_set_status("Online (banner failed to load)")

func _on_interstitial_loaded(ad_info = null, _extra = null) -> void:
	_interstitial_loading = false
	var ad_id = _ad_id_of(ad_info)
	if ad_id != "" and admob.has_method("show_interstitial_ad"):
		admob.call("show_interstitial_ad", ad_id)

func _on_interstitial_failed(_ad_info = null, _error = null) -> void:
	_interstitial_loading = false

# ---------- loading ----------

func _load_banner() -> void:
	var request = _new_global_class("LoadAdRequest")
	if request != null and admob.has_method("load_banner_ad"):
		admob.call("load_banner_ad", request)

func _load_interstitial() -> void:
	var request = _new_global_class("LoadAdRequest")
	if request != null and admob.has_method("load_interstitial_ad"):
		_interstitial_loading = true
		admob.call("load_interstitial_ad", request)

# ---------- helpers ----------

# The plugin's classes (LoadAdRequest, AdInfo ...) are GDScript classes. They are
# looked up by name at run time so this script still loads if the plugin is missing.
func _new_global_class(class_id: String):
	for entry in ProjectSettings.get_global_class_list():
		if str(entry.get("class", "")) == class_id:
			var script = load(str(entry.get("path", "")))
			if script != null:
				return script.new()
	return null

# Newer plugin versions pass an AdInfo object, older ones pass the id string.
func _ad_id_of(ad_info) -> String:
	if ad_info is String:
		return ad_info
	if ad_info != null and ad_info.has_method("get_ad_id"):
		return str(ad_info.call("get_ad_id"))
	return ""

func _connect_signal(signal_name: String, callback: Callable) -> void:
	if admob != null and admob.has_signal(signal_name) and not admob.is_connected(signal_name, callback):
		admob.connect(signal_name, callback)

func _set_status(value: String) -> void:
	if status_label != null:
		status_label.text = value
