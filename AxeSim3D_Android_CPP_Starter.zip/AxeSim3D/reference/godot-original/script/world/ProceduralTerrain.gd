extends Node3D
## 256x256m mobile-friendly HTerrain generator for Axe Simulator 3D.
## Creates a low-poly/rolling off-road island with mountain borders and
## procedurally places extra choppable trees using the existing Tree1 scene node.

@export var world_size_m: float = 256.0
@export var resolution: int = 257
@export var vertical_scale: float = 18.0
@export var terrain_y: float = -1.2
@export var seed: int = 73459
@export var procedural_tree_count: int = 30
@export var tree_min_distance: float = 7.0
## Procedural trees are spawned inside this square (centered on the level origin),
## independent of world_size_m, so they stay near the playable area.
@export var tree_area_m: float = 256.0
@export var tree_max_slope: float = 38.0
@export var hide_old_floor: bool = true
@export var ground_texture: Texture2D
@export var ground_texture_size: int = 128
@export var navigation_grid: int = 24
@export var navigation_max_slope: float = 42.0
@export var shop_flat_search_radius: float = 12.0

var terrain: Node3D
var terrain_data
var noise := FastNoiseLite.new()
var detail_noise := FastNoiseLite.new()
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	_setup_noise()
	_create_terrain()
	call_deferred("_finish_world")

func _setup_noise() -> void:
	noise.seed = seed
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.0065
	noise.fractal_octaves = 4
	noise.fractal_gain = 0.52
	noise.fractal_lacunarity = 2.0

	detail_noise.seed = seed + 991
	detail_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	detail_noise.frequency = 0.018
	detail_noise.fractal_octaves = 3
	detail_noise.fractal_gain = 0.45

	rng.seed = seed

func _create_terrain() -> void:
	var HTerrainScript = load("res://addons/zylann.hterrain/hterrain.gd")
	var HTerrainDataScript = load("res://addons/zylann.hterrain/hterrain_data.gd")
	if HTerrainScript == null or HTerrainDataScript == null:
		push_error("HTerrain addon was not found.")
		return

	terrain = HTerrainScript.new()
	terrain.name = "HTerrain_256x256"
	terrain.map_scale = Vector3(world_size_m / float(resolution - 1), vertical_scale, world_size_m / float(resolution - 1))
	terrain.centered = true
	terrain.position.y = terrain_y
	terrain.chunk_size = 32
	terrain.lod_scale = 2.5
	add_child(terrain)

	terrain_data = HTerrainDataScript.new()
	terrain_data.resize(resolution)

	var height_image: Image = terrain_data.get_image(terrain_data.CHANNEL_HEIGHT)
	for z in resolution:
		var wz := (float(z) / float(resolution - 1) - 0.5) * world_size_m
		for x in resolution:
			var wx := (float(x) / float(resolution - 1) - 0.5) * world_size_m
			var h := _height01(wx, wz)
			height_image.set_pixel(x, z, Color(h, 0.0, 0.0, 1.0))

	terrain_data.notify_full_change()
	terrain.set_data(terrain_data)
	terrain.set_collision_enabled(true)

	_create_ground_texture(terrain)

func _height01(x: float, z: float) -> float:
	var edge_coord := maxf(absf(x), absf(z))
	var half_world := world_size_m * 0.5
	var border := smoothstep(half_world * 0.76, half_world * 0.98, edge_coord)

	# Large rolling landforms.
	var broad := noise.get_noise_2d(x, z) * 0.13
	var detail := detail_noise.get_noise_2d(x, z) * 0.045

	# Keep a winding low off-road route through the playable center.
	var road_center := sin(x * 0.008) * 24.0 + cos(x * 0.0035) * 18.0
	var road_distance := absf(z - road_center)
	var road_cut := (1.0 - smoothstep(10.0, 24.0, road_distance)) * 0.075

	# Mountains form a continuous natural border.
	var mountain_noise := noise.get_noise_2d(x * 0.014 + 300.0, z * 0.014 + 300.0) * 0.16
	var mountains := border * (0.55 + mountain_noise)

	var h := 0.18 + broad + detail + mountains - road_cut
	return clampf(h, 0.02, 0.98)

func _create_ground_texture(t: Node) -> void:
	# Optional inspector texture. If none is assigned, create a small
	# procedural texture once. Keeping this at 128x128 is much cheaper on
	# mobile than a large terrain texture.
	if ground_texture != null:
		var texture_set = t.get_texture_set()
		if texture_set.get_slots_count() == 0:
			texture_set.insert_slot(0)
		texture_set.set_texture(0, texture_set.TYPE_ALBEDO_BUMP, ground_texture)
		t.set_texture_set(texture_set)
		return

	var size := clampi(ground_texture_size, 64, 256)
	var image := Image.create(size, size, false, Image.FORMAT_RGB8)
	var tex_noise := FastNoiseLite.new()
	tex_noise.seed = seed + 444
	tex_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	tex_noise.frequency = 0.035

	for y in size:
		for x in size:
			var n := tex_noise.get_noise_2d(x, y) * 0.5 + 0.5
			var grass := Color(0.20, 0.30, 0.12)
			var dirt := Color(0.28, 0.22, 0.13)
			var rock := Color(0.27, 0.27, 0.23)
			var c: Color
			if n < 0.34:
				c = dirt.lerp(grass, n / 0.34)
			elif n > 0.82:
				c = grass.lerp(rock, (n - 0.82) / 0.18)
			else:
				c = grass
			var grain := 0.92 + fmod(float(x * 17 + y * 31), 29.0) / 290.0
			image.set_pixel(x, y, c * grain)

	var texture := ImageTexture.create_from_image(image)
	var texture_set = t.get_texture_set()
	if texture_set.get_slots_count() == 0:
		texture_set.insert_slot(0)
	texture_set.set_texture(0, texture_set.TYPE_ALBEDO_BUMP, texture)
	t.set_texture_set(texture_set)

func _create_world_border() -> void:
	var old = get_parent().get_node_or_null("WorldBorder")
	if old != null:
		old.queue_free()
	var border := Node3D.new()
	border.name = "WorldBorder"
	get_parent().add_child(border)
	var half := world_size_m * 0.5
	var thickness := 2.0
	var height := 10.0
	var length := world_size_m + thickness * 2.0
	var sides = [
		[Vector3(0, height * 0.5, -half), Vector3(length, height, thickness)],
		[Vector3(0, height * 0.5, half), Vector3(length, height, thickness)],
		[Vector3(-half, height * 0.5, 0), Vector3(thickness, height, length)],
		[Vector3(half, height * 0.5, 0), Vector3(thickness, height, length)]
	]
	for i in range(sides.size()):
		var body := StaticBody3D.new()
		body.name = "Border_%d" % i
		body.position = sides[i][0]
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = sides[i][1]
		shape.shape = box
		body.add_child(shape)
		border.add_child(body)

func _finish_world() -> void:
	if hide_old_floor:
		var floor = get_parent().get_node_or_null("Floor")
		if floor:
			floor.visible = false
			var body = floor.get_node_or_null("StaticBody3D")
			if body:
				body.collision_layer = 0
				body.collision_mask = 0

	# The old baked NavigationRegion was made for the old floor. Disable it
	# and create a lightweight navigation mesh from the exact same procedural
	# height function used by this terrain.
	_disable_old_navigation()
	_create_runtime_navigation()
	_create_world_border()

	_update_existing_trees()
	_spawn_procedural_trees()
	_place_shop_on_terrain()

func _disable_old_navigation() -> void:
	var old_nav := get_parent().get_parent()
	if old_nav is NavigationRegion3D:
		old_nav.enabled = false

func _create_runtime_navigation() -> void:
	# Companions use lightweight steering + obstacle raycasts instead of a
	# 1024x1024 NavigationRegion3D. This avoids baking a huge navmesh and
	# keeps Android performance predictable.
	return

func _wake_companions() -> void:
	await get_tree().physics_frame
	for companion in get_tree().get_nodes_in_group("companion"):
		if companion.has_method("refresh_navigation"):
			companion.refresh_navigation()

func _terrain_normal_at(x: float, z: float) -> Vector3:
	var sample := 0.75
	var h_l := _terrain_height_at_world(x - sample, z)
	var h_r := _terrain_height_at_world(x + sample, z)
	var h_d := _terrain_height_at_world(x, z - sample)
	var h_u := _terrain_height_at_world(x, z + sample)
	return Vector3(h_l - h_r, sample * 2.0, h_d - h_u).normalized()

func _place_shop_on_terrain() -> void:
	var shop := get_parent().get_node_or_null("Shop3D")
	if shop == null:
		return

	var original = shop.position
	var best := Vector2(original.x, original.z)
	var best_score := INF

	# Find a flatter location near the existing shop position.
	for zi in range(9):
		for xi in range(9):
			var x = original.x + (float(xi) / 8.0 - 0.5) * shop_flat_search_radius * 2.0
			var z = original.z + (float(zi) / 8.0 - 0.5) * shop_flat_search_radius * 2.0
			if maxf(absf(x), absf(z)) > world_size_m * 0.5 - 5.0:
				continue
			var n := _terrain_normal_at(x, z)
			var slope := rad_to_deg(acos(clampf(n.dot(Vector3.UP), -1.0, 1.0)))
			var distance_penalty := Vector2(x, z).distance_to(Vector2(original.x, original.z)) * 0.08
			var score := slope + distance_penalty
			if score < best_score:
				best_score = score
				best = Vector2(x, z)

	shop.position = Vector3(best.x, _terrain_height_at_world(best.x, best.y), best.y)
	# Keep the shop upright; real placement means its base follows the ground,
	# while the building itself does not lean with a small terrain slope.

func _terrain_height_at_world(x: float, z: float) -> float:
	return terrain_y + _height01(x, z) * vertical_scale

func _update_existing_trees() -> void:
	var trees_root = get_parent().get_node_or_null("Trees")
	if trees_root == null:
		return
	for child in trees_root.get_children():
		if child.is_in_group("tree"):
			var p = child.position
			p.y = _terrain_height_at_world(p.x, p.z) + 0.03
			child.position = p

func _spawn_procedural_trees() -> void:
	var trees_root = get_parent().get_node_or_null("Trees")
	if trees_root == null:
		return

	var template: Node3D = null
	for child in trees_root.get_children():
		if child.is_in_group("tree") and child.name == "Tree1":
			template = child
			break
	if template == null:
		for child in trees_root.get_children():
			if child.is_in_group("tree"):
				template = child
				break
	if template == null:
		push_warning("No existing tree template found; procedural trees were not spawned.")
		return

	# Remove previously generated trees so changing the inspector count
	# doesn't leave old procedural trees behind.
	for child in trees_root.get_children():
		if str(child.name).begins_with("ProceduralTree_"):
			child.queue_free()

	var placed: Array[Vector3] = []
	for child in trees_root.get_children():
		if child.is_in_group("tree") and not str(child.name).begins_with("ProceduralTree_"):
			placed.append(child.position)

	# Random rejection sampling inside a tree_area_m x tree_area_m square.
	# Respects tree_min_distance and max slope; relaxes the spacing a little
	# if the area is crowded so the requested count is always created.
	var half := minf(tree_area_m, world_size_m) * 0.5
	half = minf(half, world_size_m * 0.45)
	var created := 0
	var attempts := 0
	var min_dist := tree_min_distance
	while created < procedural_tree_count and attempts < procedural_tree_count * 200:
		attempts += 1
		if attempts % 2000 == 0:
			min_dist *= 0.8
		var x := rng.randf_range(-half, half)
		var z := rng.randf_range(-half, half)
		if Vector2(x, z).length() < 20.0:
			continue
		var n := _terrain_normal_at(x, z)
		if rad_to_deg(acos(clampf(n.dot(Vector3.UP), -1.0, 1.0))) > tree_max_slope:
			continue
		var p := Vector3(x, _terrain_height_at_world(x, z), z)
		var too_close := false
		for q in placed:
			if Vector2(p.x - q.x, p.z - q.z).length() < min_dist:
				too_close = true
				break
		if too_close:
			continue

		var tree := template.duplicate()
		tree.name = "ProceduralTree_%03d" % created
		tree.position = p + Vector3.UP * 0.03
		tree.rotation.y = rng.randf_range(0.0, TAU)
		# Multiply the template's own scale instead of replacing it.
		tree.scale = template.scale * rng.randf_range(0.88, 1.12)
		trees_root.add_child(tree)
		placed.append(p)
		created += 1

	print("Procedural trees created: ", created, "/", procedural_tree_count)
	# Make sure the freshly built terrain collider / trees follow the active world.
	var port = get_tree().get_first_node_in_group("travel_port")
	if port != null and port.has_method("refresh_worlds"):
		port.refresh_worlds()
