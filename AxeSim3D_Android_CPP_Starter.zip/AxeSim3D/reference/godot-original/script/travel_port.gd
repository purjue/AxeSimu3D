extends Node3D

var LEVEL2_COST: int = 100000000

@onready var AREA = $Area3D
@onready var TRAVEL_BTN = $Ui/TravelBtn
@onready var CLOSE_BTN = $Ui/CloseBtn

@onready var WORLD_PANEL = $Ui/Worlds
@onready var WORLD1_GO = $"Ui/Worlds/HBoxContainer/World1-Go"
@onready var WORLD2_BUY = $"Ui/Worlds/HBoxContainer/World2-Buy"
@onready var WORLD2_GO = $"Ui/Worlds/HBoxContainer/World2-Go"

# Relative rather than absolute "/root/MAIN/..." paths — those break if
# MAIN ever ends up loaded somewhere other than literally the scene
# tree's root. Nav is a sibling of TravelPort under MAIN either way, so
# ".." always reaches it correctly regardless of where MAIN itself sits.
@onready var LEVEL1 = get_tree().current_scene.find_child("Level-1", true, false)
@onready var LEVEL2 = get_tree().current_scene.find_child("Level-2", true, false)

var current_world: int = 1
var _worlds_ready: bool = false

var looked_at := false

func _ready():
	add_to_group("travel_port")
	AREA.body_entered.connect(_on_body_entered)
	AREA.body_exited.connect(_on_body_exited)
	TRAVEL_BTN.visible = false
	# Deferred so every tree's own _ready() has run (they set up their
	# chop-trigger Area3D there) before this touches them.
	call_deferred("_init_worlds")

func _init_worlds():
	current_world = 2 if LEVEL2.visible and not LEVEL1.visible else 1
	_set_world_active(LEVEL1, current_world == 1)
	_set_world_active(LEVEL2, current_world == 2)
	_worlds_ready = true

# Re-applies the active/inactive state to everything in both worlds. Called by
# ProceduralTerrain after it (re)builds terrain/trees, so nodes created later
# than _init_worlds() are switched off/on correctly too.
func refresh_worlds() -> void:
	if not _worlds_ready:
		return
	_apply_world_state(LEVEL1, current_world == 1)
	_apply_world_state(LEVEL2, current_world == 2)

func _switch_world(world: int):
	if world == current_world:
		return
	current_world = world
	_set_world_active(LEVEL1, world == 1)
	_set_world_active(LEVEL2, world == 2)

# Level-1 and Level-2 sit at the same coordinates, and just hiding one
# (.visible = false) only hides its meshes — its solid bodies and its
# tree chop-triggers stay fully active. That's how an invisible world kept
# blocking the player (and could have its trees chopped). So the inactive
# world is properly switched off here:
#  - solid bodies get their collision layer/mask zeroed (and restored when
#    the world comes back)
#  - trigger areas (tree chop triggers AND shop stalls) stop monitoring, and
#    a shop's buttons/UI are closed, so each world only has its own shop
func _set_world_active(level: Node, active: bool):
	if level is Node3D:
		level.visible = active
	_apply_world_state(level, active)

func _close_shop(stall: Node):
	var ui = stall.get("SHOPUI")
	if ui:
		ui.visible = false
	var open_btn = stall.get("SHOP_BTN")
	if open_btn:
		open_btn.visible = false
	var close_btn = stall.get("SHOP_CLOSE")
	if close_btn:
		close_btn.visible = false
	var player_ui = stall.get("PLAYER_UI")
	if player_ui:
		player_ui.visible = true

func _apply_world_state(node: Node, active: bool):
	# Solid bodies AND trigger areas: zero the layer/mask so the player, the
	# companions and the aim ray can't touch the hidden world. (Areas must be
	# zeroed too, otherwise the aim ray still "sees" the other world's shop
	# and trees.)
	if node is CollisionObject3D:
		if not active:
			if not node.has_meta("_orig_layer"):
				node.set_meta("_orig_layer", node.collision_layer)
				node.set_meta("_orig_mask", node.collision_mask)
			node.set_deferred("collision_layer", 0)
			node.set_deferred("collision_mask", 0)
		elif node.has_meta("_orig_layer"):
			node.set_deferred("collision_layer", node.get_meta("_orig_layer"))
			node.set_deferred("collision_mask", node.get_meta("_orig_mask"))
			node.remove_meta("_orig_layer")
			node.remove_meta("_orig_mask")

	if node is Area3D:
		if not active:
			if not node.has_meta("_orig_monitoring"):
				node.set_meta("_orig_monitoring", node.monitoring)
				node.set_meta("_orig_monitorable", node.monitorable)
			node.set_deferred("monitoring", false)
			node.set_deferred("monitorable", false)
		elif node.has_meta("_orig_monitoring"):
			node.set_deferred("monitoring", node.get_meta("_orig_monitoring"))
			node.set_deferred("monitorable", node.get_meta("_orig_monitorable"))
			node.remove_meta("_orig_monitoring")
			node.remove_meta("_orig_monitorable")

	# HTerrain keeps its collider inside the physics server (it is NOT a
	# CollisionObject3D node), so the zeroing above never touched it. That is
	# why Level-1's ground stayed solid while standing in Level-2 ("walking on
	# air"). Switch the terrain collider on/off explicitly.
	if node.has_method("set_collision_enabled"):
		node.set_collision_enabled(active)

	if not active:
		# tree.gd / tree2.gd: forget that the player was in range
		if "is_visible_tree" in node and "player_in_range" in node:
			node.player_in_range = false
		# Shop stalls: their Shop/Close buttons and shop UI are CanvasLayers,
		# which do NOT get hidden when the 3D world above them is hidden.
		if "SHOPUI" in node and "SHOP_BTN" in node:
			_close_shop(node)

	for child in node.get_children():
		_apply_world_state(child, active)

func set_looked_at(value: bool) -> void:
	looked_at = value
	if WORLD_PANEL.visible or CLOSE_BTN.visible:
		return
	TRAVEL_BTN.visible = value

func _on_body_entered(_body):
	# The travel button is controlled by the player's aim ray.
	pass

func _on_body_exited(_body):
	if not WORLD_PANEL.visible:
		TRAVEL_BTN.visible = false

func _physics_process(_delta):
	if TRAVEL_BTN.is_pressed():
		WORLD_PANEL.visible = true
		TRAVEL_BTN.visible = false
		CLOSE_BTN.visible = true
		
	if CLOSE_BTN.is_pressed():
		WORLD_PANEL.visible = false
		TRAVEL_BTN.visible = looked_at
		CLOSE_BTN.visible = false
		
	if WORLD1_GO.is_pressed():
		WORLD_PANEL.visible = false
		TRAVEL_BTN.visible = looked_at
		CLOSE_BTN.visible = false
		_switch_world(1)
		
	if WORLD2_BUY.is_pressed():
		if Wood.spend_wood(LEVEL2_COST):
			WORLD2_GO.visible = true
			WORLD2_BUY.visible = false
			
	if WORLD2_GO.is_pressed():
		WORLD_PANEL.visible = false
		TRAVEL_BTN.visible = looked_at
		CLOSE_BTN.visible = false
		_switch_world(2)
