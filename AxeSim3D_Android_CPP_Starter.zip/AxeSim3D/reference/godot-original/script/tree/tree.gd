extends Node3D

@export var respawn_time: float = 10.0
@export var wood_cooldown: float = 10.0

@onready var area = $Area3D
@onready var trunk_collision: CollisionShape3D = $TreeMesh/StaticBody3D/CollisionShape3D
var player_in_range = false
var last_wood_time: float = 0.0
var is_visible_tree: bool = true

# Relative rather than absolute "/root/MAIN/..." — see travel_port.gd for
# why. A tree sits 4 levels under MAIN (Tree -> Trees -> Level-1 -> Nav ->
# MAIN), so "../../../../" reaches MAIN.


func _ready():
	area.body_entered.connect(_on_body_entered)
	area.body_exited.connect(_on_body_exited)
	add_to_group("tree")
	last_wood_time = Time.get_ticks_msec()

const COMPANION_CHOP_RANGE := 2.4   # metres (companions stop ~1.35m from the trunk)

func _process(_delta):
	# A companion chops this tree once it is close to it and it is the tree
	# the companion is working on. (The old rule needed the companion's body to
	# overlap the Area3D AND a perfect line-of-sight ray, which very often
	# failed, so companions stood at the tree and then gave up.)
	if is_visible_tree and is_visible_in_tree():
		for body in get_tree().get_nodes_in_group("companion"):
			if not is_instance_valid(body) or body.get("current_target_tree") != self:
				continue
			var dx: float = body.global_position.x - global_position.x
			var dz: float = body.global_position.z - global_position.z
			if sqrt(dx * dx + dz * dz) > COMPANION_CHOP_RANGE:
				continue
			if body.has_method("can_see_tree") and not body.can_see_tree(self):
				continue
			companion_chop(body)
			break

	# Keep the old player-in-range state for compatibility with other systems.
	if is_visible_tree and player_in_range:
		var current_time = Time.get_ticks_msec()
		if current_time - last_wood_time >= wood_cooldown * 1000:
			last_wood_time = current_time

func _on_body_entered(body):
	if body.is_in_group("player"):
		player_in_range = true
	elif body.is_in_group("companion"):
		# Actual chopping is handled in _process after a sight-ray check.
		pass

func _on_body_exited(body):
	if body.is_in_group("player"):
		player_in_range = false

func chop():
	if not player_in_range or not is_visible_tree:
		return
	is_visible_tree = false
	await get_tree().create_timer(1.0).timeout
	Wood.add_wood(2)
	hide()
	trunk_collision.disabled = true
	await get_tree().create_timer(respawn_time).timeout
	respawn()

# Player chop is controlled by the camera AxeRayCast3D. It does not
# require the old Area3D proximity check: if the axe ray is actually
# colliding with this tree and the player presses CHOP, this tree is cut.
func chop_from_player(_player: Node = null) -> void:
	if not is_visible_tree:
		return
	is_visible_tree = false
	await get_tree().create_timer(1.0).timeout
	Wood.add_wood(2)
	hide()
	trunk_collision.disabled = true
	await get_tree().create_timer(respawn_time).timeout
	respawn()

# Auto-chop when the companion walks into range — no button press needed.
# Gives the companion its own flat, local wood total instead of touching
# the global Wood pool directly (that happens later, when it visits the shop).
func companion_chop(companion_node):
	if not is_visible_tree:
		return
	is_visible_tree = false
	if companion_node.has_method("play_chop_animation"):
		companion_node.play_chop_animation()
	await get_tree().create_timer(1.0).timeout
	if companion_node.has_method("receive_wood"):
		companion_node.receive_wood(2)
	hide()
	trunk_collision.disabled = true
	await get_tree().create_timer(respawn_time).timeout
	respawn()

func respawn():
	is_visible_tree = true
	trunk_collision.disabled = false
	show()
	last_wood_time = Time.get_ticks_msec()
