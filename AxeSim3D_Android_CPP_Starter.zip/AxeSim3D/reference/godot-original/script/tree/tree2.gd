extends Node3D

@export var respawn_time: float = 10.0
@export var wood_cooldown: float = 10.0
# World 2 trees are stronger: the player gets 1000 wood per chop (see chop()),
# and the companion's delivery is worth this many times a World 1 tree.
@export var companion_power: int = 1000

@onready var area = $Area3D
@onready var trunk_collision: CollisionShape3D = $StaticBody3D/CollisionShape3D
var player_in_range = false
var last_wood_time: float = 0.0
var is_visible_tree: bool = true

func _ready():
	area.body_entered.connect(_on_body_entered)
	area.body_exited.connect(_on_body_exited)
	add_to_group("tree")
	last_wood_time = Time.get_ticks_msec()

func _process(_delta):
	# Only give wood if tree is VISIBLE and player is in range
	if is_visible_tree and player_in_range:
		var current_time = Time.get_ticks_msec()
		if current_time - last_wood_time >= wood_cooldown * 1000:
			last_wood_time = current_time

func _on_body_entered(body):
	if body.is_in_group("player"):
		player_in_range = true
	elif body.is_in_group("companion"):
		companion_chop(body)

func _on_body_exited(body):
	if body.is_in_group("player"):
		player_in_range = false

func chop():
	if not player_in_range or not is_visible_tree:
		return
	is_visible_tree = false
	await get_tree().create_timer(1.0).timeout
	Wood.add_wood(2000)
	hide()
	trunk_collision.disabled = true
	await get_tree().create_timer(respawn_time).timeout
	respawn()

# Auto-chop when the companion walks into range — no button press needed.
# Gives the companion its own flat, local wood total instead of touching
# the global Wood pool directly (that happens later, when it visits the shop).
func companion_chop(companion_node):
	if not is_visible_tree:
		return
	is_visible_tree = false
	if companion_node.has_method("play_chop_animation"):
		companion_node.play_chop_animation()
	await get_tree().create_timer(1.0).timeout
	if companion_node.has_method("receive_wood"):
		companion_node.receive_wood(20, companion_power)
	hide()
	trunk_collision.disabled = true
	await get_tree().create_timer(respawn_time).timeout
	respawn()

func respawn():
	is_visible_tree = true
	trunk_collision.disabled = false
	show()
	last_wood_time = Time.get_ticks_msec()
