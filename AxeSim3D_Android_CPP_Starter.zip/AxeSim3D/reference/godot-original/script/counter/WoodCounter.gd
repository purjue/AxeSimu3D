extends Panel

const NumberFormat = preload("res://script/counter/NumberFormat.gd")

@onready var wood_label = $WoodLabel

func _ready():
	# Connect to Wood autoload signal
	Wood.wood_changed.connect(_on_wood_changed)
	# Set initial value
	_on_wood_changed(Wood.wood)

func _on_wood_changed(new_amount: int):
	wood_label.text = NumberFormat.abbreviate(new_amount)
