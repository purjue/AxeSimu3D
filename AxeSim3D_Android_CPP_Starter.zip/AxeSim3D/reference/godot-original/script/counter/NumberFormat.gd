extends RefCounted

# Shortens big numbers for the wood counters:
#   1, 10, 100, 1k, 10k, 100k, 1M, 10M, 100M, 1B, 10B, 100B,
#   1T, 10T, 100T, 1Qd, 10Qd, 100Qd, then 9 more steps:
#   Qn (quintillion), Sx (sextillion), Sp (septillion), Oc (octillion),
#   No (nonillion), Dc (decillion), Ud (undecillion), Dd (duodecillion),
#   Td (tredecillion).
#
# In-between values show up to 2 decimals (1.5k, 12.34M). Decimals are cut
# off, never rounded up, so 999,999 shows as 999.99k and never "1000k".
#
# Use it with:
#   const NumberFormat = preload("res://script/counter/NumberFormat.gd")
#   label.text = NumberFormat.abbreviate(amount)

const SUFFIXES = ["", "k", "M", "B", "T", "Qd", "Qn", "Sx", "Sp", "Oc", "No", "Dc", "Ud", "Dd", "Td"]

static func abbreviate(value) -> String:
	var v: float = float(value)
	var negative = v < 0.0
	v = absf(v)

	var idx = 0
	while v >= 1000.0 and idx < SUFFIXES.size() - 1:
		v /= 1000.0
		idx += 1

	var text: String
	if idx == 0:
		text = str(int(v))
	else:
		var truncated = floor(v * 100.0) / 100.0
		text = ("%.2f" % truncated).rstrip("0").rstrip(".")

	return ("-" if negative else "") + text + SUFFIXES[idx]
