extends Node

## Independent wood/progression storage for Pranjal Nayak.
## This companion deliberately uses its own save file:
## user://companion_1_save.json
signal wood_changed_companion(new_amount)

const MAX_WOOD: int = 9223372036854775807

var wood_companion: int = 0
const SAVE_PATH := "user://companion_1_save.json"

func _ready():
	load_progress()

func add_wood_companion(amount: int = 1):
	if amount <= 0:
		return
	if wood_companion >= MAX_WOOD - amount:
		wood_companion = MAX_WOOD
	else:
		wood_companion += amount
	wood_changed_companion.emit(wood_companion)
	save_progress()

func spend_wood_companion(amount: int) -> bool:
	if amount < 0 or wood_companion < amount:
		return false
	wood_companion -= amount
	wood_changed_companion.emit(wood_companion)
	save_progress()
	return true

func save_progress():
	var data = {
		"wood_companion": wood_companion,
	}
	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.close()

func load_progress():
	if not FileAccess.file_exists(SAVE_PATH):
		# Companion 1 keeps the old companion balance once, then moves to its
		# independent save file. Companions 2-4 start independently at zero.
		if 1 == 1:
			var old_path := "user://axe_save.json"
			if FileAccess.file_exists(old_path):
				var old_file = FileAccess.open(old_path, FileAccess.READ)
				if old_file:
					var parsed = JSON.parse_string(old_file.get_as_text())
					old_file.close()
					if parsed is Dictionary:
						wood_companion = int(parsed.get("wood_companion", 0))
						save_progress()
		wood_changed_companion.emit(wood_companion)
		return

	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if parsed is Dictionary:
		wood_companion = max(0, int(parsed.get("wood_companion", 0)))
	wood_changed_companion.emit(wood_companion)
