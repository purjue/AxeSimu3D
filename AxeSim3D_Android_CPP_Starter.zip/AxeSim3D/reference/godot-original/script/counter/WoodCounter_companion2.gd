extends Node3D

const NumberFormat = preload("res://script/counter/NumberFormat.gd")
@onready var wood_label: Label3D = $WoodLabel
@export var companion_index: int = 2

func _ready():
	call_deferred("_connect_to_companion")

func _connect_to_companion():
	var companion = get_parent()
	if companion == null:
		return
	var wood_system = companion.get("wood_system")
	if wood_system == null:
		return
	if not wood_system.wood_changed_companion.is_connected(_on_wood_changed):
		wood_system.wood_changed_companion.connect(_on_wood_changed)
	_on_wood_changed(wood_system.wood_companion)

func _on_wood_changed(new_amount: int):
	wood_label.text = NumberFormat.abbreviate(new_amount)
