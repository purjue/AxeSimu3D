extends Node3D

const NumberFormat = preload("res://script/counter/NumberFormat.gd")

@onready var wood_label = $WoodLabel

func _ready():
	# Connect to Wood autoload signal
	WoodCompanion.wood_changed_companion.connect(_on_wood_changed)
	# Set initial value
	_on_wood_changed(WoodCompanion.wood_companion)

func _on_wood_changed(new_amount: int):
	wood_label.text = NumberFormat.abbreviate(new_amount)
