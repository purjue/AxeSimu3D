extends Node

signal wood_changed(new_amount)

# Godot int is a signed 64-bit integer. Keep wood from overflowing and
# wrapping around into a negative number.
const MAX_WOOD: int = 9223372036854775807

var wood: int = 0
var multiplier: int = 1
var multiplier2: int = 1
var multiplier_add: int = 0

# Which tier of each upgrade is currently owned/equipped.
# axe_tier starts at 1 because the Noob Skill is the free starting skill.
var axe_tier: int = 1
var power_tier: int = 0
var boost_tier: int = 0

func _safe_multiply(a: int, b: int) -> int:
	if a <= 0 or b <= 0:
		return 0
	if a > MAX_WOOD / b:
		return MAX_WOOD
	return a * b

func _safe_add(a: int, b: int) -> int:
	if b <= 0:
		return a
	if a >= MAX_WOOD - b:
		return MAX_WOOD
	return a + b

func add_wood(amount: int = 1):
	if amount <= 0:
		return

	var power_and_boost := _safe_add(multiplier2, multiplier_add)
	var total := _safe_multiply(amount, multiplier)
	total = _safe_multiply(total, power_and_boost)

	wood = _safe_add(wood, total)
	wood_changed.emit(wood)

func spend_wood(amount: int) -> bool:
	if amount < 0 or wood < amount:
		return false
	wood -= amount
	wood_changed.emit(wood)
	return true
