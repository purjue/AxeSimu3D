# AxeSim3D — Android C++ starter

**Credit:** Made by Pranjal Nayak

This is a native Android project using C++17 and OpenGL ES 2.0 through JNI. The project name, Android package, launcher label, mobile controls, persistent save data and GitHub Actions APK workflow are configured.

## Included

- Landscape Android app with a 3D island prototype, player, trees and a shop stall.
- Touch joystick, jump and axe-swing controls.
- Chop trees to earn wood; trees disappear after three hits.
- Two shop tabs with the item prices and multiplier values read from the supplied `shop_ui.gd`, `shop_ui_2.gd`, and `Wood.gd`.
- Buy/equip state, boost progression, 64-bit wood amounts with saturating arithmetic.
- Low/Balanced/High quality selector.
- Save button, load option and save attempt when the app is backgrounded.
- Supplied `axe.glb`, `pine_tree_low-poly.glb`, `food_stall_in_edo.glb`, ground texture and icon are bundled under `app/src/main/assets/models/`.
- Original supplied Godot scripts/scenes are retained under `reference/godot-original/` and `reference/original-godot-project-files.zip` for porting reference.
- GitHub Actions workflow: `.github/workflows/android-apk.yml`.

## Build APK with GitHub Actions

1. Create a new GitHub repository and upload the contents of this folder (the files inside `AxeSim3D`, not the enclosing folder).
2. Open **Actions** and enable workflows if GitHub asks.
3. Select **Build AxeSim3D APK** and press **Run workflow**, or push to `main`/`master`.
4. Open the completed workflow run and download the `AxeSim3D-debug-apk` artifact.
5. Extract it and install `app-debug.apk` on an Android device. For installation, enable permission to install apps from the app you use to open the APK.

## Open in Android Studio

Open this folder as a Gradle project. Install Android SDK Platform 35, Build Tools 35.0.0, NDK 27.2.12479018 and CMake 3.22.1, then run `assembleDebug`.

## Important scope note

This is a **first playable C++ porting starter**, not a finished 1:1 conversion of the Godot project. The current native renderer draws placeholder geometry for the player, trees and stall; the supplied GLB models are included but are not yet loaded by the C++ renderer. The original Godot animation rig, exact camera/raycast targeting, detailed terrain, realistic dynamic shadows, and every original shop label/ownership detail still need a proper model/animation importer and further porting/testing. The included axe swing is a simple procedural prototype animation. An APK has not been compiled or device-tested in this environment; GitHub Actions is configured to perform the Android build.
