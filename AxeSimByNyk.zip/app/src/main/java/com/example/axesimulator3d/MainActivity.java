package com.example.axesimulator3d;

import android.app.NativeActivity;

/** Main Android activity for the native C++ game. Ads have been removed. */
public class MainActivity extends NativeActivity {
}
