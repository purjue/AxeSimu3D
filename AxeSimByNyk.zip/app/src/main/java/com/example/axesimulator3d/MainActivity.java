package com.example.axesimulator3d;

import android.app.NativeActivity;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Main Android activity for the native C++ game. The game itself is C++; this class only plays the sounds.
 *
 * The C++ code (android_main.cpp) calls playSound(id, volume, speed). The ids are the order of SOUNDS below,
 * which is the same order as AxeSim::Sfx in axe_sim.h. The files are in app/src/main/assets/sounds/.
 * The ambient loop (wind, leaves, birds) starts by itself when the game opens.
 */
public class MainActivity extends NativeActivity {
    private static final String TAG = "AxeSimSound";

    // same order as AxeSim::Sfx: chop, jump, land, 3 walking steps, 3 running steps
    private static final String[] SOUNDS = {"chop", "jump", "land", "step1", "step2", "step3", "run1", "run2", "run3"};
    private static final String AMBIENT = "ambient";
    private static final float AMBIENT_VOLUME = 0.35f;

    private SoundPool pool;
    private final int[] soundIds = new int[SOUNDS.length];
    private final boolean[] soundReady = new boolean[SOUNDS.length];
    private int ambientId = 0;
    private boolean ambientStarted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            initSound();
        } catch (RuntimeException e) {
            Log.w(TAG, "Sound is not available: " + e);   // the game still works, just without sound
            pool = null;
        }
    }

    private void initSound() {
        final AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        pool = new SoundPool.Builder().setMaxStreams(12).setAudioAttributes(attrs).build();
        pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
                if (status != 0) return;
                for (int i = 0; i < soundIds.length; i++) if (soundIds[i] == sampleId) soundReady[i] = true;
                if (sampleId == ambientId && !ambientStarted) {
                    ambientStarted = true;
                    soundPool.play(ambientId, AMBIENT_VOLUME, AMBIENT_VOLUME, 0, -1, 1.0f);   // loop forever
                }
            }
        });
        for (int i = 0; i < SOUNDS.length; i++) soundIds[i] = loadSound(SOUNDS[i]);
        ambientId = loadSound(AMBIENT);
    }

    private int loadSound(String name) {
        final String path = "sounds/" + name + ".wav";
        try {
            final AssetFileDescriptor afd = getAssets().openFd(path);
            final int id = pool.load(afd, 1);
            afd.close();
            return id;
        } catch (Exception first) {
            try {   // the file was stored compressed in the APK: copy it out and load it from there
                final File out = new File(getCacheDir(), name + ".wav");
                final InputStream in = getAssets().open(path);
                final OutputStream os = new FileOutputStream(out);
                final byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                os.close();
                in.close();
                return pool.load(out.getAbsolutePath(), 1);
            } catch (Exception second) {
                Log.w(TAG, "Could not load " + path + ": " + second);
                return 0;
            }
        }
    }

    /** Called from C++ (on the game thread). volumePercent 0..100, speedPercent 50..200 (100 = normal pitch). */
    public void playSound(int index, int volumePercent, int speedPercent) {
        final SoundPool p = pool;
        if (p == null || index < 0 || index >= soundIds.length || !soundReady[index]) return;
        final float volume = Math.max(0f, Math.min(1f, volumePercent / 100f));
        final float rate = Math.max(0.5f, Math.min(2f, speedPercent / 100f));
        p.play(soundIds[index], volume, volume, 1, 0, rate);
    }

    @Override
    protected void onPause() {
        if (pool != null) pool.autoPause();     // silence while the game is in the background
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pool != null) pool.autoResume();
    }

    @Override
    protected void onDestroy() {
        if (pool != null) {
            pool.release();
            pool = null;
        }
        super.onDestroy();
    }
}
