// game_numbers.h - how big numbers are shown, and the odds of the wood-price spinner.
// Nothing in here touches the game or the GPU, so it can be tested on its own.
#pragma once
#include <cmath>
#include <cstdio>
#include <random>
#include <string>

namespace gnum {

// "1.50" -> "1.5",  "2.00" -> "2"
inline std::string trimZeros(std::string s) {
    if (s.find('.') != std::string::npos) {
        while (!s.empty() && s.back() == '0') s.pop_back();
        if (!s.empty() && s.back() == '.') s.pop_back();
    }
    return s;
}

// The name of each step of three zeros: 1 = k, 2 = M, 3 = B, 4 = T, 5 = Qa ... 21 = Vg (1e63).
// After that come aa, ab, ac ... az, ba ... (enough to go past 1e300). Add more names to the list to extend it.
inline std::string suffix(int g) {
    static const char* const names[] = {"", "k", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No",
                                        "Dc", "Ud", "Dd", "Td", "Qad", "Qid", "Sxd", "Spd", "Ocd", "Nod", "Vg"};
    const int named = (int)(sizeof(names) / sizeof(names[0]));
    if (g < 0) g = 0;
    if (g < named) return names[g];
    const int k = g - named;   // 0 = aa, 1 = ab ... 25 = az, 26 = ba ...
    std::string s;
    s += (char)('a' + (k / 26) % 26);
    s += (char)('a' + k % 26);
    return s;
}

// 10 -> 100 -> 1k -> 1.5k -> 12.3k -> 123k -> 1.23M -> 1B -> 1T -> 1Qa ...   Used for every coin, wood and price number.
inline std::string format(double v) {
    if (!(v > 0.0)) return v < 0.0 ? "-" + format(-v) : "0";   // zero (and NaN)
    if (std::isinf(v)) return "INF";
    char b[48];
    if (v < 999.995) {   // under 1k: whole numbers plain, fractions with up to 2 decimals (7.5, 11.25)
        const double r = std::floor(v + 0.5);
        if (std::fabs(v - r) < 0.005) std::snprintf(b, sizeof b, "%.0f", r);
        else std::snprintf(b, sizeof b, "%.2f", v);
        return trimZeros(b);
    }
    int g = (int)std::floor(std::log10(v) / 3.0);
    if (g < 1) g = 1;
    double m = v / std::pow(1000.0, g);          // 1 .. 999.99
    if (m >= 999.5) { m /= 1000.0; g++; }       // 999.7k is shown as 1M, not 1000k
    const char* fmt = m < 10.0 ? "%.2f" : (m < 100.0 ? "%.1f" : "%.0f");
    std::snprintf(b, sizeof b, fmt, m);
    return trimZeros(b) + suffix(g);
}

// 28200 -> "28.2",  50 -> "0.05"   (a spinner weight as a percentage)
inline std::string percent(int weight) {
    char b[24];
    std::snprintf(b, sizeof b, "%.2f", weight / 1000.0);
    return trimZeros(b);
}

}  // namespace gnum

// ---- the wood-price spinner ----------------------------------------------------------------------------------------
// One spin lands on one of these multipliers. weight is out of 100000, so the bigger the multiplier the rarer it is:
// x1.5 comes up in 28.2% of spins, x10000 in only 0.05% (about 1 spin in 2000).
struct SpinTier { double mult; int weight; };
constexpr int kSpinTiers = 14;
inline const SpinTier* spinTiers() {
    static const SpinTier t[kSpinTiers] = {
        {1.5, 28200}, {2, 22000}, {3, 16000}, {5, 11000}, {10, 8000}, {25, 5500}, {50, 3500},
        {100, 2500}, {250, 1500}, {500, 900}, {1000, 500}, {2500, 250}, {5000, 100}, {10000, 50}};
    return t;
}
// Picks a tier number (0 .. kSpinTiers-1) at random using the weights above.
template <class Rng>
inline int rollSpinTier(Rng& rng) {
    const int r = std::uniform_int_distribution<int>(0, 99999)(rng);
    int acc = 0;
    for (int i = 0; i < kSpinTiers; i++) {
        acc += spinTiers()[i].weight;
        if (r < acc) return i;
    }
    return 0;
}
