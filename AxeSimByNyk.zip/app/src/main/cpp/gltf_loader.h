// gltf_loader.h - reads .glb files (binary glTF 2.0): meshes, materials, textures, node transforms.
// No OpenGL in here, so it can be tested anywhere. Include it AFTER engine.cpp.
//
// Textures (PNG/JPG inside the .glb) are decoded with stb_image.h when that file sits next to this
// one. The GitHub build downloads it automatically. Without it, models still load, just untextured.
#pragma once

#if __has_include("stb_image.h")
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_NO_STDIO
#include "stb_image.h"
#define HAVE_STB_IMAGE 1
#endif

// ---------------------------------------------------------------- model data (CPU side)
struct MeshData {
    std::vector<float> v;        // 8 floats per vertex: position(3) normal(3) uv(2)
    std::vector<uint32_t> idx;   // triangles
};
struct ImageData { int w = 0, h = 0; std::vector<uint8_t> rgba; };
struct MatData {                 // glTF metallic-roughness material
    Vec3 base{1, 1, 1}; float alpha = 1, metal = 1, rough = 1;
    Vec3 emissive{0, 0, 0};
    int texBase = -1, texNormal = -1, texMR = -1, texEmis = -1;  // indexes into ModelData::images
    bool mask = false, dbl = false; float cut = 0.5f;
};
struct PartData { MeshData mesh; Mat4 world; int mat = -1; };
struct ModelData {
    std::vector<PartData> parts;
    std::vector<MatData> mats;
    std::vector<ImageData> images;
    Vec3 lo, hi;                 // bounding box after the node transforms
};

// Turns one of our basic shapes into vertices with normals. Edges sharper than "creaseDeg"
// stay sharp (cube corners); smoother ones are blended (sphere).
inline MeshData buildMeshData(const Mesh& m, float creaseDeg = 55.f) {
    MeshData d;
    size_t nt = m.tris.size();
    std::vector<Vec3> fn(nt);
    std::vector<std::vector<int>> adj(m.verts.size());
    for (size_t t = 0; t < nt; t++) {
        const Triangle& tr = m.tris[t];
        fn[t] = cross(m.verts[tr.b] - m.verts[tr.a], m.verts[tr.c] - m.verts[tr.a]);
        adj[tr.a].push_back((int)t); adj[tr.b].push_back((int)t); adj[tr.c].push_back((int)t);
    }
    float cosT = std::cos(radians(creaseDeg));
    uint32_t next = 0;
    for (size_t t = 0; t < nt; t++) {
        Vec3 own = normalize(fn[t]);
        const int corner[3] = {m.tris[t].a, m.tris[t].b, m.tris[t].c};
        for (int vi : corner) {
            Vec3 sum = fn[t];
            for (int u : adj[vi])
                if (u != (int)t && dot(normalize(fn[u]), own) > cosT) sum += fn[u];
            Vec3 n = normalize(sum);
            if (length(n) < 0.5f) n = Vec3(0, 1, 0);
            const Vec3& p = m.verts[vi];
            d.v.insert(d.v.end(), {p.x, p.y, p.z, n.x, n.y, n.z, 0.f, 0.f});
            d.idx.push_back(next++);
        }
    }
    return d;
}

// ---------------------------------------------------------------- tiny JSON reader
struct JV {
    enum Type { NUL, BOOL, NUM, STR, ARR, OBJ } t = NUL;
    double n = 0; bool b = false; std::string s;
    std::vector<JV> a;
    std::vector<std::pair<std::string, JV>> o;
    const JV* get(const char* k) const {
        if (t != OBJ) return nullptr;
        for (auto& kv : o) if (kv.first == k) return &kv.second;
        return nullptr;
    }
    double num(const char* k, double def) const { const JV* v = get(k); return (v && v->t == NUM) ? v->n : def; }
    int count() const { return (int)a.size(); }
};

class JsonParser {
public:
    JsonParser(const char* b, const char* e) : p_(b), e_(e) {}
    bool parse(JV& out) { return value(out, 0); }
private:
    const char *p_, *e_;
    void ws() { while (p_ < e_ && (*p_ == ' ' || *p_ == '\n' || *p_ == '\r' || *p_ == '\t')) p_++; }
    bool lit(const char* w) {
        size_t n = std::strlen(w);
        if ((size_t)(e_ - p_) >= n && !std::strncmp(p_, w, n)) { p_ += n; return true; }
        return false;
    }
    bool str(std::string& out) {
        if (p_ >= e_ || *p_ != '"') return false;
        p_++; out.clear();
        while (p_ < e_ && *p_ != '"') {
            char c = *p_++;
            if (c == '\\' && p_ < e_) {
                char d = *p_++;
                if (d == 'n') out += '\n'; else if (d == 't') out += '\t'; else if (d == 'r') out += '\r';
                else if (d == 'u' && e_ - p_ >= 4) { unsigned v = (unsigned)std::strtoul(std::string(p_, 4).c_str(), nullptr, 16); p_ += 4; out += v < 128 ? (char)v : '?'; }
                else out += d;
            } else out += c;
        }
        if (p_ >= e_) return false;
        p_++;
        return true;
    }
    bool value(JV& v, int depth) {
        ws();
        if (depth > 64 || p_ >= e_) return false;
        char c = *p_;
        if (c == '{') {
            p_++; v.t = JV::OBJ; ws();
            if (p_ < e_ && *p_ == '}') { p_++; return true; }
            for (;;) {
                ws(); std::string k;
                if (!str(k)) return false;
                ws();
                if (p_ >= e_ || *p_ != ':') return false;
                p_++;
                JV child;
                if (!value(child, depth + 1)) return false;
                v.o.emplace_back(std::move(k), std::move(child));
                ws();
                if (p_ >= e_) return false;
                if (*p_ == ',') { p_++; continue; }
                if (*p_ == '}') { p_++; return true; }
                return false;
            }
        }
        if (c == '[') {
            p_++; v.t = JV::ARR; ws();
            if (p_ < e_ && *p_ == ']') { p_++; return true; }
            for (;;) {
                JV child;
                if (!value(child, depth + 1)) return false;
                v.a.push_back(std::move(child));
                ws();
                if (p_ >= e_) return false;
                if (*p_ == ',') { p_++; continue; }
                if (*p_ == ']') { p_++; return true; }
                return false;
            }
        }
        if (c == '"') { v.t = JV::STR; return str(v.s); }
        if (lit("true")) { v.t = JV::BOOL; v.b = true; return true; }
        if (lit("false")) { v.t = JV::BOOL; v.b = false; return true; }
        if (lit("null")) { v.t = JV::NUL; return true; }
        char* end = nullptr;
        v.n = std::strtod(p_, &end);
        if (end == p_) return false;
        p_ = end; v.t = JV::NUM;
        return true;
    }
};

// ---------------------------------------------------------------- .glb loader
inline Mat4 gltfNodeMatrix(const JV& node) {
    Mat4 r;
    if (const JV* m = node.get("matrix")) {
        if (m->count() == 16)
            for (int c = 0; c < 4; c++) for (int row = 0; row < 4; row++) r.m[row][c] = (float)m->a[c * 4 + row].n;  // file is column-major
        return r;
    }
    Vec3 t(0, 0, 0), s(1, 1, 1);
    float q[4] = {0, 0, 0, 1};
    if (const JV* v = node.get("translation")) if (v->count() == 3) t = Vec3((float)v->a[0].n, (float)v->a[1].n, (float)v->a[2].n);
    if (const JV* v = node.get("scale")) if (v->count() == 3) s = Vec3((float)v->a[0].n, (float)v->a[1].n, (float)v->a[2].n);
    if (const JV* v = node.get("rotation")) if (v->count() == 4) for (int i = 0; i < 4; i++) q[i] = (float)v->a[i].n;
    float x = q[0], y = q[1], z = q[2], w = q[3];
    Mat4 R;
    R.m[0][0] = 1 - 2 * (y * y + z * z); R.m[0][1] = 2 * (x * y - z * w);     R.m[0][2] = 2 * (x * z + y * w);
    R.m[1][0] = 2 * (x * y + z * w);     R.m[1][1] = 1 - 2 * (x * x + z * z); R.m[1][2] = 2 * (y * z - x * w);
    R.m[2][0] = 2 * (x * z - y * w);     R.m[2][1] = 2 * (y * z + x * w);     R.m[2][2] = 1 - 2 * (x * x + y * y);
    return Mat4::translate(t) * R * Mat4::scale(s);
}

// Loads a .glb from memory. Returns false (with a message) if the file cannot be used.
inline bool loadGLB(const uint8_t* d, size_t n, ModelData& out, std::string* err = nullptr) {
    auto fail = [&](const char* m) { if (err) *err = m; return false; };
    if (n < 20 || std::memcmp(d, "glTF", 4) != 0) return fail("not a .glb file");
    auto u32 = [&](size_t o) { uint32_t v; std::memcpy(&v, d + o, 4); return v; };  // phones are little-endian
    if (u32(4) != 2) return fail("only glTF 2.0 is supported");

    std::string json;
    const uint8_t* bin = nullptr;
    size_t binLen = 0, off = 12;
    while (off + 8 <= n) {
        uint32_t len = u32(off), type = u32(off + 4);
        off += 8;
        if (off + len > n) return fail("file is cut short");
        if (type == 0x4E4F534Au) json.assign((const char*)d + off, len);                // "JSON"
        else if (type == 0x004E4942u && !bin) { bin = d + off; binLen = len; }          // "BIN"
        off += (len + 3) & ~3u;
    }
    JV root;
    if (json.empty() || !JsonParser(json.c_str(), json.c_str() + json.size()).parse(root)) return fail("bad JSON in .glb");

    const JV* accs = root.get("accessors");
    const JV* views = root.get("bufferViews");

    // Reads accessor "idx" as floats and/or integers.
    auto accessor = [&](int idx, std::vector<float>* fo, std::vector<uint32_t>* io, int* comps) -> bool {
        if (!accs || !views || !bin || idx < 0 || idx >= accs->count()) return false;
        const JV& a = accs->a[idx];
        int bv = (int)a.num("bufferView", -1);
        if (bv < 0 || bv >= views->count()) return false;
        const JV& v = views->a[bv];
        size_t base = (size_t)v.num("byteOffset", 0) + (size_t)a.num("byteOffset", 0);
        int ct = (int)a.num("componentType", 0), cnt = (int)a.num("count", 0);
        const JV* tp = a.get("type");
        if (!tp) return false;
        int nc = tp->s == "SCALAR" ? 1 : tp->s == "VEC2" ? 2 : tp->s == "VEC3" ? 3 : tp->s == "VEC4" ? 4 : 0;
        int cs = (ct == 5120 || ct == 5121) ? 1 : (ct == 5122 || ct == 5123) ? 2 : (ct == 5125 || ct == 5126) ? 4 : 0;
        if (!nc || !cs || cnt <= 0) return false;
        size_t stride = (size_t)v.num("byteStride", 0);
        if (!stride) stride = (size_t)cs * nc;
        const JV* nm = a.get("normalized");
        bool norm = nm && nm->b;
        if (base + (size_t)(cnt - 1) * stride + (size_t)cs * nc > binLen) return false;
        if (fo) fo->resize((size_t)cnt * nc);
        if (io) io->resize((size_t)cnt * nc);
        for (int i = 0; i < cnt; i++)
            for (int k = 0; k < nc; k++) {
                const uint8_t* p = bin + base + (size_t)i * stride + (size_t)k * cs;
                float f = 0; uint32_t u = 0;
                switch (ct) {
                    case 5126: std::memcpy(&f, p, 4); u = (uint32_t)f; break;
                    case 5125: std::memcpy(&u, p, 4); f = (float)u; break;
                    case 5123: { uint16_t x; std::memcpy(&x, p, 2); u = x; f = norm ? x / 65535.f : (float)x; } break;
                    case 5122: { int16_t x; std::memcpy(&x, p, 2); u = (uint32_t)x; f = norm ? std::max(x / 32767.f, -1.f) : (float)x; } break;
                    case 5121: { uint8_t x = *p; u = x; f = norm ? x / 255.f : (float)x; } break;
                    default: { int8_t x = (int8_t)*p; u = (uint32_t)x; f = norm ? std::max(x / 127.f, -1.f) : (float)x; } break;
                }
                if (fo) (*fo)[(size_t)i * nc + k] = f;
                if (io) (*io)[(size_t)i * nc + k] = u;
            }
        if (comps) *comps = nc;
        return true;
    };

    // images (decoded when stb_image is available)
    if (const JV* imgs = root.get("images")) {
        for (int i = 0; i < imgs->count(); i++) {
            ImageData im;
#ifdef HAVE_STB_IMAGE
            const JV& j = imgs->a[i];
            int bv = (int)j.num("bufferView", -1);
            if (views && bin && bv >= 0 && bv < views->count()) {
                const JV& v = views->a[bv];
                size_t o = (size_t)v.num("byteOffset", 0), len = (size_t)v.num("byteLength", 0);
                if (o + len <= binLen) {
                    int w = 0, h = 0, c = 0;
                    unsigned char* px = stbi_load_from_memory(bin + o, (int)len, &w, &h, &c, 4);
                    if (px) { im.w = w; im.h = h; im.rgba.assign(px, px + (size_t)w * h * 4); stbi_image_free(px); }
                }
            }
#endif
            out.images.push_back(std::move(im));
        }
    }
    const JV* texs = root.get("textures");
    auto texSource = [&](const JV* t) -> int {
        if (!t || !texs) return -1;
        int ti = (int)t->num("index", -1);
        if (ti < 0 || ti >= texs->count()) return -1;
        int src = (int)texs->a[ti].num("source", -1);
        return (src >= 0 && src < (int)out.images.size() && out.images[src].w > 0) ? src : -1;
    };

    // materials
    if (const JV* ms = root.get("materials")) {
        for (int i = 0; i < ms->count(); i++) {
            const JV& m = ms->a[i];
            MatData md;
            if (const JV* pbr = m.get("pbrMetallicRoughness")) {
                if (const JV* bc = pbr->get("baseColorFactor"))
                    if (bc->count() >= 4) { md.base = Vec3((float)bc->a[0].n, (float)bc->a[1].n, (float)bc->a[2].n); md.alpha = (float)bc->a[3].n; }
                md.metal = (float)pbr->num("metallicFactor", 1);
                md.rough = (float)pbr->num("roughnessFactor", 1);
                md.texBase = texSource(pbr->get("baseColorTexture"));
                md.texMR = texSource(pbr->get("metallicRoughnessTexture"));
            }
            md.texNormal = texSource(m.get("normalTexture"));
            md.texEmis = texSource(m.get("emissiveTexture"));
            if (const JV* e = m.get("emissiveFactor")) if (e->count() == 3) md.emissive = Vec3((float)e->a[0].n, (float)e->a[1].n, (float)e->a[2].n);
            if (const JV* am = m.get("alphaMode")) md.mask = (am->s == "MASK" || am->s == "BLEND");  // leaves: cut-out instead of see-through
            md.cut = (float)m.num("alphaCutoff", 0.5);
            if (const JV* ds = m.get("doubleSided")) md.dbl = ds->b;
            out.mats.push_back(md);
        }
    }

    // meshes: a list of primitives, each with its own material
    struct Prim { MeshData mesh; int mat; };
    std::vector<std::vector<Prim>> meshes;
    if (const JV* ms = root.get("meshes")) {
        for (int i = 0; i < ms->count(); i++) {
            meshes.emplace_back();
            const JV* prims = ms->a[i].get("primitives");
            if (!prims) continue;
            for (int pi = 0; pi < prims->count(); pi++) {
                const JV& pr = prims->a[pi];
                if ((int)pr.num("mode", 4) != 4) continue;  // triangles only
                const JV* at = pr.get("attributes");
                if (!at) continue;
                std::vector<float> pos, nor, uv;
                int c = 0;
                if (!accessor((int)at->num("POSITION", -1), &pos, nullptr, &c) || c != 3) continue;
                size_t nv = pos.size() / 3;
                bool hasN = at->get("NORMAL") && accessor((int)at->num("NORMAL", -1), &nor, nullptr, &c) && c == 3 && nor.size() == pos.size();
                bool hasUV = at->get("TEXCOORD_0") && accessor((int)at->num("TEXCOORD_0", -1), &uv, nullptr, &c) && c == 2 && uv.size() / 2 == nv;
                Prim p;
                p.mat = (int)pr.num("material", -1);
                std::vector<uint32_t> ix;
                if (pr.get("indices")) { if (!accessor((int)pr.num("indices", -1), nullptr, &ix, &c)) continue; }
                else for (size_t k = 0; k < nv; k++) ix.push_back((uint32_t)k);
                bool bad = false;
                for (uint32_t k : ix) if (k >= nv) bad = true;
                if (bad || ix.size() < 3) continue;
                if (!hasN) {  // no normals in the file: make smooth ones
                    nor.assign(pos.size(), 0.f);
                    for (size_t k = 0; k + 2 < ix.size(); k += 3) {
                        Vec3 a(pos[ix[k] * 3], pos[ix[k] * 3 + 1], pos[ix[k] * 3 + 2]), b(pos[ix[k + 1] * 3], pos[ix[k + 1] * 3 + 1], pos[ix[k + 1] * 3 + 2]),
                             cc(pos[ix[k + 2] * 3], pos[ix[k + 2] * 3 + 1], pos[ix[k + 2] * 3 + 2]);
                        Vec3 fnn = cross(b - a, cc - a);
                        for (int q = 0; q < 3; q++) { nor[ix[k + q] * 3] += fnn.x; nor[ix[k + q] * 3 + 1] += fnn.y; nor[ix[k + q] * 3 + 2] += fnn.z; }
                    }
                    for (size_t k = 0; k < nv; k++) {
                        Vec3 nn = normalize(Vec3(nor[k * 3], nor[k * 3 + 1], nor[k * 3 + 2]));
                        nor[k * 3] = nn.x; nor[k * 3 + 1] = nn.y; nor[k * 3 + 2] = nn.z;
                    }
                }
                p.mesh.v.resize(nv * 8);
                for (size_t k = 0; k < nv; k++) {
                    float* o = &p.mesh.v[k * 8];
                    o[0] = pos[k * 3]; o[1] = pos[k * 3 + 1]; o[2] = pos[k * 3 + 2];
                    o[3] = nor[k * 3]; o[4] = nor[k * 3 + 1]; o[5] = nor[k * 3 + 2];
                    o[6] = hasUV ? uv[k * 2] : 0.f; o[7] = hasUV ? uv[k * 2 + 1] : 0.f;
                }
                p.mesh.idx = std::move(ix);
                meshes.back().push_back(std::move(p));
            }
        }
    }

    // nodes: walk the scene and place every mesh
    const JV* nodes = root.get("nodes");
    if (!nodes) return fail("no nodes in the model");
    std::vector<bool> isChild(nodes->count(), false);
    for (int i = 0; i < nodes->count(); i++)
        if (const JV* ch = nodes->a[i].get("children"))
            for (auto& c : ch->a) if ((int)c.n >= 0 && (int)c.n < nodes->count()) isChild[(int)c.n] = true;
    std::vector<int> roots;
    const JV* scenes = root.get("scenes");
    int sc = (int)root.num("scene", 0);
    if (scenes && sc >= 0 && sc < scenes->count() && scenes->a[sc].get("nodes"))
        for (auto& c : scenes->a[sc].get("nodes")->a) roots.push_back((int)c.n);
    else
        for (int i = 0; i < nodes->count(); i++) if (!isChild[i]) roots.push_back(i);

    std::function<void(int, const Mat4&, int)> visit = [&](int ni, const Mat4& parent, int depth) {
        if (ni < 0 || ni >= nodes->count() || depth > 32) return;
        const JV& nd = nodes->a[ni];
        Mat4 world = parent * gltfNodeMatrix(nd);
        int mi = (int)nd.num("mesh", -1);
        if (mi >= 0 && mi < (int)meshes.size())
            for (Prim& p : meshes[mi]) { PartData pd; pd.mesh = p.mesh; pd.world = world; pd.mat = p.mat; out.parts.push_back(std::move(pd)); }
        if (const JV* ch = nd.get("children")) for (auto& c : ch->a) visit((int)c.n, world, depth + 1);
    };
    for (int r : roots) visit(r, Mat4(), 0);
    if (out.parts.empty()) return fail("the model has no triangles");

    bool first = true;
    for (auto& pt : out.parts)
        for (size_t k = 0; k < pt.mesh.v.size(); k += 8) {
            Vec3 w = pt.world.point(Vec3(pt.mesh.v[k], pt.mesh.v[k + 1], pt.mesh.v[k + 2]));
            if (first) { out.lo = out.hi = w; first = false; }
            out.lo = Vec3(std::min(out.lo.x, w.x), std::min(out.lo.y, w.y), std::min(out.lo.z, w.z));
            out.hi = Vec3(std::max(out.hi.x, w.x), std::max(out.hi.y, w.y), std::max(out.hi.z, w.z));
        }
    return true;
}

// Centers the model on the origin and scales it so its longest side is "size" units.
inline void normalizeModel(ModelData& m, float size) {
    Vec3 c = (m.lo + m.hi) * 0.5f, ext = m.hi - m.lo;
    float big = std::max(ext.x, std::max(ext.y, ext.z));
    if (big < 1e-6f) return;
    float s = size / big;
    Mat4 fix = Mat4::scale(Vec3(s, s, s)) * Mat4::translate(-c);
    for (auto& p : m.parts) p.world = fix * p.world;
    m.lo = ext * (-0.5f * s);
    m.hi = ext * (0.5f * s);
}

// Puts the model's bottom at y = 0, centers it left/right, and scales it so it is "height" units tall.
inline void fitModelOnGround(ModelData& m, float height) {
    Vec3 ext = m.hi - m.lo;
    if (ext.y < 1e-6f) return;
    float s = height / ext.y;
    Vec3 c((m.lo.x + m.hi.x) * 0.5f, m.lo.y, (m.lo.z + m.hi.z) * 0.5f);
    Mat4 fix = Mat4::scale(Vec3(s, s, s)) * Mat4::translate(-c);
    for (auto& p : m.parts) p.world = fix * p.world;
    m.lo = Vec3(-ext.x * 0.5f * s, 0.f, -ext.z * 0.5f * s);
    m.hi = Vec3(ext.x * 0.5f * s, height, ext.z * 0.5f * s);
}

// Decodes a PNG or JPG file held in memory (needs stb_image.h; returns false without it).
inline bool decodeImage(const uint8_t* d, size_t n, ImageData& out) {
#ifdef HAVE_STB_IMAGE
    int w = 0, h = 0, c = 0;
    unsigned char* px = stbi_load_from_memory(d, (int)n, &w, &h, &c, 4);
    if (!px) return false;
    out.w = w; out.h = h; out.rgba.assign(px, px + (size_t)w * h * 4);
    stbi_image_free(px);
    return true;
#else
    (void)d; (void)n; (void)out;
    return false;
#endif
}
