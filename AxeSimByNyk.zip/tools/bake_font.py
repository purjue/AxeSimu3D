# Turns a .ttf font into the picture + letter table the game draws text with.
# Usage:  python3 tools/bake_font.py tools/Kurland.ttf app/src/main/assets/fonts
# (needs:  pip install pillow)   Output: kurland.txt and kurland.raw
import sys, os
from PIL import Image, ImageDraw, ImageFont
ttf, out = sys.argv[1], sys.argv[2]
SIZE, PAD, AW, AH = 56, 3, 1024, 512
font = ImageFont.truetype(ttf, SIZE)
asc, desc = font.getmetrics()
img = Image.new('L', (AW, AH), 0); d = ImageDraw.Draw(img)
x = y = PAD; rowh = 0; lines = []
for code in range(32, 127):
    ch = chr(code)
    l, t, r, b = font.getbbox(ch, anchor='ls'); w, h = max(0, r - l), max(0, b - t)
    gx = gy = 0
    if w > 0 and h > 0:
        if x + w + PAD > AW: x = PAD; y += rowh + PAD; rowh = 0
        d.text((x - l, y - t), ch, font=font, fill=255, anchor='ls'); gx, gy = x, y; x += w + PAD; rowh = max(rowh, h)
    lines.append(f"{code} {gx} {gy} {w} {h} {l} {t} {font.getlength(ch):.3f}")
assert y + rowh + PAD <= AH, "atlas too small"
os.makedirs(out, exist_ok=True)
open(os.path.join(out, 'kurland.txt'), 'w').write(f"{AW} {AH} {SIZE} {asc} {desc} {asc + desc}\n" + "\n".join(lines) + "\n")
open(os.path.join(out, 'kurland.raw'), 'wb').write(img.tobytes())
print("baked", len(lines), "characters")
