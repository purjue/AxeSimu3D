NEW IN THIS VERSION
===================

GRAPHICS  (Options > LOW / MEDIUM / HIGH)
  LOW     nothing changes (the original look and speed).
  MEDIUM  bloom + realistic lighting.
  HIGH    god rays + bloom (a little wider) + realistic lighting.
  - Bloom adds 10% of the blurred bright parts. To change it: gpu_renderer.h  bloomStrength (0.10), bloomGain, rayStrength.
  - Realistic lighting = softer shadow edges, sky-blue light inside shadows, sun-lit haze, less shine-sparkle on bumpy
    surfaces, and grass / leaves that glow when the sun shines through them. LOW uses the original shader untouched.
  - If a phone cannot build a new shader, the game falls back to the normal picture by itself (it never breaks).
  - AUTO LOWER (Options): when the phone is slow it switches the extras off first, then shadows, then the resolution.

3D GRASS
  - Your grass.obj was converted to app/src/main/assets/models/grass_clump.glb (your six greens were merged into three
    so it draws faster). The ground still uses your own grass texture.
  - Options > GRASS: ON / OFF (saved). Only grass within 34 units of you is drawn; grass casts no shadows.
  - Number and size of the clumps: axe_sim.h, search "3D grass" (90 patches x 7 clumps, size 1.3 - 2.4).

SOUNDS  (app/src/main/assets/sounds/*.wav, played by MainActivity.java)
  chop, jump, land, step1-3 (walking), run1-3 (running), ambient (wind, leaves and birds, loops forever).
  They were made for you with code. To use your own sounds, replace the files and keep the same names.

SPRINT
  - A small SPRINT button above the joystick. Tap = run (1.7 times faster, with running steps), tap again = walk.

SPIN WHEEL
  - The wood price keeps the HIGHEST multiplier: x5 then x3 stays x5, then x10 becomes x10.

WOOD
  - No more 2 billion limit: wood can go up to 1e300 (shown as 1k, 1M, 1B ... 1Qa ... aa, ab ...).
  - WOOD MULTIPLIER steps:  1x 2x 3x ... 10x, then 20x 30x ... 100x, then 200x 300x ... 1000x, and so on without end.
  - Upgrades allowed per level: 10 in level 1, 20 in level 2, ... 100 in level 10 (axe_sim.h  multMaxUpgrades()).
    Going back to a lower level never takes upgrades away.

IMPORTANT FOR GITHUB: keep only ONE .zip in the main folder of the repository (the build uses the first one it finds).
