

## Smooth axe motion and UI polish
- Added eased, low-frequency first-person axe bob that activates only while walking and fades smoothly at rest.
- Added a darker glass-style HUD, clearer resource panels, a refined stamina bar, toast backing, and updated shop/world/options panel styling.
- These changes are source-level updates; run the GitHub Actions workflow to compile and verify on Android.


Latest touch/UI update: the movement joystick is invisible until you touch the left movement area, then appears dynamically under your finger. HUD and menus use brighter warm cream, sky-blue, and orange accents rather than dark panels.
