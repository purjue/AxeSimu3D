AXE SIMULATOR 3D  -  an Android game written in C++ (OpenGL ES 3.0 engine, no Godot; one tiny Java activity for Android)
===============================================================================================

THE GAME
  - An island with hills, a beach, a wooden fence along the shore, and the sea beyond it. You cannot walk into the water.
  - Chop 60 pine trees. Trees fall and grow back after a while.
  - SHOP (food stall), two pages:
      SELL     : sell 1 wood, or all your wood (5 coins each).
      UPGRADES : axe (more damage + 10% chance of double wood per level, up to 90%), stamina,
                 MAX WOOD (the most wood one tree can give: 7, 9, 11 ... costs 3,000 then 12,000 then 27,000 ...),
                 WOOD MULTIPLIER (x1.5, x2.0 ... costs 5,000 then 20,000 then 45,000 ...).
  - PORT (the gate): WORLD 2 (autumn woods, 60 trees) costs 100,000 coins. Every tree there gives 10x wood.
  - Progress and settings are saved automatically.

CONTROLS (landscape)
  Joystick  : touch anywhere on the left half. It is small, but the touch area is big and dynamic (the stick follows
              your finger). It only WALKS (forward, back, sideways). It never turns the camera.
  Camera    : drag anywhere else on the screen. You can move and look at the same time.
  CHOP, JUMP, SHOP/PORT : three small buttons on the right (SHOP / PORT appears when you stand near them).
  OPTIONS   : button under the wood / coin counters (top left).

OPTIONS
  Camera view (first / third person), graphics LOW / MEDIUM / HIGH, resolution scaler (30% to 125%, 100% = full
  resolution), shadows on/off, auto lower (lowers graphics by itself if the game is slow), restart world.

TEXT: everything you read in the game uses the Kurland font (tools/Kurland.ttf, baked into the app's assets/fonts).
  To change the font: python3 tools/bake_font.py tools/YourFont.ttf app/src/main/assets/fonts

ADS
- Ads have been removed from this build. No banner or rewarded video is loaded.



CUSTOM BUILD NOTES
- Ads removed from this no-ads project.
- Free Spin button removed; Price Spin uses in-game coins only.
- No real-money/in-app purchase integration is included in this project.
